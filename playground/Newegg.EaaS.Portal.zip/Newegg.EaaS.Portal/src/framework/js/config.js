var NEG = NEG || {};

NEG.NewkitAPI = "http://10.16.75.24:9020"; // Newkit自身API地址，请不要修改
//NEG.NewkitAPI = "http://localhost:9020"; // Newkit自身API地址，请不要修改

NEG.debug = true; //运行状态，用于Log记录位置，Debug时仅仅记录到Console，非Debug会记录到Console和Log System

NEG.APIGatewayAddress = "http://10.16.75.24:3000"; //Gateway地址，用于拼接API地址

NEG.DomainName = "Newkit"; //用来从Global Config中获取配置，同时也用来设置缓存使用，不同的系统使用不同的名字

//所有挂载到系统的Application Id，Id来自于Keystone的GUID，和Newegg Central类似
NEG.Applications =
 {
   "Newkit": "1f48a705-b734-476c-b32b-29359177c122",
   "NeweggCentral": "dfbc65d8-9205-4336-9521-647f450d8b43",
   "EDI": "8767a1d1-7efe-4666-8646-e0e97bb073e2"
 }

//Log的相关配置，主要用于记录客户端的Log
NEG.LogGlobal="Newkit";
NEG.LogLocal="Client";
NEG.LogCategory="ExceptionLog";

NEG.languages={
  'en-us':"English",
  'zh-cn':'简体中文',
  'zh-tw':'繁體中文'
}