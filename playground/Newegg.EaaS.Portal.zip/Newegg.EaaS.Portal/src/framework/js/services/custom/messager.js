﻿
negServices.factory("messager", function() {
  return {
    success: function(msg, retainOther) {
      if (!retainOther) {
        Messenger().hideAll();
      }
      return Messenger().post({
        message: msg,
        type: 'success',
        showCloseButton: true
      });
    },
    error: function(msg, retainOther) {
      if (!retainOther) {
        Messenger().hideAll();
      }
      if (msg === '401') {
        msg = 'Unauthorized.';
      }
      return Messenger().post({
        message: msg,
        type: 'error',
        showCloseButton: true,
        delay: 600
      });
    },
    info: function(msg, retainOther) {
      if (!retainOther) {
        Messenger().hideAll();
      }
      if (msg === '401') {
        msg = 'Unauthorized.';
      }
      return Messenger().post({
        message: msg,
        type: 'info',
        showCloseButton: true,
        delay: 600
      });
    },
    hideAll: function() {
      Messenger().hideAll();
      return $.gritter.removeAll();
    },
    confirm: function(callback, msg) {
      return msg = Messenger().post({
        message: msg || "Do you want to continue?",
        id: "Only-one-message",
        showCloseButton: true,
        actions: {
          OK: {
            label: "OK",
            phrase: "Confirm",
            delay: 60,
            action: function() {
              callback();
              return msg.cancel();
            }
          },
          cancel: {
            action: function() {
              return msg.cancel();
            }
          }
        }
      });
    },
    prompt: function(callback, msg) {},
    notice: function(option) {
      return $.gritter.add(option);
    },
    hideNotice: function() {
      return $.gritter.removeAll();
    }
  };
});
