﻿(function() {

  angular.module("negTimePicker", []).directive("negTimePicker", function() {
    return {
      restrict: "A",
      link: function(scope, element, attrs) {
        var options;
        options = JSON.parse(attrs.negTimePicker);
        return $(element).timepicker(options);
      }
    };
  });

}).call(this);
