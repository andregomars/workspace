(function() {
  angular.module("app", ['framework-ctrl', 'system', 'eaas', 'custom-modules', 'ngRoute', 'ngSanitize', 'ngAnimate', 'ngCookies', 'pasvaz.bindonce', 'ngProgress', 'ui.utils', 'ui.bootstrap', 'ui.select2', 'ngDragDrop', 'angularFileUpload', 'pascalprecht.translate', 'negServices', 'negDirectives', 'formatFilters', 'rgkevin.datetimeRangePicker']).config([
    "$locationProvider", function($locationProvider) {
      return $locationProvider.html5Mode(true);
    }
  ]).config([
    "$httpProvider", function($httpProvider) {
      return $httpProvider.responseInterceptors.push([
        "$rootScope", "$q", function($rootScope, $q) {
          var error, success;
          success = function(response) {
            return response;
          };
          error = function(response) {
            return $q.reject(response);
          };
          return function(promise) {
            return promise.then(success, error);
          };
        }
      ]);
    }
  ]).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.otherwise({
        redirectTo: "/404"
      });
    }
  ]).config([
    "$translateProvider", function($translateProvider) {
      $translateProvider.preferredLanguage('en-us');
      $translateProvider.useLocalStorage();
      return $translateProvider.translations('en-us', resources.framework.us).translations('zh-cn', resources.framework.cn).translations('zh-tw', resources.framework.tw);
    }
  ]).run([
    "$rootScope", "progress", function($rootScope, progress) {
      return $rootScope.$on('$routeChangeStart', function() {
        return progress.complete();
      });
    }
  ]).run([
    "$rootScope", "authorize", "$location", function($rootScope, authorize, $location) {
      return $rootScope.$on('$routeChangeStart', function(event, current) {
        if (current && current.$$route && !authorize.canVisitPage(current.$$route.originalPath)) {
          $rootScope.$emit("negRouteProvider.ignore");
          return $location.path("/401").replace();
        }
      });
    }
  ]).run([
    "$rootScope", "userProfile", "$location", function($rootScope, userProfile, $location) {
      return $rootScope.$on("routePathCompleted", function(event, routePath) {
        var menu, mostUsed;
        if (routePath) {
          menu = routePath[routePath.length - 1];
          if (menu.Url !== '/login' && menu.Url !== '/loading' && menu.Url !== '/401' && menu.Url !== '/404' && menu.Url !== '/') {
            mostUsed = userProfile.get("most-used-menus") || {};
            if (!mostUsed[menu.Url]) {
              mostUsed[menu.Url] = 0;
            }
            mostUsed[menu.Url]++;
            return userProfile.set("most-used-menus", mostUsed);
          }
        }
      });
    }
  ]).run([
    "$rootScope", "authorize", "$location", "$http", "common", "authAPI", 'organizationAPI', '$interval', function($rootScope, authorize, $location, $http, common, authAPI, organizationAPI, $interval) {
      var current;
      $rootScope.Loading = {};
      $rootScope.Loading.delay = 0;
      $rootScope.Loading.minDuration = 0;
      $rootScope.Loading.message = 'Login...';
      $rootScope.Loading.backdrop = true;
      $rootScope.Loading.promise = null;
      $rootScope.UserAgent = {};
      $rootScope.UserAgent.chooseAgent = true;
      $rootScope.autoSetUserInfo = function() {
        if ($.cookie('eaas-auth-token') !== void 0) {
          if ($.cookie('eaas-auth-user') !== void 0) {
            common.currentUser = JSON.parse($.cookie('eaas-auth-user'));
            common.currentOrganization = null;
            common.LogoutReset();
          }
          $http.defaults.headers.common['AuthorizationToken'] = $.cookie('eaas-auth-token');
          $http.defaults.cache = false;
          if (!$http.defaults.headers.get) {
            $http.defaults.headers.get = {};
          }
          $http.defaults.headers.get['If-Modified-Since'] = 'Sat, 28 Nov 2009 01:00:00 GMT';
          $rootScope.__systemSetting = {};
          $rootScope.__systemSetting.hiddenMenu = true;
          $rootScope.__systemSetting.theme = 'ace';
          if (common.currentUser.UserRole === 'Partner') {
            common.loadStationIDListByCurrentUser(common.currentUser);
          }
          if (common.currentUser && common.currentUser.UserRole === common.userRole.organizationUser && common.currentUser.Type === common.userRole.superUser && common.currentUser.AgentOrganizationID) {
            return organizationAPI.search({
              id: common.currentUser.AgentOrganizationID
            }, function(result) {
              if (result && result.Succeeded && result.OrganizationList && result.OrganizationList.length > 0) {
                common.currentOrganization = result.OrganizationList[0];
                common.currentOrganization.IsAgent = true;
                return $rootScope.$broadcast("loginSuccessed");
              } else {
                common.clearUserInfo();
                return $rootScope.$broadcast("loginExpired");
              }
            }, function(error) {
              common.clearUserInfo();
              return $rootScope.$broadcast("loginExpired");
            });
          } else {
            if (common.currentUser && common.currentUser.Type === common.userRole.superUser && !common.currentUser.AgentOrganizationID) {
              $rootScope.UserAgent.chooseAgent = false;
              $rootScope.$broadcast("loginSuccessed");
              common.navigate('organization');
            }
            if (common.currentUser && common.currentUser.Type !== common.userRole.superUser && common.currentUser.OrganizationID) {
              return organizationAPI.search({
                id: common.currentUser.OrganizationID
              }, function(result) {
                if (result && result.Succeeded && result.OrganizationList && result.OrganizationList.length > 0) {
                  common.currentOrganization = result.OrganizationList[0];
                  return $rootScope.$broadcast("loginSuccessed");
                } else {
                  common.clearUserInfo();
                  return $rootScope.$broadcast("loginExpired");
                }
              }, function(error) {
                common.clearUserInfo();
                return $rootScope.$broadcast("loginExpired");
              });
            }
          }
        } else {
          $rootScope.$broadcast("logoutSuccessed");
          return common.navigate('home');
        }
      };
      $rootScope.autoLogin = function() {
        return authAPI.request({
          action: 'login'
        }, function(result) {
          return $rootScope.autoSetUserInfo();
        }, function(error) {
          return $rootScope.autoSetUserInfo();
        });
      };
      $rootScope.autoLogin2 = function() {
        $rootScope.$on('$destroy', $interval.cancel($rootScope.loginTimer));
        return $rootScope.autoSetUserInfo();
      };
      current = $location.path();
      if (current !== '/home') {
        $rootScope.__returnUrl = current;
      }
      $rootScope.$emit("negRouteProvider.ignore");
      $location.path('/home').replace();
      if ($http.defaults.headers.common['AuthorizationToken'] !== null) {
        delete $http.defaults.headers.common['AuthorizationToken'];
      }
      $rootScope.loginTimer = $interval($rootScope.autoLogin2, 1000);
      return $rootScope.__systemSetting = defaultProfile.system;
    }
  ]).run([
    '$route', function($route) {
      return $route.reload();
    }
  ]);

}).call(this);
