﻿(function() {

  angular.module("framework-ctrl-header", []).controller('HeaderCtrl', [
    '$scope', 'version', 'messager', 'userProfile', "$rootScope", "$http", "$location", "authorize", 'common', 'authAPI', '$interval', function($scope, version, messager, userProfile, $rootScope, $http, $location, authorize, common, authAPI, $interval) {
      var findTools, getMenuName, loginSuccessed;
      $scope.common = common;
      $scope.homeIconLink = function(isLogin) {
        common.isBackPage = false;
        if (isLogin === false) {
          return $location.path('/');
        } else {
          return $location.path('/index');
        }
      };
      $rootScope.menuStatusChange = function() {
        return $scope.common.current.link.status = 'menu';
      };
      $rootScope.$on("$routeChangeStart", function(next, current) {
        var routePath;
        if (current.$$route.originalPath) {
          routePath = current.$$route.originalPath;
          if (common.currentUser && common.currentUser.UserRole === 'Partner' && (routePath === '/agreement' || routePath === '/station')) {
            common.loadStationIDListByCurrentUser(common.currentUser);
          }
          $scope.menuName = getMenuName(routePath);
          common.validationSuperVisor(common, routePath);
        }
        if ($rootScope.timer) {
          return $rootScope.$on('$destroy', $interval.cancel($rootScope.timer));
        }
      });
      getMenuName = function(routePath) {
        if (routePath === "/home" && $rootScope.isSignout === true) {
          $.removeCookie('eaas-auth-token');
          $.removeCookie('eaas-auth-user');
          $.removeCookie('eaas-agent-auth-token');
          delete $http.defaults.headers.common['AuthorizationToken'];
          $rootScope.isSignout = false;
        }
        if (routePath === "/agreement" || routePath === "/account" || routePath === "/agreement/edit" || routePath === "/partner" || routePath === "/organization" || routePath === "/account/create" || routePath === "/account/edit" || routePath === "/partner/create" || routePath === "/partner/edit" || routePath === "/agreement/create" || routePath === "/organization/view" || routePath === "/organization" || routePath === "/organization/detail" || routePath === "/station" || routePath === "/station/create" || routePath === "/station/edit" || routePath === "/station/view" || routePath === "/partner/view" || routePath === "/account/view" || routePath === "/agreement/view" || routePath === "/organization/create" || routePath === "/organization/edit") {
          return 'Management';
        }
        if (routePath === "/schema" || routePath === "/mapper" || routePath === "/transmission" || routePath === "/certificate" || routePath === "/schema/create" || routePath === "/schema/edit" || routePath === "/mapper/create" || routePath === "/mapper/edit" || routePath === "/transmission/create" || routePath === "/transmission/edit" || routePath === "/certificate/upload" || routePath === "/schema/view" || routePath === "/mapper/view" || routePath === "/certificate/view" || routePath === "/transmission/view") {
          return 'Resource';
        }
        if (routePath === "/statistics" || routePath === "/action-log" || routePath === "/message" || routePath === "/message/view") {
          return 'Monitor';
        }
        if (routePath === "/") {
          return 'Home';
        }
        if (routePath === '/transfer') {
          return '';
        }
        if (routePath === "/version-history" || routePath === "/feature") {
          return 'Help';
        }
        return 'Home';
      };
      if ($location.$$url) {
        $scope.menuName = getMenuName($location.$$url);
      }
      version.get().then(function(data) {
        return $scope.version = data[0].ver;
      });
      findTools = function(urls, allTools) {
        var tool, tools, url, _i, _j, _len, _len1;
        if (!urls || urls.length === 0 || !allTools || allTools.length === 0) {
          return null;
        }
        tools = [];
        for (_i = 0, _len = urls.length; _i < _len; _i++) {
          url = urls[_i];
          for (_j = 0, _len1 = allTools.length; _j < _len1; _j++) {
            tool = allTools[_j];
            if (url === tool.tplUrl) {
              tools.push(tool);
              break;
            }
          }
        }
        return tools;
      };
      loginSuccessed = function() {
        var allTools, urls;
        $scope.user = authorize.accountInfo;
        urls = userProfile.get("toolbars");
        if (urls && urls.length === 0) {
          urls = defaultProfile.toolbars;
        }
        allTools = authorize.toolbars || [];
        return $scope.toolbars = findTools(urls, allTools);
      };
      $scope.$on("loginSuccessed", function() {
        return loginSuccessed();
      });
      if ($scope.__loginAfter) {
        loginSuccessed();
      }
      $scope.$on('setToolbarSuccessed', function(event, selectedUrls) {
        var allTools;
        if (!selectedUrls || selectedUrls.length === 0) {
          selectedUrls = defaultProfile.toolbars;
        }
        allTools = authorize.toolbars || [];
        return $scope.toolbars = findTools(selectedUrls, allTools);
      });
      $scope.showExitAgent = function() {
        if (common.currentUser.Type === common.userRole.superUser && $rootScope.UserAgent.chooseAgent === true) {
          return true;
        }
        return false;
      };
      $scope.exitAgent = function() {
        return authAPI.request({
          action: 'agent',
          OrganizationID: null
        }, function(result) {
          if (result && result.Succeeded && result.Status === 'Successful') {
            common.setUserToken(result.AuthorizationToken);
            common.currentOrganization = null;
            common.LogoutReset();
            common.currentUser.OrganizationID = null;
            common.currentUser.AgentOrganizationID = null;
            common.saveUserInfo(common.currentUser);
            $rootScope.UserAgent.chooseAgent = false;
            $rootScope.exitAgentNow = true;
            common.navigate('organization');
            messager.success("You have successfully stopped working as an agent of an organization.");
            return $rootScope.$broadcast("ExitAgentSuccessed");
          } else {
            return common.ShowAPIError('Stop working as an agent of an organization failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Stop working as an agent of an organization failed.', error.data);
        });
      };
      $scope.signout = function(loginAgain) {
        authAPI.request({
          action: 'logout'
        }, function(result) {
          if (result && result.Succeeded) {
            return null;
          } else {
            return common.ShowAPIError('Logout failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Logout failed.', error.data);
        });
        $rootScope.isSignout = true;
        $.removeCookie('eaas-auth-token');
        $.removeCookie('eaas-auth-user');
        $.removeCookie('eaas-agent-auth-token');
        messager.hideNotice();
        delete $http.defaults.headers.common['AuthorizationToken'];
        if ($http.defaults.headers.common['OrganizationID'] !== null) {
          delete $http.defaults.headers.common['OrganizationID'];
        }
        if ($http.defaults.headers.common['PartnerID'] !== null) {
          delete $http.defaults.headers.common['PartnerID'];
        }
        if ($http.defaults.headers.common['StationID'] !== null) {
          delete $http.defaults.headers.common['StationID'];
        }
        common.currentUser = {};
        common.currentOrganization = {};
        if (loginAgain) {
          $rootScope.$broadcast("loginExpired");
        }
        $rootScope.$broadcast("logoutSuccessed");
        $rootScope.__returnUrl = $location.path();
        return $location.path('/home');
      };
      return $scope.$on('userInfoChanged', function() {
        return $scope.signout();
      });
    }
  ]);

}).call(this);
