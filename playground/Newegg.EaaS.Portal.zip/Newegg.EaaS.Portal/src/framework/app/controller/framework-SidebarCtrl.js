﻿
angular.module("framework-ctrl-sidebar", []).controller('SidebarCtrl', [
  "$scope", "$location", "$window", "userProfile", "authorize", "$rootScope", "$http", "$route", function($scope, $location, $window, userProfile, authorize, $rootScope, $http, $route) {
    var findPath, getHasSub, hasSubMenus, loadMenu, setFavorite;
    setFavorite = function() {
      var favUrls, url, _i, _len, _results;
      favUrls = userProfile.get("favor-link") || [];
      $scope.links = [];
      _results = [];
      for (_i = 0, _len = favUrls.length; _i < _len; _i++) {
        url = favUrls[_i];
        if (authorize.urls[url] != null) {
          _results.push($scope.links.push(authorize.urls[url]));
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.$on("favorLinkChanged", function() {
      return setFavorite();
    });
    $scope.back = function() {
      return $window.history.go(-1);
    };
    $scope.forward = function() {
      return $window.history.go(1);
    };
    $scope.refresh = function() {
      return $route.reload();
    };
    loadMenu = function() {
      var data;
      data = authorize.menus || [];
      getHasSub(data);
      $scope.__menus = data;
      setTimeout((function() {
        return ace.handle_side_menu($);
      }), 1000);
      return $scope.routePath = [];
    };
    $scope.$on("loginSuccessed", function() {
      return loadMenu();
    });
    getHasSub = function(menus) {
      var m, _i, _len, _results;
      if (!menus || !menus.length) {
        return;
      }
      _results = [];
      for (_i = 0, _len = menus.length; _i < _len; _i++) {
        m = menus[_i];
        m.HasSubMenus = hasSubMenus(m);
        _results.push(getHasSub(m.SubMenus));
      }
      return _results;
    };
    hasSubMenus = function(menu) {
      var m, _i, _len, _ref;
      if (!menu.SubMenus || menu.SubMenus.length === 0) {
        return false;
      }
      _ref = menu.SubMenus;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        m = _ref[_i];
        if (m.IsVisible) {
          return true;
        }
      }
      return false;
    };
    $rootScope.$on("$routeChangeSuccess", function() {
      var currentPath, item, menus, result, routePath, _i, _j, _len, _len1;
      currentPath = $location.path();
      menus = $scope.__menus;
      routePath = $scope.routePath;
      if ((routePath != null) && routePath.length > 0) {
        for (_i = 0, _len = routePath.length; _i < _len; _i++) {
          item = routePath[_i];
          item.isSelected = false;
        }
      }
      routePath = [];
      if (currentPath === "/login" || currentPath === "/401" || currentPath === "/404") {
        $rootScope.$broadcast("routePathCompleted");
        $scope.routePath = [];
        return;
      }
      if ((menus != null) && menus.length > 0) {
        result = findPath(routePath, menus, currentPath);
        if (result === true) {
          $rootScope.$broadcast("routePathCompleted", routePath);
          for (_j = 0, _len1 = routePath.length; _j < _len1; _j++) {
            item = routePath[_j];
            item.isSelected = true;
          }
          return $scope.routePath = routePath;
        } else {
          $rootScope.$broadcast("routePathCompleted");
          return $scope.routePath = [];
        }
      }
    });
    findPath = function(routePath, menus, url) {
      var menu, _i, _len;
      for (_i = 0, _len = menus.length; _i < _len; _i++) {
        menu = menus[_i];
        if ((menu.Url != null) && menu.Url.toLowerCase() === url.toLowerCase()) {
          routePath.push(menu);
          return true;
        } else if ((menu.SubMenus != null) && menu.SubMenus.length > 0) {
          routePath.push(menu);
          if (findPath(routePath, menu.SubMenus, url) === true) {
            return true;
          } else {
            routePath.pop();
          }
        }
      }
      return false;
    };
    if ($scope.__loginAfter) {
      loadMenu();
      return setFavorite();
    }
  }
]);
