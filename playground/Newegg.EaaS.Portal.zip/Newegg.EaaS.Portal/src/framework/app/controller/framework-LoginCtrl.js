﻿
angular.module("framework-ctrl-login", ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/home", {
      template: "",
      controller: function() {}
    });
  }
]).controller('LoginCtrl', [
  "$scope", "noticeCenter", "$rootScope", "$http", "messager", "common", "authAPI", 'organizationAPI', '$location', function($scope, noticeCenter, $rootScope, $http, messager, common, authAPI, organizationAPI, $location) {
    noticeCenter.onLoad();
    $scope.common = common;
    $scope.homeIconLink = function(isLogin) {
      if (isLogin === true) {
        return $location.path('/');
      } else {
        return $location.path('/home');
      }
    };
    $rootScope.__featurePanel = false;
    $scope.showFeature = function() {
      $rootScope.__loginAfter = false;
      $rootScope.__login = false;
      $rootScope.__logoff = false;
      return $rootScope.__featurePanel = true;
    };
    $scope.showHome = function() {
      $rootScope.__loginAfter = false;
      $rootScope.__login = false;
      $rootScope.__logoff = true;
      return $rootScope.__featurePanel = false;
    };
    $scope.showlogin = function() {
      $rootScope.__loginAfter = false;
      $rootScope.__login = true;
      $rootScope.__logoff = false;
      return $rootScope.__featurePanel = false;
    };
    $rootScope.$on("$routeChangeStart", function(next, current) {
      var routePath;
      if ($scope.user && $scope.user.IsRememberMe) {
        $scope.user.IsRememberMe = false;
      }
      routePath = current.$$route.originalPath;
      if (routePath === "/feature/eaas" || routePath === "/feature/partner" || routePath === "/feature/agreement" || routePath === "/feature/monitor") {
        $scope.menuName = "Feature";
      }
      if (routePath === "/home") {
        return $scope.menuName = "Home";
      }
    });
    $scope.menuName = "Home";
    $scope.changeMenu = function(menuName) {
      return $scope.menuName = menuName;
    };
    $scope.loginShow = function() {
      $scope.showError = false;
      $scope.error = '';
      $rootScope.__loginAfter = false;
      $rootScope.__login = true;
      $rootScope.__logoff = false;
      $rootScope.__featurePanel = false;
      return $scope.changeMenu('');
    };
    $scope.HomeShow = function() {
      $rootScope.__loginAfter = false;
      $rootScope.__login = false;
      $rootScope.__logoff = true;
      $rootScope.__featurePanel = false;
      return $scope.changeMenu('Home');
    };
    return $scope.login = function() {
      var ExpirationTimeSpan, ExpirationTimeUnit, aaa;
      $scope.submitting = true;
      $scope.showError = false;
      aaa = document.cookie;
      delete $http.defaults.headers.common['AuthorizationToken'];
      $.removeCookie('eaas-auth-token');
      $.removeCookie('eaas-auth-user');
      $.removeCookie('eaas-agent-auth-token');
      common.clearUserInfo();
      if ($scope.user.IsRememberMe) {
        ExpirationTimeUnit = 'Day';
        ExpirationTimeSpan = 30;
      } else {
        ExpirationTimeUnit = 'Day';
        ExpirationTimeSpan = 1;
      }
      return authAPI.request({
        action: 'login',
        loginName: $scope.user.UserName,
        password: $scope.user.Password,
        expirationTimeUnit: ExpirationTimeUnit,
        expirationTimeSpan: ExpirationTimeSpan
      }, function(result) {
        var date, failereResult, minutes;
        $scope.showLoading = false;
        if (result && result.Succeeded && result.Status === 'Successful') {
          $rootScope.UserAgent.chooseAgent = true;
          $scope.submitting = false;
          common.currentUser = result.AccountList[0];
          common.currentOrganization = null;
          common.LogoutReset();
          date = new Date();
          minutes = 1;
          if ($scope.user.IsRememberMe) {
            minutes = 43200;
          } else {
            minutes = 1440;
            $scope.user.UserName = null;
          }
          date.setTime(date.getTime() + (minutes * 60 * 1000));
          common.currentUser.loginExpireMinute = minutes;
          common.currentUser.loginExpireDate = date;
          $.cookie('eaas-auth-token', result.AuthorizationToken, {
            expires: date,
            path: '/'
          });
          $http.defaults.headers.common['AuthorizationToken'] = result.AuthorizationToken;
          $http.defaults.cache = false;
          if (!$http.defaults.headers.get) {
            $http.defaults.headers.get = {};
          }
          $http.defaults.headers.get['If-Modified-Since'] = 'Sat, 28 Nov 2009 01:00:00 GMT';
          common.currentUser.UserRole = common.currentUser.Type;
          if (common.currentUser.UserRole === 'Partner') {
            common.loadStationIDListByCurrentUser(common.currentUser);
          }
          $.cookie('eaas-auth-user', JSON.stringify(common.currentUser), {
            expires: date,
            path: '/'
          });
          $scope.user.Password = '';
          $rootScope.__systemSetting = {};
          $rootScope.__systemSetting.hiddenMenu = true;
          $rootScope.__systemSetting.theme = 'ace';
          if (common.currentUser.Type === common.userRole.superUser) {
            $rootScope.UserAgent.chooseAgent = false;
            common.navigate('organization');
            $rootScope.$broadcast("loginSuccessed");
          }
          if (common.currentUser && common.currentUser.Type !== common.userRole.superUser && common.currentUser.OrganizationID) {
            return organizationAPI.search({
              id: null
            }, function(result) {
              if (result && result.Succeeded && result.OrganizationList && result.OrganizationList.length > 0) {
                common.currentOrganization = result.OrganizationList[0];
                $rootScope.$broadcast("loginSuccessed");
                return $location.path('/');
              } else {
                common.ShowAPIError('Login failed.', result);
                common.clearUserInfo();
                return $location.path('/home');
              }
            }, function(error) {
              var errorMsg;
              errorMsg = null;
              if (error.data) {
                errorMsg = error.data;
              }
              if (error.Data) {
                errorMsg = error.Data;
              }
              common.ShowAPIError('Login failed.', errorMsg);
              common.clearUserInfo();
              return $location.path('/home');
            });
          }
        } else {
          $scope.submitting = false;
          $scope.backPwd = $scope.user.Password;
          $scope.user.Password = '';
          failereResult = result;
          if (result.FailureReason === "AlreadyLogin") {
            $scope.user.Password = $scope.backPwd;
            return authAPI.request({
              action: 'logout'
            }, function(result) {
              if (result && result.Succeeded) {
                return $scope.login();
              } else {
                return common.ShowAPIError('Logout failed.', failereResult);
              }
            }, function(error) {
              return common.ShowAPIError('Logout failed.', failereResult);
            });
          } else {
            return common.ShowAPIError('Login failed.', failereResult);
          }
        }
      }, function(error) {
        var errorMsg;
        $scope.user.Password = '';
        if (error.data) {
          errorMsg = error.data;
        }
        if (error.Data) {
          errorMsg = error.Data;
        }
        return common.ShowAPIError('Login failed, please contact eaas administrator.', errorMsg);
      });
    };
  }
]);
