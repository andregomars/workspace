﻿(function() {

  angular.module("framework-ctrl-global-search", []).controller('GlobalSearchCtrl', [
    "$scope", "$http", "$location", "authorize", function($scope, $http, $location, authorize) {
      $scope.$on("loginSuccessed", function() {
        $scope.globalSearch = authorize.globalSearch;
        if (authorize.globalSearch.length > 0) {
          $scope.globalSearch = authorize.globalSearch;
          $scope.selectedItem = $scope.globalSearch[0];
          return $scope.displayUrl = $scope.globalSearch[0].url;
        }
      });
      if ($scope.__loginAfter) {
        if ((authorize.globalSearch != null) && authorize.globalSearch.length > 0) {
          $scope.globalSearch = authorize.globalSearch;
          $scope.selectedItem = $scope.globalSearch[0];
          $scope.displayUrl = $scope.globalSearch[0].url;
        }
      }
      $scope.search = function(url, search) {
        if (!url) {
          return;
        }
        if (search) {
          return $location.url("" + url + "?id=" + search);
        } else {
          return $location.path(url);
        }
      };
      $scope.enter = function(url, search, $event) {
        if ($event.which === 13) {
          return $scope.search(url, search);
        }
      };
      return $scope.select = function(item) {
        $scope.displayUrl = item.url;
        return $scope.selectedItem = item;
      };
    }
  ]);

}).call(this);
