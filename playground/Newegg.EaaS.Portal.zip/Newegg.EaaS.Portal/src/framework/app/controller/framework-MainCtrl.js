﻿
angular.module("framework-ctrl-main", []).controller('MainCtrl', [
  "$scope", "$rootScope", "$http", "$location", "authorize", "noticeCenter", function($scope, $rootScope, $http, $location, authorize, noticeCenter) {
    $scope.$on("loginSuccessed", function() {
      var url;
      noticeCenter.start();
      $rootScope.__loginAfter = true;
      $rootScope.__login = false;
      $rootScope.__logoff = false;
      $rootScope.__featurePanel = false;
      url = $scope.__returnUrl;
      if (url) {
        $scope.__returnUrl = null;
        $location.path(url).replace();
      } else if ($location.path() === '/home') {
        $location.path('/').replace();
      }
      return $scope.__themePath = '/framework/themes/ace/index.html';
    });
    $scope.$on("logoutSuccessed", function() {
      noticeCenter.end();
      $rootScope.__loginAfter = false;
      $rootScope.__login = false;
      $rootScope.__logoff = true;
      $rootScope.__featurePanel = false;
      return $scope.__themePath = '/framework/themes/ace/index.html';
    });
    return $scope.$on('loginExpired', function() {
      $rootScope.__loginAfter = false;
      $rootScope.__login = true;
      $rootScope.__logoff = false;
      $rootScope.__featurePanel = false;
      return $scope.__themePath = '/framework/themes/ace/index.html';
    });
  }
]);
