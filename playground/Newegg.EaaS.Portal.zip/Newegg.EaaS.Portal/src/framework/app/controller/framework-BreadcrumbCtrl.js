﻿
angular.module("framework-ctrl-breadcrumb", []).controller('BreadcrumbCtrl', [
  "$scope", "$rootScope", "$location", "$window", "userProfile", "$route", function($scope, $rootScope, $location, $window, userProfile, $route) {
    $scope.$on("loginSuccessed", function() {
      return $scope.links = userProfile.get("favor-link") || [];
    });
    if ($scope.__loginAfter) {
      $scope.links = userProfile.get("favor-link") || [];
    }
    $scope.toggle = function() {
      var i, isExist, item, _i, _len, _ref;
      isExist = false;
      _ref = $scope.links;
      for (i = _i = 0, _len = _ref.length; _i < _len; i = ++_i) {
        item = _ref[i];
        if (!(item === $scope.breads[$scope.breads.length - 1].Url)) {
          continue;
        }
        isExist = true;
        $scope.links.splice(i, 1);
        break;
      }
      if (!isExist) {
        $scope.links.push($scope.breads[$scope.breads.length - 1].Url);
      }
      userProfile.set("favor-link", $scope.links);
      return $rootScope.$broadcast("favorLinkChanged");
    };
    $scope.$on("routePathCompleted", function(event, routePath) {
      $scope.breads = routePath;
      $scope.isShow = (routePath != null) && routePath.length > 0;
      return $scope.isExist = function() {
        var item, _i, _len, _ref;
        if (!($scope.links != null) || $scope.links.length === 0 || !($scope.breads != null) || $scope.breads.length === 0) {
          return false;
        }
        _ref = $scope.links;
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          item = _ref[_i];
          if (item === $scope.breads[$scope.breads.length - 1].Url) {
            return true;
          }
        }
        return false;
      };
    });
    return $scope.$on("editLastBreadCrumb", function(event, lastbread) {
      var lan, newbread;
      $scope.breads = $scope.breads || [];
      newbread = {};
      if (typeof lastbread === "string") {
        for (lan in NEG.languages) {
          newbread[lan] = lastbread;
        }
      } else {
        for (lan in NEG.languages) {
          newbread[lan] = lastbread[lan];
        }
      }
      if ($scope.breads.length > 0) {
        $scope.breads.pop();
      }
      return $scope.breads.push(newbread);
    });
  }
]);
