﻿
angular.module("framework-ctrl", ["framework-ctrl-main", "framework-ctrl-login", "framework-ctrl-sidebar", "framework-ctrl-header", "framework-ctrl-breadcrumb", "framework-ctrl-global-search"]);
