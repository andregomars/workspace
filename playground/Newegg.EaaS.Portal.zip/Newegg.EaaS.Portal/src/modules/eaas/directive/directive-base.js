﻿(function() {

  angular.module('eaas-directive', ['edAuth', 'edSpace', 'edBelongTo', 'edOwnerTitle', 'edSearch', 'edEnter', 'edChooseStationIdentity', 'edEditInfo', 'edChevron', 'edObjectNotExist', 'edChartSetting', 'edView']);

}).call(this);
