﻿(function() {

  angular.module("edEnter", ['eaas-cache-common']).directive('edEnter', [
    "common", function(common) {
      return {
        link: function(scope, element, attrs) {
          debugger;          element.bind("keydown keypress", function(event) {
            if (event.which === 13) {
              scope.$apply(function() {
                scope.$eval(attrs.ngEnter);
              });
              event.preventDefault();
            }
          });
        }
      };
    }
  ]);

}).call(this);
