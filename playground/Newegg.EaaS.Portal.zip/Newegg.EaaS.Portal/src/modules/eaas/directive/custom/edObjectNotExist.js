﻿(function() {

  angular.module("edObjectNotExist", ['eaas-cache-common', 'ngSanitize']).directive('edObjectNotExist', [
    "common", function(common) {
      return {
        restrict: 'E',
        scope: {
          errorTitle: '='
        },
        template: '\
  <div class="well">\
    <h1 class="grey lighter smaller">\
        <span class="blue bigger-120">\
            <i class="icon-remove-sign eaas-icon-red"></i>\
        </span>\
        <span class="eaas-icon-red">This {{errorTitle}} in our system no longer exists.</span>\
    </h1>\
\
     <hr>\
    <div class="space"></div>\
\
    <div class="center">        \
        <button class="btn btn-grey" type="button" ng-click="common.back()">\
        <i class="icon-reply bigger-120"></i>\
        Back\
        </button>\
    </div>\
    </div>\
    ',
        controller: function($scope, $sce) {
          $scope.common = common;
          return null;
        },
        link: function($scope, element, attrs, $sce) {
          return null;
        }
      };
    }
  ]);

}).call(this);
