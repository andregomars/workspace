﻿(function() {

  angular.module("edBelongTo", ['eaas-service']).directive('edEditBelongTo', [
    "common", 'organizationAPI', 'partnerAPI', 'stationAPI', function(common, organizationAPI, partnerAPI, stationAPI) {
      return {
        restrict: 'E',
        scope: {
          ownerType: '=',
          ownerId: '=',
          ownerOrganizationId: '=',
          ownerPartnerId: '=',
          ownerStationId: '=',
          promise: '=',
          ownerChanged: '&',
          beginInitialize: '=',
          enableChooseOrgan: '=',
          enableChoosePartner: '=',
          enableChooseStation: '=',
          beginSetOwnerInfo: '=',
          viewMode: '=',
          setOwnerByUserRole: '=',
          descriptionLabel: '=',
          account: '='
        },
        template: '<div ng-show="!isView">\
            <h3 class="header">\
                <span class="eaas-title">Belongs To</span>\
            </h3>                          \
\
             <label class="eaas-document-title-description eaas-document-title-description-closeto-top" ng-show="ownerDeleted">\
                <i class="icon-hand-right" style="color: #7d7b7b"></i>\
                <span class="eaas-message-warning">Owner object has been deleted.</span>\
            </label>    \
             <label class="eaas-document-title-description eaas-document-title-description-closeto-top" ng-show="descriptionLabel">\
                <i class="icon-hand-right" style="color: #7d7b7b"></i>\
                <span >{{ descriptionLabel }}</span>\
           </label>\
            <div class="form-group clearfix">\
                <label class="col-sm-3  control-label no-padding-right text-right">Organization:</label>\
                <div class="col-sm-9 col-xs-12">\
                    <div class="clearfix" ng-show="!hasOrgan&&!loadOrgan">\
                        <select name="userOrganization"\
                            maxlength="30"\
                            ng-disabled="!chooseOrgan"\
                            ng-model="organId"\
                            ng-options="organ.Id as organ.Name for organ in organList"\
                            ng-change="organChanged()"\
                            class="col-sm-7 col-xs-12 no-padding-left" />\
                    </div>\
                    <div class="clearfix" ng-show="hasOrgan">\
                        <label class="eaas-document-label" style="padding-top: 4px">{{ common.currentOrganization.Name }}</label>\
                    </div>\
                    <i class="icon-spinner icon-spin eaas-loading-small" ng-show="loadOrgan" ></i>\
                </div>\
            </div>\
            <div class="form-group clearfix">\
                <label class="control-label col-sm-3 no-padding-right text-right">Local Partner:</label>\
                <div class="col-sm-9 col-xs-12">\
                    <div class="clearfix" ng-show="orignalStationList && orignalStationList.length>0&&!hasPartner">\
                        <select name="localpartner"\
                            maxlength="30"\
                            ng-disabled="!choosePartner"\
                            ng-model="partnerId"\
                            ng-options="partner.Id as partner.Name for partner in partnerList"\
                            ng-change="partnerChanged()"\
                            class="col-sm-7 col-xs-12 no-padding-left" />\
                    </div>\
                    <i class="icon-spinner icon-spin eaas-loading-small" ng-show="belongTo_PartnerLoading" ></i>\
                    <div class="clearfix" ng-show="hasPartner">\
                        <label class="eaas-document-label" style="padding-top: 4px">{{ partnerName }}</label>\
                    </div>\
                </div>\
            </div>\
            <div class="form-group clearfix">\
                <label class="control-label col-sm-3 no-padding-right text-right">Station:</label>\
                <div class="col-sm-9 col-xs-12">\
                    <div class="clearfix" ng-show="orignalStationList && orignalStationList.length>0&&!hasStation">\
                        <select name="station"\
                            ng-disabled="!chooseStation"\
                            maxlength="30"\
                            ng-model="stationId"\
                            ng-options="station.Id as station.Name for station in stationList"\
                            ng-change="stationChanged()"\
                            class="col-sm-7 col-xs-12 no-padding-left" />\
                    </div>\
                     <i class="icon-spinner icon-spin eaas-loading-small" ng-show="belongTo_StationLoading" ></i>\
                     <div class="clearfix" ng-show="hasStation">\
                        <label class="eaas-document-label" style="padding-top: 4px">{{ stationName }}</label>\
                    </div>\
                </div>\
            </div>\
        </div>\
        \
\
        <div ng-show="isView&&isLoadViewComplete&&!ownerDeleted">\
            <h3 class="header">\
                <span class="eaas-title">Belongs To</span>\
            </h3>\
            <label class="eaas-document-title-description eaas-document-title-description-closeto-top" ng-show="ownerDeleted">\
                <i class="icon-hand-right" style="color: #7d7b7b"></i>\
                <span>Owner object has been deleted.</span>\
            </label>    \
            <div ng-show="!ownerDeleted">\
                <div class="clearfix eaas-document-formgroup" ng-show="organViewName">\
                    <label class="col-sm-5 eaas-document-label-title text-right control-label">Organization:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{organViewName}}</label>\
                        </div>\
                    </div>\
                </div>\
\
                <div class="clearfix eaas-document-formgroup" ng-show="partnerViewName">\
                    <label class="col-sm-5 eaas-document-label-title text-right control-label">Local Partner:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{partnerViewName}}</label>\
                        </div>\
                    </div>\
                </div>\
\
                <div class="clearfix eaas-document-formgroup" ng-show="stationViewName">\
                    <label class="col-sm-5 eaas-document-label-title text-right control-label">Station:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{stationViewName}}</label>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>\
        ',
        controller: function($scope) {
          $scope.common = common;
          $scope.belongTo_PartnerLoading = true;
          $scope.belongTo_StationLoading = true;
          $scope.chooseOrgan = true;
          $scope.choosePartner = true;
          $scope.chooseStation = true;
          $scope.isView = false;
          $scope.isLoadViewComplete = false;
          $scope.autoSetOwnerInfo = false;
          $scope.loadDataComplete = false;
          $scope.hasPartner = false;
          $scope.hasStation = false;
          $scope.loadOrgan = true;
          $scope.backOwnerType = null;
          $scope.backOwnerId = null;
          $scope.deletedId = 65535;
          $scope.deletedName = 'Not Found';
          $scope.setOrganOwner = function() {
            if ($scope.autoSetOwnerInfo === false) {
              return;
            }
            if ($scope.organId === $scope.deletedId) {
              $scope.ownerId = $scope.backOwnerId;
              $scope.ownerType = $scope.backOwnerType;
              return $scope.revertAccountInfo();
            } else if ($scope.organId !== -1) {
              $scope.ownerOrganizationId = $scope.organId;
              $scope.ownerType = common.ownerType.organization;
              $scope.ownerId = $scope.organId;
              $scope.ownerPartnerId = null;
              return $scope.ownerStationId = null;
            } else {
              $scope.ownerOrganizationId = null;
              $scope.ownerPartnerId = null;
              $scope.ownerStationId = null;
              $scope.ownerType = null;
              return $scope.ownerId = null;
            }
          };
          $scope.setPartnerOwner = function() {
            if ($scope.autoSetOwnerInfo === false) {
              return;
            }
            if ($scope.partnerId === $scope.deletedId) {
              $scope.ownerId = $scope.backOwnerId;
              $scope.ownerType = $scope.backOwnerType;
              return $scope.revertAccountInfo();
            } else if ($scope.partnerId !== -1) {
              $scope.ownerPartnerId = $scope.partnerId;
              $scope.ownerId = $scope.partnerId;
              $scope.ownerType = common.ownerType.partner;
              return $scope.ownerStationId = null;
            } else {
              $scope.ownerPartnerId = null;
              return $scope.setOrganOwner();
            }
          };
          $scope.setStationOwner = function() {
            if ($scope.autoSetOwnerInfo === false) {
              return;
            }
            if ($scope.stationId === $scope.deletedId) {
              $scope.ownerId = $scope.backOwnerId;
              $scope.ownerType = $scope.backOwnerType;
              return $scope.revertAccountInfo();
            } else if ($scope.stationId !== -1) {
              $scope.ownerStationId = $scope.stationId;
              $scope.ownerId = $scope.stationId;
              return $scope.ownerType = common.ownerType.station;
            } else {
              $scope.ownerStationId = null;
              return $scope.setPartnerOwner();
            }
          };
          $scope.revertAccountInfo = function() {
            if ($scope.account) {
              $scope.ownerOrganizationId = $scope.account.OrganizationID;
              $scope.ownerPartnerId = $scope.account.PartnerID;
              return $scope.ownerStationId = $scope.account.StationID;
            }
          };
          $scope.stationChanged = function() {
            return $scope.setStationOwner();
          };
          $scope.partnerChanged = function() {
            var index;
            $scope.stationList = [];
            for (index in $scope.orignalStationList) {
              if ($scope.orignalStationList[index].PartnerID === $scope.partnerId) {
                $scope.stationList.push($scope.orignalStationList[index]);
              }
            }
            if ($scope.partnerId !== $scope.deletedId) {
              $scope.stationList.splice(0, 0, {
                Id: -1,
                Name: ''
              });
            }
            if ($scope.stationList.length > 0) {
              $scope.stationId = $scope.stationList[0].Id;
            }
            return $scope.setPartnerOwner();
          };
          $scope.organChanged = function() {
            var index;
            $scope.partnerList = [];
            for (index in $scope.orignalPartnerList) {
              if ($scope.orignalPartnerList[index].OrganizationID === $scope.organId) {
                $scope.partnerList.push($scope.orignalPartnerList[index]);
              }
            }
            if ($scope.organId !== $scope.deletedId) {
              $scope.partnerList.splice(0, 0, {
                Id: -1,
                Name: ''
              });
            }
            if ($scope.partnerList.length > 0) {
              $scope.partnerId = $scope.partnerList[0].Id;
            }
            $scope.setOrganOwner();
            return $scope.partnerChanged();
          };
          $scope.findOwnerInfo = function(list, id) {
            var index, ownerObj;
            ownerObj = null;
            for (index in list) {
              if (list[index].Id === id) {
                ownerObj = list[index];
                break;
              }
            }
            return ownerObj;
          };
          $scope.setViewOrgan = function(organId) {
            var organ;
            if ($scope.organList && $scope.organList.length > 0) {
              organ = $scope.findOwnerInfo($scope.organList, organId);
              if (organ === null) {
                return $scope.ownerDeleted = true;
              } else {
                return $scope.organViewName = organ.Name;
              }
            } else {
              if (organId !== common.currentOrganization.Id) {
                return $scope.ownerDeleted = true;
              } else {
                return $scope.organViewName = common.currentOrganization.Name;
              }
            }
          };
          $scope.setViewPartner = function(partnerId) {
            var partner;
            partner = $scope.findOwnerInfo($scope.orignalPartnerList, partnerId);
            if (partner === null) {
              return $scope.ownerDeleted = true;
            } else {
              $scope.setViewOrgan(partner.OrganizationID);
              if (!$scope.ownerDeleted) {
                return $scope.partnerViewName = partner.Name;
              }
            }
          };
          $scope.setViewStation = function(stationId) {
            var station;
            station = $scope.findOwnerInfo($scope.orignalStationList, stationId);
            if (station === null) {
              return $scope.ownerDeleted = true;
            } else {
              $scope.setViewPartner(station.PartnerID);
              if (!$scope.ownerDeleted) {
                return $scope.stationViewName = station.Name;
              }
            }
          };
          $scope.setOwnerInfo = function() {
            var organ, partner, station;
            if ($scope.isView) {
              if ($scope.ownerType === common.ownerType.organization) {
                $scope.setViewOrgan($scope.ownerId);
              }
              if ($scope.ownerType === common.ownerType.partner) {
                $scope.setViewPartner($scope.ownerId);
              }
              if ($scope.ownerType === common.ownerType.station) {
                $scope.setViewStation($scope.ownerId);
              }
              return $scope.isLoadViewComplete = true;
            } else {
              if ($scope.autoSetOwnerInfo === false) {
                if ($scope.ownerType === common.ownerType.organization) {
                  if ($scope.organList && $scope.organList.length > 0) {
                    organ = $scope.findOwnerInfo($scope.organList, $scope.ownerId);
                    if (!organ) {
                      $scope.ownerDeleted = true;
                      $scope.organId = $scope.organList[0].Id;
                      $scope.autoSetOwnerInfo = true;
                      $scope.organChanged();
                    } else {
                      $scope.organId = $scope.ownerId;
                      $scope.organChanged();
                    }
                  } else {
                    if ($scope.ownerId !== common.currentOrganization.Id) {
                      $scope.ownerDeleted = true;
                      $scope.organId = $scope.organList[0].Id;
                      $scope.autoSetOwnerInfo = true;
                      $scope.organChanged();
                    } else {
                      $scope.organId = $scope.ownerId;
                      $scope.organChanged();
                    }
                  }
                }
                if ($scope.ownerType === common.ownerType.partner) {
                  partner = $scope.findOwnerInfo($scope.orignalPartnerList, $scope.ownerId);
                  if (!partner) {
                    $scope.ownerDeleted = true;
                    if ($scope.hasOrgan) {
                      $scope.organId = common.currentOrganization.Id;
                      $scope.ownerOrganizationId = $scope.organId;
                      $scope.organChanged();
                      if ($scope.hasPartner && common.currentUser.PartnerID) {
                        partner = $scope.findOwnerInfo($scope.orignalPartnerList, common.currentUser.PartnerID);
                        if (partner) {
                          $scope.partnerName = partner.Name;
                          $scope.partnerId = common.currentUser.PartnerID;
                          $scope.ownerPartnerId = common.currentUser.PartnerID;
                          $scope.partnerChanged();
                        }
                      }
                    } else {
                      $scope.organId = $scope.organList[0].Id;
                      $scope.organChanged();
                    }
                    $scope.handleNotFoundOwner();
                  } else {
                    if ($scope.hasPartner) {
                      $scope.partnerName = partner.Name;
                    }
                    $scope.organId = partner.OrganizationID;
                    $scope.ownerOrganizationId = $scope.organId;
                    $scope.organChanged();
                    $scope.partnerId = $scope.ownerId;
                    $scope.ownerPartnerId = $scope.ownerId;
                    $scope.partnerChanged();
                  }
                }
                if ($scope.ownerType === common.ownerType.station) {
                  station = $scope.findOwnerInfo($scope.orignalStationList, $scope.ownerId);
                  if (!station) {
                    $scope.ownerDeleted = true;
                    if ($scope.hasOrgan) {
                      $scope.organId = common.currentOrganization.Id;
                      $scope.ownerOrganizationId = $scope.organId;
                      $scope.organChanged();
                      if ($scope.hasPartner && common.currentUser.PartnerID) {
                        partner = $scope.findOwnerInfo($scope.orignalPartnerList, common.currentUser.PartnerID);
                        if (partner) {
                          $scope.partnerName = partner.Name;
                          $scope.partnerId = common.currentUser.PartnerID;
                          $scope.ownerPartnerId = common.currentUser.PartnerID;
                          $scope.partnerChanged();
                        }
                      }
                    } else {
                      $scope.organId = $scope.organList[0].Id;
                      $scope.organChanged();
                    }
                    $scope.handleNotFoundOwner();
                  } else {
                    if ($scope.hasStation) {
                      $scope.stationName = station.Name;
                    }
                    if ($scope.hasPartner) {
                      partner = $scope.findOwnerInfo($scope.orignalPartnerList, station.PartnerID);
                      if (partner) {
                        $scope.partnerName = partner.Name;
                      }
                    }
                    $scope.organId = station.OrganizationID;
                    $scope.ownerOrganizationId = $scope.organId;
                    $scope.organChanged();
                    $scope.partnerId = station.PartnerID;
                    $scope.ownerPartnerId = $scope.partnerId;
                    $scope.partnerChanged();
                    $scope.stationId = $scope.ownerId;
                    $scope.ownerStationId = $scope.stationId;
                    $scope.stationChanged();
                  }
                }
                return $scope.autoSetOwnerInfo = true;
              }
            }
          };
          $scope.handleNotFoundOwner = function() {
            var organ, partner, station;
            $scope.backOwnerType = $scope.ownerType;
            $scope.backOwnerId = $scope.ownerId;
            if ($scope.hasOrgan && !$scope.account) {
              if ($scope.hasPartner && common.currentUser.PartnerID) {
                $scope.stationList.splice(1, 0, {
                  Id: $scope.deletedId,
                  Name: $scope.deletedName,
                  PartnerID: $scope.deletedId
                });
                return $scope.stationId = $scope.deletedId;
              } else {
                if ($scope.ownerType === common.ownerType.station) {
                  $scope.orignalStationList.push({
                    Id: $scope.deletedId,
                    Name: $scope.deletedName,
                    PartnerID: $scope.deletedId
                  });
                  $scope.orignalPartnerList.push({
                    Id: $scope.deletedId,
                    Name: $scope.deletedName,
                    OrganizationID: $scope.organId
                  });
                  $scope.partnerList.splice(1, 0, {
                    Id: $scope.deletedId,
                    Name: $scope.deletedName,
                    OrganizationID: $scope.organId
                  });
                  $scope.partnerId = $scope.deletedId;
                  return $scope.partnerChanged();
                } else if ($scope.ownerType === common.ownerType.partner) {
                  $scope.orignalPartnerList.push({
                    Id: $scope.deletedId,
                    Name: $scope.deletedName,
                    OrganizationID: $scope.organId
                  });
                  $scope.partnerList.splice(1, 0, {
                    Id: $scope.deletedId,
                    Name: $scope.deletedName,
                    OrganizationID: $scope.organId
                  });
                  $scope.partnerId = $scope.deletedId;
                  return $scope.partnerChanged();
                }
              }
            } else {
              if ($scope.account) {
                $scope.revertAccountInfo();
                if ($scope.account.OrganizationID) {
                  if ($scope.hasOrgan) {
                    organ = common.currentOrganization;
                  } else {
                    organ = $scope.findOwnerInfo($scope.organList, $scope.account.OrganizationID);
                  }
                  if (!organ) {
                    $scope.organList.splice(1, 0, {
                      Id: $scope.deletedId,
                      Name: $scope.deletedName
                    });
                    $scope.organId = $scope.deletedId;
                    return $scope.organChanged();
                  } else {
                    $scope.organId = $scope.account.OrganizationID;
                    $scope.organChanged();
                    if ($scope.account.PartnerID) {
                      partner = $scope.findOwnerInfo($scope.orignalPartnerList, $scope.account.PartnerID);
                      if (!partner) {
                        $scope.orignalPartnerList.splice(1, 0, {
                          Id: $scope.deletedId,
                          Name: $scope.deletedName,
                          OrganizationID: $scope.organId
                        });
                        $scope.partnerList.splice(1, 0, {
                          Id: $scope.deletedId,
                          Name: $scope.deletedName,
                          OrganizationID: $scope.organId
                        });
                        $scope.partnerId = $scope.deletedId;
                        return $scope.partnerChanged();
                      } else {
                        $scope.partnerId = $scope.account.PartnerID;
                        $scope.partnerChanged();
                        if ($scope.account.StationID) {
                          station = $scope.findOwnerInfo($scope.orignalStationList, $scope.account.StationID);
                          if (!station) {
                            $scope.stationList.splice(1, 0, {
                              Id: $scope.deletedId,
                              Name: $scope.deletedName,
                              PartnerID: $scope.partnerId
                            });
                            $scope.orignalStationList.push({
                              Id: $scope.deletedId,
                              Name: $scope.deletedName,
                              PartnerID: $scope.partnerId
                            });
                            return $scope.stationId = $scope.deletedId;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          };
          $scope.getStationInfo = function() {
            var organId;
            organId = $scope.organId;
            if ($scope.organId === -1) {
              organId = null;
            }
            return stationAPI.search({
              contact: false,
              schema: false,
              customsettingvalue: false,
              organizationid: organId
            }, function(result) {
              $scope.belongTo_StationLoading = false;
              if (result && result.Succeeded) {
                $scope.orignalStationList = result.StationList;
                $scope.partnerChanged();
                $scope.loadDataComplete = true;
                $scope.setUserRole();
                return $scope.setOwnerInfo();
              }
            });
          };
          $scope.getPartnerInfo = function() {
            var organId;
            organId = $scope.organId;
            if ($scope.organId === -1) {
              organId = null;
            }
            return partnerAPI.search({
              contact: false,
              certificate: false,
              station: false,
              organizationid: organId
            }, function(result) {
              var index;
              $scope.belongTo_PartnerLoading = false;
              if (result && result.Succeeded) {
                $scope.partnerList = [];
                $scope.orignalPartnerList = [];
                for (index in result.PartnerList) {
                  if (result.PartnerList[index].Type === 'Local') {
                    $scope.partnerList.push(result.PartnerList[index]);
                    $scope.orignalPartnerList.push(result.PartnerList[index]);
                  }
                }
                $scope.organChanged();
                return $scope.getStationInfo();
              }
            });
          };
          $scope.getOrganizationInfo = function(organId) {
            if (organId === -1) {
              organId = null;
            }
            return organizationAPI.search({
              Id: organId
            }, function(result) {
              $scope.loadOrgan = false;
              if (result && result.Succeeded) {
                $scope.organList = result.OrganizationList;
                $scope.organList.splice(0, 0, {
                  Id: -1,
                  Name: ''
                });
                $scope.organId = $scope.organList[0].Id;
                $scope.setOrganOwner();
                return $scope.getPartnerInfo();
              }
            });
          };
          $scope.initialize = function() {
            $scope.loadOrgan = true;
            if (common.currentUser.Type === common.userRole.superUser && !common.currentOrganization) {
              $scope.hasOrgan = false;
              return $scope.getOrganizationInfo(null);
            } else {
              $scope.hasOrgan = true;
              $scope.loadOrgan = false;
              $scope.organId = common.currentOrganization.Id;
              $scope.setOrganOwner();
              return $scope.getPartnerInfo();
            }
          };
          $scope.setUserRole = function() {
            if (common.currentUser.Type === common.ownerType.organization || (common.currentUser.Type === common.userRole.superUser && common.currentOrganization)) {
              $scope.chooseOrgan = false;
              if ($scope.setOwnerByUserRole) {
                $scope.ownerId = common.currentUser.OrganizationID;
                $scope.ownerType = common.ownerType.organization;
              }
            }
            if (common.currentUser.Type === common.ownerType.partner) {
              if ($scope.setOwnerByUserRole) {
                $scope.ownerId = common.currentUser.PartnerID;
                $scope.ownerType = common.ownerType.partner;
                $scope.autoSetOwnerInfo = false;
              }
              $scope.choosePartner = false;
              $scope.hasPartner = true;
            }
            if (common.currentUser.Type === common.ownerType.station) {
              if ($scope.setOwnerByUserRole) {
                $scope.ownerId = common.currentUser.StationID;
                $scope.ownerType = common.ownerType.station;
                $scope.autoSetOwnerInfo = false;
              }
              $scope.choosePartner = false;
              $scope.chooseStation = false;
              $scope.hasPartner = true;
              $scope.hasStation = true;
            }
            if (common.currentUser.Type === common.userRole.superUser && !common.currentOrganization) {
              if ($scope.setOwnerByUserRole) {
                $scope.ownerId = null;
                $scope.ownerType = null;
                return $scope.autoSetOwnerInfo = true;
              }
            }
          };
          $scope.$watch('beginInitialize', function(newVal, oldVal) {
            if (newVal === true) {
              return $scope.initialize();
            }
          });
          $scope.$watch('enableChoosePartner', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              return $scope.choosePartner = newVal;
            }
          });
          $scope.$watch('enableChooseStation', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              return $scope.chooseStation = newVal;
            }
          });
          $scope.$watch('enableChooseOrgan', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              return $scope.chooseOrgan = newVal;
            }
          });
          return $scope.$watch('viewMode', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              return $scope.isView = newVal;
            }
          });
        },
        link: function($scope, element, attrs) {
          var sd;
          sd = $scope.descriptionLabel;
          return null;
        }
      };
    }
  ]).directive('edSelectBelongTo', [
    "common", function(common) {
      return {
        restrict: 'E',
        scope: {
          item: '=',
          closeDialog: '&'
        },
        template: '<span class="align-middle">\
                        <div class="clearfix" ng-show="item.OwnerName == null">\
                            <i class="icon-spinner icon-spin eaas-loading-small"  ></i> \
                        </div>\
                         <div class="clearfix" ng-show="item.OwnerName == \'NotExist\'">\
                            <span class="eaas-message-warning">{{ ownerNotExist }}</span>\
                        </div>\
                        <div class="clearfix" ng-show="item.OwnerName && item.OwnerName != \'NotExist\'">\
                             {{ item.OwnerType }} \
                            <i class="icon-double-angle-right"></i>                     \
                            {{item.OwnerName}}\
                        </div>\
                    </span>',
        link: function($scope, element, attrs) {
          $scope.ownerNotExist = common.message.ownerNotExistNormal;
          if ($scope && $scope.item && $scope.item.OwnerID && !$scope.item.OwnerName) {
            common.RequestOwner($scope.item);
          }
          return $scope.navigateOwnerDetail = function(item) {
            $scope.closeDialog();
            return common.navigateOwnerDetail(item);
          };
        }
      };
    }
  ]).directive('edViewBelongToLabel', [
    "common", 'organizationAPI', 'partnerAPI', 'stationAPI', function(common, organizationAPI, partnerAPI, stationAPI) {
      return {
        restrict: 'E',
        scope: {
          ownerType: '=',
          ownerId: '=',
          promise: '=',
          beginInitialize: '=',
          columnClass: '='
        },
        template: '<div ng-show="isLoadViewComplete&&!ownerDeleted">\
            <h3 class="header">\
                <span class="eaas-title">Belongs To</span>\
            </h3>\
            <label class="eaas-document-title-description eaas-document-title-description-closeto-top" ng-show="ownerDeleted">\
                <i class="icon-hand-right" style="color: #7d7b7b"></i>\
                <span>Owner object has been deleted.</span>\
            </label>    \
            <div ng-show="!ownerDeleted">\
                <div class="clearfix eaas-document-formgroup" ng-show="organViewName">\
                    <label class="eaas-document-label-title text-right control-label" ng-class="{\'col-sm-5\':columnClass == undefined,\'col-sm-4\':columnClass == \'4\'}">Organization:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{organViewName}}</label>\
                        </div>\
                    </div>\
                </div>\
\
                <div class="clearfix eaas-document-formgroup" ng-show="partnerViewName">\
                    <label class="eaas-document-label-title text-right control-label" ng-class="{\'col-sm-5\':columnClass == undefined,\'col-sm-4\':columnClass == \'4\'}">Local Partner:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{partnerViewName}}</label>\
                        </div>\
                    </div>\
                </div>\
\
                <div class="clearfix eaas-document-formgroup" ng-show="stationViewName">\
                    <label class="eaas-document-label-title text-right control-label" ng-class="{\'col-sm-5\':columnClass == undefined,\'col-sm-4\':columnClass == \'4\'}">Station:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{stationViewName}}</label>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>',
        controller: function($scope) {
          $scope.common = common;
          $scope.isLoadViewComplete = false;
          $scope.getStationInfo = function(stationId) {
            return stationAPI.search({
              contact: false,
              schema: false,
              customsettingvalue: false,
              Id: stationId
            }, function(result) {
              if (result && result.Succeeded && result.StationList && result.StationList.length > 0) {
                $scope.stationViewName = result.StationList[0].Name;
                if ($scope.promise) {
                  return $scope.promise = $scope.getPartnerInfo(result.StationList[0].PartnerID);
                } else {
                  return $scope.getPartnerInfo(result.StationList[0].PartnerID);
                }
              } else {
                return $scope.ownerDeleted = true;
              }
            });
          };
          $scope.getPartnerInfo = function(partnerId) {
            return partnerAPI.search({
              contact: false,
              certificate: false,
              station: false,
              Id: partnerId
            }, function(result) {
              if (result && result.Succeeded && result.PartnerList && result.PartnerList.length > 0) {
                $scope.partnerViewName = result.PartnerList[0].Name;
                if ($scope.promise) {
                  return $scope.promise = $scope.getOrganizationInfo(result.PartnerList[0].OrganizationID);
                } else {
                  return $scope.getOrganizationInfo(result.PartnerList[0].OrganizationID);
                }
              } else {
                return $scope.ownerDeleted = true;
              }
            });
          };
          $scope.getOrganizationInfo = function(organId) {
            return organizationAPI.search({
              Id: organId
            }, function(result) {
              if (result && result.Succeeded && result.OrganizationList && result.OrganizationList.length > 0) {
                $scope.organViewName = result.OrganizationList[0].Name;
              } else {
                $scope.ownerDeleted = true;
              }
              return $scope.isLoadViewComplete = true;
            });
          };
          $scope.initialize = function() {
            if ($scope.ownerType === common.ownerType.organization) {
              if ($scope.promise) {
                $scope.promise = $scope.getOrganizationInfo($scope.ownerId);
              } else {
                $scope.getOrganizationInfo($scope.ownerId);
              }
            }
            if ($scope.ownerType === common.ownerType.partner) {
              if ($scope.promise) {
                $scope.promise = $scope.getPartnerInfo($scope.ownerId);
              } else {
                $scope.getPartnerInfo($scope.ownerId);
              }
            }
            if ($scope.ownerType === common.ownerType.station) {
              if ($scope.promise) {
                return $scope.promise = $scope.getStationInfo($scope.ownerId);
              } else {
                return $scope.getStationInfo($scope.ownerId);
              }
            }
          };
          return $scope.$watch('beginInitialize', function(newVal, oldVal) {
            if (newVal === true) {
              return $scope.initialize();
            }
          });
        },
        link: function($scope, element, attrs) {
          return null;
        }
      };
    }
  ]).directive('edViewBelongTo', [
    "common", 'organizationAPI', 'partnerAPI', 'stationAPI', function(common, organizationAPI, partnerAPI, stationAPI) {
      return {
        restrict: 'E',
        scope: {
          ownerType: '=',
          ownerId: '=',
          promise: '=',
          beginInitialize: '=',
          columnClass: '='
        },
        template: '\
  <div ng-show="isLoadViewComplete&&!ownerDeleted">\
                <div>\
                    <h3 class="header no-margin-top no-padding-top">\
                        <span class="eaas-title">Belongs To</span>\
                    </h3>\
                    <label class="eaas-document-title-description eaas-document-title-description-closeto-top" ng-show="ownerDeleted">\
                        <i class="icon-hand-right" style="color: #7d7b7b"></i>\
                        <span>Owner object has been deleted.</span>\
                    </label>    \
                </div>\
            <div class="clearfix" ng-show="!ownerDeleted">\
                <table class="table table-responsive" >\
                    <tbody>                        \
                        <tr ng-show="organViewName">\
                            <td class="eaas-document-table-border eaas-document-table-td-width-15 eaas-document-table-td-title">\
                                <label class="eaas-document-label-title eaas-document-label-title-bold">Organization</label>\
                            </td>\
                            <td class="eaas-document-table-border">\
                             <label class="eaas-document-label ">{{organViewName}}</label>\
                            </td>\
                        </tr>\
                         <tr ng-show="partnerViewName">\
                            <td class="eaas-document-table-border eaas-document-table-td-width-15 eaas-document-table-td-title">\
                                <label class="eaas-document-label-title eaas-document-label-title-bold">Local Partner</label>\
                            </td>\
                            <td class="eaas-document-table-border">\
                             <label class="eaas-document-label ">{{partnerViewName}}</label>\
                            </td>\
                        </tr>\
                         <tr ng-show="stationViewName">\
                            <td class="eaas-document-table-border eaas-document-table-td-width-15 eaas-document-table-td-title">\
                                <label class="eaas-document-label-title eaas-document-label-title-bold">Station</label>\
                            </td>\
                            <td class="eaas-document-table-border">\
                             <label class="eaas-document-label ">{{stationViewName}}</label>\
                            </td>\
                        </tr>\
\
                    </tbody>\
\
                    </table>\
            </div>\
        </div>',
        controller: function($scope) {
          $scope.common = common;
          $scope.isLoadViewComplete = false;
          $scope.getStationInfo = function(stationId) {
            return stationAPI.search({
              contact: false,
              schema: false,
              customsettingvalue: false,
              Id: stationId
            }, function(result) {
              if (result && result.Succeeded && result.StationList && result.StationList.length > 0) {
                $scope.stationViewName = result.StationList[0].Name;
                if ($scope.promise) {
                  return $scope.promise = $scope.getPartnerInfo(result.StationList[0].PartnerID);
                } else {
                  return $scope.getPartnerInfo(result.StationList[0].PartnerID);
                }
              } else {
                return $scope.ownerDeleted = true;
              }
            });
          };
          $scope.getPartnerInfo = function(partnerId) {
            return partnerAPI.search({
              contact: false,
              certificate: false,
              station: false,
              Id: partnerId
            }, function(result) {
              if (result && result.Succeeded && result.PartnerList && result.PartnerList.length > 0) {
                $scope.partnerViewName = result.PartnerList[0].Name;
                if ($scope.promise) {
                  return $scope.promise = $scope.getOrganizationInfo(result.PartnerList[0].OrganizationID);
                } else {
                  return $scope.getOrganizationInfo(result.PartnerList[0].OrganizationID);
                }
              } else {
                return $scope.ownerDeleted = true;
              }
            });
          };
          $scope.getOrganizationInfo = function(organId) {
            return organizationAPI.search({
              Id: organId
            }, function(result) {
              if (result && result.Succeeded && result.OrganizationList && result.OrganizationList.length > 0) {
                $scope.organViewName = result.OrganizationList[0].Name;
              } else {
                $scope.ownerDeleted = true;
              }
              return $scope.isLoadViewComplete = true;
            });
          };
          $scope.initialize = function() {
            if ($scope.ownerType === common.ownerType.organization) {
              if ($scope.promise) {
                $scope.promise = $scope.getOrganizationInfo($scope.ownerId);
              } else {
                $scope.getOrganizationInfo($scope.ownerId);
              }
            }
            if ($scope.ownerType === common.ownerType.partner) {
              if ($scope.promise) {
                $scope.promise = $scope.getPartnerInfo($scope.ownerId);
              } else {
                $scope.getPartnerInfo($scope.ownerId);
              }
            }
            if ($scope.ownerType === common.ownerType.station) {
              if ($scope.promise) {
                return $scope.promise = $scope.getStationInfo($scope.ownerId);
              } else {
                return $scope.getStationInfo($scope.ownerId);
              }
            }
          };
          return $scope.$watch('beginInitialize', function(newVal, oldVal) {
            if (newVal === true) {
              return $scope.initialize();
            }
          });
        },
        link: function($scope, element, attrs) {
          return null;
        }
      };
    }
  ]);

}).call(this);
