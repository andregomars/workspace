﻿
angular.module("edView", ['eaas-service']).directive('edTableView', [
  "common", function(common) {
    return {
      restrict: 'E',
      scope: {
        viewObject: '='
      },
      template: '<div ng-show="viewObject">\
            <div ng-hide="viewObject.hideMainTitle&&viewObject.hideMainTitle==true">\
                <h3 class="header no-margin-top no-padding-top" ng-show="!viewObject.isChildTitle">\
                    <span class="eaas-title">{{viewObject.title}}</span>\
                    <ed-Title-Edit-Info business-Object="viewObject" ></ed-Title-Edit-Info>\
                </h3>\
                <label class="eaas-document-title-description eaas-document-title-description-closeto-top" ng-show="viewObject.titleDescription&&!viewObject.isChildTitle">\
                    <i class="icon-hand-right"></i>\
                    <span>{{viewObject.titleDescription}}</span>\
                </label>    \
            \
                <div ng-show="viewObject.isChildTitle==true&&viewObject.showTitle==true">\
                    <span class="agreement-tab-title no-margin no-padding">\
                                                <i class="icon-cog"></i>&nbsp;&nbsp;{{viewObject.title}}\
                     </span>\
\
                    <br />                    \
                </div>\
            </div>\
            <div class="clearfix no-margin-top no-padding-top">\
        <table class="table table-responsive" style="margin-bottom:10px;">\
            <tbody>\
\
                <tr ng-repeat="viewAttr in viewObject.viewAttList" ng-show="viewAttr.value">\
                    <td class="eaas-document-table-border eaas-document-table-td-title" ng-class="{\'eaas-document-table-td-width-15\':viewObject.titleWidth == undefined,\'eaas-document-table-td-width-20\':viewObject.titleWidth == \'20\',\'eaas-document-table-td-width-25\':viewObject.titleWidth == \'25\',\'eaas-document-table-td-width-30\':viewObject.titleWidth == \'30\'}">\
                        <label class="eaas-document-label-title eaas-document-label-title-bold">{{viewAttr.title}}</label>\
                    </td>\
                    <td class="eaas-document-table-border" ng-show="!viewAttr.isSpecial" colspan="50">\
                     <label class="eaas-document-label ">{{viewAttr.value}}</label>\
                    </td>\
                    <td class="eaas-document-table-border" ng-show="viewAttr.statusView&&viewAttr.statusView==true" colspan="50">\
                            <span class="btn-colorpicker eaas-document-status"\
                                  ng-class="{\'eaas-status-successful\':viewAttr.value==\'Active\',\'eaas-status-failed\':viewAttr.value==\'Deactive\'}"\
                                  title="{{viewAttr.value}}"></span>\
                    </td>\
                      <td class="eaas-document-table-border" ng-show="viewAttr.statusCertificateView&&viewAttr.statusCertificateView==true" colspan="50">\
                            <span class="btn-colorpicker eaas-document-status"\
                                  ng-class="{\'eaas-status-successful\':viewAttr.value==\'Active\'||viewAttr.value==\'Valid\',\'eaas-status-failed\':viewAttr.value!=\'Active\'&&viewAttr.value!=\'Valid\'}"\
                                  title="{{viewAttr.value}}"></span>\
                    </td>\
                     <td class="eaas-document-table-border" ng-show="viewAttr.mailView&&viewAttr.mailView==true" colspan="50">\
                        <div style="padding-top:2px">\
                            <a ng-href="mailto:{{viewAttr.value}}" style="padding-left: 6px;" >{{ viewAttr.value }}</a>\
                        </div>\
                    </td>\
                    <td class="eaas-document-table-border " ng-show="viewAttr.downloadView&&viewAttr.downloadView==true" colspan="50">              \
                        <div style="padding-top:2px">              \
                                <a title="{{viewAttr.downloadTitle}}" target="_blank" style="padding-left: 6px;"  ng-href="{{viewAttr.url}}" ng-show="viewAttr.url">\
                                    {{viewAttr.value}}\
                                </a>\
                        </div>\
                    </td>\
                     <td class="eaas-document-table-border" ng-show="viewAttr.momentView&&viewAttr.momentView==true" colspan="50">\
                            <label class="eaas-document-label ">{{viewAttr.value | moment:\'YYYY-MM-DD HH:mm:ss\'}}</label>\
                    </td>\
                      <td class="eaas-document-table-border" ng-show="viewAttr.navigateView&&viewAttr.navigateView==true" colspan="50">                \
                            <div style="padding-top:2px">           \
                                <a href="#" style="padding-left: 6px;" ng-click="common.navigate(viewAttr.naviUrl,viewAttr.naviObj)">{{viewAttr.value}}</a>\
                            </div>\
                    </td>\
                    <td class="eaas-document-table-border" ng-show="viewAttr.checkBoxView&&viewAttr.checkBoxView==true" colspan="50">                \
                            <div style="padding-top:2px">       \
                                <i class="icon-ok eaas-icon-green" style="padding-left: 6px"></i>\
                               <label class="eaas-document-label ">   {{viewAttr.value}}</label>\
                            </div>\
                    </td>\
                    <td ng-repeat="viewMutipleAttr in viewAttr.viewMultipleAttList" class="eaas-document-table-border" ng-show="viewAttr.multipleAttrView&&viewAttr.multipleAttrView==true" colspan="{{viewMutipleAttr.colspan}}">                \
                            <div style="padding-top:2px" ng-show="viewMutipleAttr.viewModels&&viewMutipleAttr.viewModels==\'checkbox\'">       \
                                <i class="icon-ok eaas-icon-green" style="padding-left: 6px"></i>\
                               <label class="eaas-document-label ">   {{viewMutipleAttr.value}}</label>\
                            </div>\
                            <div style="padding-top:2px" ng-show="viewMutipleAttr.viewModels&&viewMutipleAttr.viewModels==\'normal\'">                                       \
                               <label class="eaas-document-label ">   {{viewMutipleAttr.value}}</label>\
                            </div>\
                    </td>\
                </tr>\
            </tbody>\
\
</table>\
\
    </div>\
\
\
\
        </div>\
        ',
      controller: function($scope) {
        return $scope.common = common;
      },
      link: function($scope, element, attrs) {
        return null;
      }
    };
  }
]);
