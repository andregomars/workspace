﻿(function() {

  angular.module("edSpace", ['eaas-cache-common']).directive('edSpace', [
    "common", function(common) {
      return {
        scope: {
          bindModel: '=',
          isAccount: '=',
          isCertificatePwd: '='
        },
        link: function($scope, element, attrs) {
          return $scope.$watch('bindModel', function(newVal, oldVal) {
            var tmpVal;
            if (newVal) {
              if ($scope.isAccount) {
                tmpVal = newVal.trim();
                return $scope.bindModel = tmpVal.replace(' ', '');
              } else if ($scope.isCertificatePwd) {
                tmpVal = newVal.trim();
                tmpVal = tmpVal.replace(' ', '');
                if (tmpVal === '') {
                  return $scope.bindModel = void 0;
                } else {
                  return $scope.bindModel = tmpVal;
                }
              } else {
                tmpVal = newVal.trim();
                if (tmpVal === '') {
                  return $scope.bindModel = null;
                }
              }
            }
          });
        }
      };
    }
  ]);

}).call(this);
