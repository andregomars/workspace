﻿
angular.module("edChevron", ['eaas-cache-common', 'ngSanitize']).directive('edChevron', [
  "common", "$rootScope", "$compile", function(common, $rootScope, $compile) {
    return {
      restrict: 'E',
      scope: {
        data: '=',
        query: '=',
        pageChangedEvent: '&'
      },
      template: '<div class="eaas-chevron-top" ng-show="data && query.totalItems>query.pageSize">\
              <a class="eaas-chevron" href="#" ng-click="pageChanged_chevron(\'left\')"  ng-class="{\'eaas-chevron-disabled\':query.currentPage == 1}">\
                   <i class="icon-chevron-left eaas-chevron-left" ></i>\
                   <div style="position: absolute; left: 0; margin-top: -42px; margin-left: 5px;opacity: 0">\
                       <i class="icon-chevron-left eaas-chevron-left" style="font-size: 60px;"></i>\
                   </div>\
              </a>\
               <a class="eaas-chevron" href="#" ng-click="pageChanged_chevron(\'right\')"  ng-class="{\'eaas-chevron-disabled\': query.totalItems / query.pageSize <= query.currentPage}" >\
                   <i class="icon-chevron-right eaas-chevron-right" ng-class="{\'eaas-chevron-right-disabled\': query.totalItems / query.pageSize <= query.currentPage}" ></i>\
                   <div style="position: absolute; right: 0; margin-top: -42px; margin-right: 5px;opacity: 0">\
                       <i class="icon-chevron-right eaas-chevron-right" style="font-size: 60px;"></i>\
                   </div>\
              </a>\
            </div>',
      link: function($scope, element) {
        return $scope.pageChanged_chevron = function(type) {
          if (type === 'left') {
            if ($scope.query.currentPage === 1) {
              return;
            }
            $scope.page = $scope.query.currentPage - 1;
            return $scope.pageChangedEvent({
              page: $scope.page
            });
          } else {
            if ($scope.query.totalItems / $scope.query.pageSize <= $scope.query.currentPage) {
              return;
            }
            $scope.page = $scope.query.currentPage + 1;
            return $scope.pageChangedEvent({
              page: $scope.page
            });
          }
        };
      }
    };
  }
]);
