﻿(function() {

  angular.module("edEditInfo", ['eaas-service']).directive('edEditInfo', [
    "common", 'organizationAPI', 'partnerAPI', 'stationAPI', function(common, organizationAPI, partnerAPI, stationAPI) {
      return {
        restrict: 'E',
        scope: {
          businessObject: '=',
          columnClass: '=',
          viewPage: '=',
          titleNoPadding: "="
        },
        template: '<div>\
            <h3 class="header">\
                \
            </h3>                           \
\
            <div>\
\
                <div class="clearfix eaas-document-formgroup">\
                    <label class="text-right control-label " \
                    ng-class="{\
                    \'col-sm-5\':columnClass == undefined,\
                    \'col-sm-4\':columnClass == \'4\',\
                    \'col-sm-3\':columnClass == \'3\',\
                    \'eaas-document-label-title\':viewPage==true,\
                    \'no-padding-right\':titleNoPadding==true\
                    }"\
                    >Creator:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{businessObject.InUser}}</label>\
                        </div>\
                    </div>\
                </div>\
\
                <div class="clearfix eaas-document-formgroup">\
                    <label class="text-right control-label"  ng-class="{\
                    \'col-sm-5\':columnClass == undefined,\
                    \'col-sm-4\':columnClass == \'4\',\
                    \'col-sm-3\':columnClass == \'3\',\
                    \'eaas-document-label-title\':viewPage==true,\
                    \'no-padding-right\':titleNoPadding==true\
                    }">Creation Time:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{businessObject.InDate | moment :\'YYYY-MM-DD hh:mm:ss\' }}</label>\
                        </div>\
                    </div>\
                </div>\
\
                <div class="clearfix eaas-document-formgroup" ng-show="businessObject.EditUser">\
                    <label class="text-right control-label"  ng-class="{\
                    \'col-sm-5\':columnClass == undefined,\
                    \'col-sm-4\':columnClass == \'4\',\
                    \'col-sm-3\':columnClass == \'3\',\
                    \'eaas-document-label-title\':viewPage==true,\
                    \'no-padding-right\':titleNoPadding==true\
                    }">Last Edit User:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{businessObject.EditUser}}</label>\
                        </div>\
                    </div>\
                </div>\
\
                 <div class="clearfix eaas-document-formgroup" ng-show="businessObject.EditDate">\
                    <label class="text-right control-label"  ng-class="{\
                    \'col-sm-5\':columnClass == undefined,\
                    \'col-sm-4\':columnClass == \'4\',\
                    \'col-sm-3\':columnClass == \'3\',\
                    \'eaas-document-label-title\':viewPage==true,\
                    \'no-padding-right\':titleNoPadding==true\
                    }">Last Edit Time:</label>\
                    <div class="col-sm-6 col-xs-12">\
                        <div class="clearfix">\
                            <label class="eaas-document-label ">{{businessObject.EditDate | moment :\'YYYY-MM-DD hh:mm:ss\'}}</label>\
                        </div>\
                    </div>\
                </div>\
 \
        </div>\
\
        ',
        controller: function($scope) {
          return null;
        },
        link: function($scope, element, attrs) {
          return null;
        }
      };
    }
  ]).directive('edTitleEditInfo', [
    "common", function(common) {
      return {
        restrict: 'E',
        scope: {
          businessObject: '='
        },
        template: '     <div style="float: right;font-size: 13px;margin-top: 5px;font-style:italic" ng-show="businessObject&&businessObject.InUser&&!businessObject.EditUser">\
                <span>Created by {{businessObject.InUser}} at {{businessObject.InDate | moment :\'YYYY-MM-DD HH:mm:ss\' }}</span>                                  \
            </div>\
            <div style="float: right;font-size: 13px;margin-top: 5px;font-style:italic" ng-show="businessObject&&businessObject.EditUser">\
                <span>Last edited by {{businessObject.EditUser}} at {{businessObject.EditDate | moment :\'YYYY-MM-DD HH:mm:ss\'}}</span>             \
            </div>\
        ',
        controller: function($scope) {
          return null;
        },
        link: function($scope, element, attrs) {
          return null;
        }
      };
    }
  ]);

}).call(this);
