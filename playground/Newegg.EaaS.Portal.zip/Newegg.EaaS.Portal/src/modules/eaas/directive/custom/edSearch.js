﻿(function() {

  angular.module("edSearch", ['eaas-cache-common', 'ngSanitize']).directive('edSearch', [
    "common", "$rootScope", "$compile", function(common, $rootScope, $compile) {
      return {
        restrict: 'E',
        scope: {
          template: '=',
          query: '=',
          isBackPage: '=',
          click: '&'
        },
        template: '<div class="input-group">\
            <span class="input-group-btn">\
                <button type="button" title="Advanced Search" ng-click="showAdvancedPanel()" class="btn btn-inverse btn-sm eaas-search-height " style="width: 27px">\
                    <i class="icon-filter bigger-110" style="position: absolute; left: 4px; top: 3px"></i>\
                </button>\
                <div class="eaas-search-popover  fade bottom in" style="display: block;" ng-show="showAdvanced">\
                    <div class="popover-content" style="padding-left: 6px;">\
                        <div style="width: 385px">\
                            <div class="col-xs-12">\
                                <label style="width: 105px">\
                                    <strong>Exactly match: </strong>\
                                </label>\
                                <label>\
                                    <input name="switch-field-1" ng-model="query.exactMatch" class="ace ace-switch ace-switch-2" type="checkbox" />\
                                    <span class="lbl"></span>\
                                </label>\
                            </div>\
                            <div class="col-xs-12">\
                               <div style="float:left;width: 108px">\
                                <label >\
                                    <strong>Query field(s): </strong>\
                                </label>\
                            </div>\
                             <div style="float:left">\
                                    <label ng-repeat="item in query.queryFieldList">\
                                      <input name="radio-queryField" type="radio" ng-model="query.queryField" value="{{item.value}}" ng-click="updatePlaceholder(item)" class="ace">\
                                      <span class="lbl"> {{item.text}}&nbsp;&nbsp;&nbsp;&nbsp;</span>\
                                    </label>\
                                     </div>\
                            </div>\
                        </div>\
                        <div style="width: 385px" ng-include="template"></div>\
                        <hr class="no-margin no-padding col-xs-12" />\
                        <div style="float: right; margin-top: 5px; margin-bottom: 5px">\
                            <button type="button" class="btn btn-xs btn-inverse" style="width: 50px"  ng-click="showAdvancedPanel()">\
                                Close\
                            </button>\
                        </div>\
                    </div>\
                </div>\
            </span>\
            <input type="text" class="form-control search-query eaas-search-height" ui-keypress="{13:\'overrideSearch()\'}" ng-blur="resetQueryField()" ng-model="query.keywords" placeholder="{{placeholderText}}">\
            <span class="input-group-btn">\
                <button type="button" class="btn btn-inverse btn-sm eaas-search-height no-padding-top" ng-submit="overrideSearch()" ng-click="overrideSearch()">\
                    Search\
                </button>\
            </span>\
        </div>',
        link: function($scope, element) {
          var index;
          $scope.clearQueryFields = function() {
            var index, _results;
            _results = [];
            for (index in $scope.query.queryFieldList) {
              _results.push(delete $scope.query[$scope.query.queryFieldList[index].value]);
            }
            return _results;
          };
          if (!$scope.isBackPage || $scope.isBackPage === false) {
            if ($scope.query.keywords) {
              $scope.query.keywords = null;
            }
            $scope.clearQueryFields();
          }
          $scope.showAdvanced = false;
          $scope.showAdvancedPanel = function() {
            if ($scope.showAdvanced === true) {
              return $scope.showAdvanced = false;
            } else {
              return $scope.showAdvanced = true;
            }
          };
          $scope.placeholderText = $scope.query.queryField;
          for (index in $scope.query.queryFieldList) {
            if ($scope.query.queryFieldList[index].value === $scope.query.queryField) {
              $scope.placeholderText = $scope.query.queryFieldList[index].text;
              break;
            }
          }
          $scope.updatePlaceholder = function(selectedItem) {
            return $scope.placeholderText = selectedItem.text;
          };
          $scope.resetQueryField = function() {
            $scope.clearQueryFields();
            if ($scope.query.keywords) {
              return $scope.query[$scope.query.queryField] = $scope.query.keywords;
            }
          };
          return $scope.overrideSearch = function() {
            $scope.resetQueryField();
            $scope.showAdvanced = false;
            return $scope.click();
          };
        }
      };
    }
  ]);

}).call(this);
