﻿
angular.module("edChartSetting", ['eaas-cache-common', 'ngSanitize']).directive('edChartSetting', [
  "common", "$rootScope", "$compile", function(common, $rootScope, $compile) {
    return {
      restrict: 'E',
      replace: true,
      scope: {
        isRefresh: '=',
        leftData: '=',
        rightData: '=',
        leftName: '=',
        rightName: '=',
        chartColors: '=',
        leftFunc: '&',
        rightFunc: '&'
      },
      template: '<div class="eaas-popover clearfix" ng-show="data_Total_types && data_Total_types.length > 0">\
        <div class="memberdiv">\
            <div class="inline position-relative">\
                <div style="float: left;">\
                    <span ng-repeat="item in data_Total_types | filter:{ isChecked: true }">\
                        <span class="btn-colorpicker" ng-model="item.color" ng-value="chartColors[$index]" ng-style="item.style" style=" width: 15px; height: 15px;" title="{{ item.type }}"></span>\
                    </span>\
                      <a href="#" style="color: #b5b3b3; font-size: 16px; margin-bottom: -3px !important;" >\
                          &nbsp;<i class="icon-cog"></i>\
                      </a>\
                </div>\
                <div class="popover left" ng-class="{\'statistics-chart-popover-1\':data_Total_types.length==1,\'statistics-chart-popover-2\':data_Total_types.length==2,\'statistics-chart-popover-3\':data_Total_types.length==3,\'statistics-chart-popover-4\':data_Total_types.length==4,\'statistics-chart-popover-5\':data_Total_types.length==5,\'statistics-chart-popover-6\':data_Total_types.length==6,\'statistics-chart-popover-7\':data_Total_types.length==7,\'statistics-chart-popover-8\':data_Total_types.length==8,\'statistics-chart-popover-9\':data_Total_types.length==9}">\
                    <div class="arrow"></div>\
                    <div class="popover-content">\
                        <div style="width: 225px">\
                            <div class="col-xs-12 no-margin no-padding">\
                                <label style="cursor: pointer" class="col-xs-12 no-margin-left" ng-repeat="item in data_Total_types">\
                                    <i class="icon-check-sign" ng-style="item.color" style="font-size: 18px;" ng-show="item.isChecked==true"></i>\
                                    <i class="icon-check-empty" ng-style="item.color" style="font-size: 18px;" ng-show="item.isChecked==false"></i>\
\
                                    <span class="lbl">{{ item.type }}</span>\
                                    <input name="form-field-checkbox" ng-model="item.isChecked" value="true" type="checkbox" class="ace" ng-change="selectMessageType(item)">\
                                </label>\
\
                            </div>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>',
      link: function($scope, element) {
        $scope.left = true;
        $scope.right = true;
        $scope.LoadChart = function() {
          var colorIndex, data1, data2, hideMessageTypes, index, labelList, lastData1, lastData2;
          data1 = angular.copy($scope.leftData);
          data2 = angular.copy($scope.rightData);
          labelList = [];
          lastData1 = [];
          lastData2 = [];
          hideMessageTypes = [];
          for (index in data2) {
            if (labelList.indexOf(data2[index].MessageTypeName) < 0) {
              labelList.push(data2[index].MessageTypeName);
            }
          }
          if ($scope.isRefresh === false) {
            $scope.data_Total_types = [];
          } else {
            $scope.isRefresh = false;
          }
          if (!$scope.data_Total_types || $scope.data_Total_types.length === 0) {
            $scope.data_Total_types = [];
            for (index in labelList) {
              $scope.data_Total_types.push({
                type: labelList[index],
                isChecked: true,
                color: {
                  "color": $scope.chartColors[index]
                },
                style: {
                  "background-color": $scope.chartColors[index]
                }
              });
            }
          } else {
            colorIndex = 0;
            for (index in $scope.data_Total_types) {
              if ($scope.data_Total_types[index].isChecked === true) {
                $scope.data_Total_types[index].color = {
                  "color": $scope.chartColors[colorIndex]
                };
                $scope.data_Total_types[index].style = {
                  "background-color": $scope.chartColors[colorIndex]
                };
                colorIndex++;
              } else {
                $scope.data_Total_types[index].color = '';
              }
            }
          }
          for (index in $scope.data_Total_types) {
            if ($scope.data_Total_types[index].isChecked === false) {
              hideMessageTypes.push($scope.data_Total_types[index].type);
            }
          }
          if (hideMessageTypes && hideMessageTypes.length > 0) {
            for (index in data1) {
              if (hideMessageTypes.indexOf(data1[index].MessageTypeName) < 0) {
                lastData1.push(data1[index]);
              }
            }
            for (index in data2) {
              if (hideMessageTypes.indexOf(data2[index].MessageTypeName) < 0) {
                lastData2.push(data2[index]);
              }
            }
          } else {
            lastData1 = data1;
            lastData2 = data2;
          }
          $scope.leftFunc({
            data: lastData1
          });
          return $scope.rightFunc({
            data: lastData2
          });
        };
        $scope.selectMessageType = function(item) {
          if ($scope.checkMessageTypeCount() === false) {
            return item.isChecked = true;
          } else {
            $scope.isRefresh = true;
            return $scope.LoadChart();
          }
        };
        $scope.checkMessageTypeCount = function() {
          var index, isCheckedCount;
          isCheckedCount = 0;
          for (index in $scope.data_Total_types) {
            if ($scope.data_Total_types[index].isChecked === true) {
              isCheckedCount++;
            }
          }
          if (isCheckedCount === 0) {
            return false;
          }
          return true;
        };
        return $scope.$watch('leftData', function(newVal, oldVal) {
          return $scope.LoadChart();
        });
      }
    };
  }
]);
