(function() {

  angular.module("edChooseStationIdentity", ['eaas-service']).directive('edChooseStationIdentity', [
    "common", 'stationAPI', 'customSettingCache', 'customsettingvalueAPI', '$compile', function(common, stationAPI, customSettingCache, customsettingvalueAPI, $compile) {
      return {
        restrict: 'E',
        scope: {
          name: '=',
          stationId: '=',
          identityValue: '=',
          promise: '=',
          identityCode: '=',
          onValueChanged: '&',
          onInputBlur: '&',
          setDefaultValue: '@',
          manualSetValue: '@',
          manualIdentityValue: '=',
          manualIdentityCode: '='
        },
        template: '\
    <div class="col-xs-10 no-margin no-padding ">\
    <i class="icon-spinner icon-spin eaas-loading-small" ng-show="isSearch" ></i>\
    <div class="input-group" ng-show="!isSearch" >\
      <input id="txtIdentityValue"  required type="text" class="form-control" is-Account="true" maxlength="15" ng-model="identityValue" ng-change="identityValueChanged();" ng-trim="false" ng-blur="onValueInputBlur();" ed-space   bind-model="identityValue" style="height:30px">      \
      <div class="input-group-btn">\
        <button type="button" class="btn btn-info dropdown-toggle btn-sm" data-toggle="dropdown" style="height:30px">\
            <span class="caret" style="margin-top:-3px"></span>\
        </button>\
        <ul class="dropdown-menu pull-right">\
          <li ng-repeat="item in currentStation.CustomSettingValueList"><a href="#" ng-click="selectIdentity(item);">{{item.DisplayCode}}{{item.Value}}&nbsp;&nbsp;&nbsp;&nbsp;<i class="icon-ok" ng-show="item.selected"></i></a></li>          \
        </ul>\
      </div>\
    </div>\
    </div>\
        ',
        controller: function($scope) {
          $scope.searchStationId = null;
          $scope.currentStation = null;
          $scope.currentIdentity = null;
          $scope.isSearch = true;
          $scope.onValueInputBlur = function() {
            if ($scope.onInputBlur) {
              return $scope.onInputBlur();
            }
          };
          $scope.getStationInfo = function(stationId) {
            return stationAPI.search({
              customsettingvalue: true,
              Id: stationId
            }, function(result) {
              $scope.isSearch = false;
              if (result && result.Succeeded && result.StationList && result.StationList.length > 0) {
                $scope.currentStation = result.StationList[0];
                $scope.getIdentityCode();
                if ($scope.setDefaultValue && !$scope.identityValue && $scope.currentStation && $scope.currentStation.CustomSettingValueList && $scope.currentStation.CustomSettingValueList.length > 0) {
                  $scope.identityValue = $scope.currentStation.CustomSettingValueList[0].Value;
                  $scope.identityCode = $scope.currentStation.CustomSettingValueList[0].Code;
                }
                if ($scope.manualSetValue) {
                  $scope.identityValue = $scope.manualIdentityValue;
                  $scope.identityCode = $scope.manualIdentityCode;
                }
                $scope.identityValueChanged();
                if ($scope.setDefaultValue) {
                  if ($scope.onInputBlur) {
                    $scope.$apply();
                    return $scope.onInputBlur();
                  }
                }
              }
            });
          };
          $scope.getIdentityCode = function() {
            var index, setting, _results;
            if ($scope.currentStation && $scope.currentStation.CustomSettingValueList) {
              _results = [];
              for (index in $scope.currentStation.CustomSettingValueList) {
                setting = customSettingCache.GetSettingCacheBySettingId(customSettingCache.CategoryName.IdentityQualifier, $scope.currentStation.CustomSettingValueList[index].SettingID);
                if (setting) {
                  $scope.currentStation.CustomSettingValueList[index].Code = setting.Code;
                  _results.push($scope.currentStation.CustomSettingValueList[index].DisplayCode = '(' + setting.Code + ')  ');
                } else {
                  _results.push(void 0);
                }
              }
              return _results;
            }
          };
          $scope.singleSelectIdentity = function(item) {
            var index, _results;
            _results = [];
            for (index in $scope.currentStation.CustomSettingValueList) {
              if ($scope.currentStation.CustomSettingValueList[index].Id === item.Id) {
                continue;
              } else {
                _results.push($scope.currentStation.CustomSettingValueList[index].selected = false);
              }
            }
            return _results;
          };
          $scope.findIdentity = function(identityValue, idetntityCode) {
            var index, item;
            item = null;
            if (identityValue) {
              for (index in $scope.currentStation.CustomSettingValueList) {
                if ($scope.currentStation.CustomSettingValueList[index].Value.toString() === identityValue.toString() && $scope.currentStation.CustomSettingValueList[index].Code.toString() === idetntityCode.toString()) {
                  item = $scope.currentStation.CustomSettingValueList[index];
                  return item;
                }
              }
              for (index in $scope.currentStation.CustomSettingValueList) {
                if ($scope.currentStation.CustomSettingValueList[index].Value.toString() === identityValue.toString()) {
                  item = $scope.currentStation.CustomSettingValueList[index];
                  return item;
                }
              }
            }
            return item;
          };
          $scope.identityValueChanged = function() {
            var identityItem, index;
            identityItem = $scope.findIdentity($scope.identityValue, $scope.identityCode);
            if (identityItem) {
              identityItem.selected = true;
              $scope.identityCode = identityItem.Code;
              $scope.singleSelectIdentity(identityItem);
            } else {
              for (index in $scope.currentStation.CustomSettingValueList) {
                $scope.currentStation.CustomSettingValueList[index].selected = false;
              }
            }
            if ($scope.onValueChanged) {
              $scope.$apply();
              return $scope.onValueChanged();
            }
          };
          $scope.selectIdentity = function(item) {
            item.selected = true;
            $scope.singleSelectIdentity(item);
            $scope.identityValue = item.Value;
            $scope.identityCode = item.Code;
            $scope.$apply();
            return $scope.onValueInputBlur();
          };
          $scope.initialize = function() {
            return $scope.getStationInfo($scope.searchStationId);
          };
          $scope.changeValueByCode = function() {
            var identityItem, index, _results;
            identityItem = $scope.findIdentity($scope.identityValue, $scope.identityCode);
            if (identityItem && identityItem.Code && $scope.identityCode && identityItem.Code === $scope.identityCode) {
              $scope.identityValueChanged();
              return;
            }
            _results = [];
            for (index in $scope.currentStation.CustomSettingValueList) {
              if ($scope.currentStation.CustomSettingValueList[index].Code === $scope.identityCode) {
                $scope.identityValue = $scope.currentStation.CustomSettingValueList[index].Value;
                $scope.identityValueChanged(true);
                break;
              } else {
                _results.push(void 0);
              }
            }
            return _results;
          };
          $scope.$watch('stationId', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              $scope.isSearch = true;
              $scope.searchStationId = newVal;
              return $scope.initialize();
            }
          });
          $scope.$watch('identityValue', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              if ($scope.currentStation && $scope.currentStation.CustomSettingValueList) {
                return $scope.identityValueChanged();
              } else {
                if ($scope.manualSetValue) {
                  return $scope.manualIdentityValue = newVal;
                }
              }
            }
          });
          return $scope.$watch('identityCode', function(newVal, oldVal) {
            if (newVal === void 0 || newVal === null) {

            } else {
              if ($scope.currentStation && $scope.currentStation.CustomSettingValueList) {
                return $scope.changeValueByCode();
              } else {
                if ($scope.manualSetValue) {
                  return $scope.manualIdentityCode = newVal;
                }
              }
            }
          });
        },
        compile: function(tElement, tAttrs, transclude) {
          $('#txtIdentityValue').attr('name', tAttrs.name);
          $('#txtIdentityValue').removeAttr('id');
          return null;
        },
        link: function(scope, element, attrs, $compile) {
          return null;
        }
      };
    }
  ]);

}).call(this);
