﻿(function() {

  angular.module("edOwnerTitle", ['eaas-cache-common', 'ngSanitize']).directive('edOwnerTitle', [
    "common", function(common) {
      return {
        restrict: 'E',
        scope: {
          title: '=',
          closeDialog: '&'
        },
        template: '<span ng-bind-html="deliberatelyTrustDangerousSnippet()">                        \
                </span>',
        controller: function($scope, $sce) {
          $scope.loading = '<i class="icon-spinner icon-spin eaas-loading-small" specialId="ownerinfoloading"></i>';
          $scope.deliberatelyTrustDangerousSnippet = function() {
            return $sce.trustAsHtml($scope.title);
          };
          $scope.DisplayOwnerTitle = function() {
            if (common.OwnerTitleInfo.OwnerType === 'Eaas' || common.OwnerTitleInfo.OwnerName === 'NotExist') {
              return $scope.title = $scope.title.replace($scope.loading, '<strong><a>EaaS</a></strong>');
            } else {
              return $scope.title = $scope.title.replace($scope.loading, '<strong><a>' + common.OwnerTitleInfo.OwnerName + '</a></strong>');
            }
          };
          $scope.title = $scope.title.replace('#OwnerInfo#', $scope.loading);
          if (common.OwnerTitleInfo.OwnerType && common.OwnerTitleInfo.OwnerName && common.OwnerTitleInfo.OwnerType !== 'Eaas') {
            return $scope.DisplayOwnerTitle();
          } else {
            if (!common.currentOrganization || !common.currentOrganization.Id) {
              common.OwnerTitleInfo.OwnerType = 'Eaas';
              common.OwnerTitleInfo.OwnerName = 'Eaas';
              $scope.DisplayOwnerTitle();
            }
            if (common.currentUser.Type === common.userRole.superUser && common.currentOrganization && common.currentOrganization.IsAgent && common.currentOrganization.IsAgent === true) {
              common.OwnerTitleInfo.OwnerType = common.ownerType.organization;
              common.OwnerTitleInfo.OwnerID = common.currentOrganization.Id;
              common.RequestOwner(common.OwnerTitleInfo, $scope.DisplayOwnerTitle);
            }
            if (common.currentUser.Type === common.userRole.organizationUser) {
              common.OwnerTitleInfo.OwnerType = common.ownerType.organization;
              common.OwnerTitleInfo.OwnerID = common.currentOrganization.Id;
              common.RequestOwner(common.OwnerTitleInfo, $scope.DisplayOwnerTitle);
            }
            if (common.currentUser.Type === common.userRole.partnerUser) {
              common.OwnerTitleInfo.OwnerType = common.ownerType.partner;
              common.OwnerTitleInfo.OwnerID = common.currentUser.PartnerID;
              common.RequestOwner(common.OwnerTitleInfo, $scope.DisplayOwnerTitle);
            }
            if (common.currentUser.Type === common.userRole.stationUser) {
              common.OwnerTitleInfo.OwnerType = common.ownerType.station;
              common.OwnerTitleInfo.OwnerID = common.currentUser.StationID;
              return common.RequestOwner(common.OwnerTitleInfo, $scope.DisplayOwnerTitle);
            }
          }
        },
        link: function($scope, element, attrs, $sce) {
          return null;
        }
      };
    }
  ]);

}).call(this);
