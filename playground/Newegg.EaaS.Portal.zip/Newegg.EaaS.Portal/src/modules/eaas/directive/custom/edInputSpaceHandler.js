﻿(function() {

  angular.module("edSpace", ['eaas-cache-common']).directive('edSpace', [
    "common", function(common) {
      return {
        link: function($scope, element, attrs) {
          debugger;
          var authItem, moduleName, _agreementMgmt, _hide, _moduleProxy, _partnerMgmt, _resourceMgmt, _stationMgmt;
          _hide = function() {
            return attrs.$set('class', 'ng-hide');
          };
          authItem = $scope.$eval(attrs.edAuthItem);
          if (!common.currentUser) {
            _hide();
            return false;
          }
          if (common.currentUser.UserRole === 'Organization') {
            return true;
          }
          if (authItem && authItem.InUser === common.currentUser.LoginName) {
            return true;
          }
          moduleName = common.currentRoutePath();
          _moduleProxy = function() {
            if (moduleName.indexOf('partner') >= 0) {
              return _partnerMgmt();
            } else if (moduleName.indexOf('station') >= 0) {
              return _stationMgmt();
            } else if (moduleName.indexOf('agreement') >= 0) {
              return _agreementMgmt();
            } else {
              return _resourceMgmt();
            }
          };
          _partnerMgmt = function() {
            if (!authItem && common.currentUser.UserRole !== 'Station') {
              return true;
            }
            if (authItem && authItem.Id === common.currentUser.PartnerID) {
              return true;
            }
            _hide();
            return false;
          };
          _stationMgmt = function() {
            var currentPartner;
            currentPartner = common.current.link[moduleName].pageParameter.Partner;
            if (currentPartner && currentPartner.Id === common.currentUser.PartnerID && common.currentUser.UserRole === 'Partner') {
              return true;
            }
            if (!authItem) {
              if (currentPartner && currentPartner.Type === 'Trading') {
                return true;
              }
            } else {
              if (authItem.Id === common.currentUser.StationID) {
                return true;
              }
            }
            _hide();
            return false;
          };
          _agreementMgmt = function() {
            var ss;
            if (!authItem) {
              return true;
            } else {
              debugger;
              if (common.currentUser.UserRole === 'Partner') {
                ss = common.currentUser.StationIDList.indexOf(authItem.LocalStationID);
                if (common.currentUser.StationIDList && common.currentUser.StationIDList.indexOf(authItem.LocalStationID) >= 0) {
                  return true;
                }
              } else if (common.currentUser.UserRole === 'Station') {
                if (authItem.LocalStationID === common.currentUser.StationID) {
                  return true;
                }
              }
            }
            _hide();
            return false;
          };
          _resourceMgmt = function() {
            if (!authItem) {
              return true;
            } else {
              if (common.currentUser.UserRole === 'Partner') {
                if (authItem.OwnerType === 'Partner' && authItem.OwnerID === common.currentUser.PartnerID) {
                  return true;
                }
                if (authItem.OwnerType === 'Station' && authItem.OwnerPartnerID === common.currentUser.PartnerID) {
                  return true;
                }
              } else if (common.currentUser.UserRole === 'Station') {
                if (authItem && authItem.OwnerType === 'Station' && authItem.OwnerID === common.currentUser.StationID) {
                  return true;
                }
              }
            }
            _hide();
            return false;
          };
          return _moduleProxy();
        }
      };
    }
  ]);

}).call(this);
