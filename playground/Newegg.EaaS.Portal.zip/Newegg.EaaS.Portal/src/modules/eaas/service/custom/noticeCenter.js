(function() {
  var error;

  angular.module("eaas-custom-noticeCenter", []).factory('noticeCenter', [
    "common", "$rootScope", "$interval", "$location", "notice", "versionHistoryAPI", function(common, $rootScope, $interval, $location, notice, versionHistoryAPI) {
      var expiresDays, interval_time, newVersionDate, newVersionNo, show_sticky, show_time, version, version_action_1, version_action_2, version_createText, version_onload, version_refresh, version_rewrite, version_setCookie, version_show, version_title, warning;
      interval_time = 30 * 60 * 1000;
      show_time = 60 * 1000;
      show_sticky = false;
      expiresDays = 36500;
      newVersionDate = '';
      newVersionNo = '';
      version_rewrite = false;
      version_title = 'Version Update';
      version_action_1 = {
        name: 'Read More',
        path: 'version-history'
      };
      version_action_2 = {
        name: 'Refresh',
        event: function() {
          return version_refresh();
        }
      };
      version_onload = function() {
        return versionHistoryAPI.search({}, function(result) {
          var cookieVersionDate;
          if (result && result.Succeeded && result.VersionHistoryList && result.VersionHistoryList.length > 0) {
            cookieVersionDate = $.cookie("eaas-version-date");
            if (!cookieVersionDate || Date.parse(cookieVersionDate).valueOf() < Date.parse(result.VersionHistoryList[0].ReleaseDateString).valueOf()) {
              version_rewrite = true;
            }
            $.cookie("eaas-version-date", result.VersionHistoryList[0].ReleaseDateString, {
              path: '/',
              expires: expiresDays
            });
            return $.cookie("eaas-version-number", result.VersionHistoryList[0].Version, {
              path: '/',
              expires: expiresDays
            });
          }
        });
      };
      version_refresh = function() {
        version_setCookie();
        return location.reload();
      };
      version_setCookie = function() {
        $.cookie("eaas-version-date", newVersionDate, {
          path: '/',
          expires: expiresDays
        });
        return $.cookie("eaas-version-number", newVersionNo, {
          path: '/',
          expires: expiresDays
        });
      };
      version_createText = function(newVersionNo, newVersionDate) {
        var text_1, text_2;
        text_1 = "<label style='width:105px'>New Version:</label><label>" + newVersionNo + " (" + newVersionDate + ")</label>";
        text_2 = "<label style='width:105px'>Current Version:</label><label>" + $.cookie("eaas-version-number") + " (" + $.cookie("eaas-version-date") + ")</label>";
        return text_1 + text_2;
      };
      version_show = function(newVersionNo, newVersionDate) {
        var option;
        option = {};
        option.title = version_title;
        option.text = version_createText(newVersionNo, newVersionDate);
        option.sticky = show_sticky;
        option.time = show_time;
        if (version_rewrite === true) {
          option.action = [version_action_1];
          version_rewrite = false;
          return notice.info(option);
        } else {
          if (newVersionDate !== $.cookie("eaas-version-date")) {
            option.action = [version_action_1, version_action_2];
            return notice.info(option);
          }
        }
      };
      version = function() {
        return versionHistoryAPI.search({}, function(result) {
          if (result && result.Succeeded && result.VersionHistoryList && result.VersionHistoryList.length > 0) {
            newVersionDate = result.VersionHistoryList[0].ReleaseDateString;
            newVersionNo = result.VersionHistoryList[0].Version;
            return version_show(newVersionNo, newVersionDate);
          }
        });
      };
      return warning = function() {
        return notice.warning({
          title: 'FTP Connection Warning',
          text: '[Stocking PO] FTP connection exception, please review.',
          sticky: show_sticky,
          time: 15 * 1000,
          action: [
            {
              name: 'View Detail',
              path: 'transmission'
            }
          ]
        });
      };
    }, error = function() {
      return notice.error({
        title: 'Error Message Notice',
        text: 'There are 5 error messages pending this week, please confirm.',
        sticky: show_sticky,
        time: 25 * 1000,
        action: [
          {
            name: 'View Detail',
            path: 'message'
          }
        ]
      });
    }, {
      onLoad: function() {
        return version_onload();
      },
      start: function() {
        version();
        return $rootScope.versionTimer = $interval(version, interval_time);
      },
      end: function() {
        return $rootScope.$on('$destroy', $interval.cancel($rootScope.versionTimer));
      }
    }
  ]);

}).call(this);
