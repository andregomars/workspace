﻿
angular.module("eaas-custom-notice", []).factory('notice', [
  "messager", function(messager) {
    var error_class, error_icon, info_class, info_icon, warning_class, warning_icon;
    info_icon = 'icon-info-sign';
    info_class = 'notice-info';
    warning_icon = 'icon-warning-sign';
    warning_class = 'notice-warning';
    error_icon = 'icon-remove-sign';
    error_class = 'notice-error';
    return {
      info: function(option) {
        if (!option) {
          return;
        }
        option.image = info_icon;
        option.class_name = info_class;
        return messager.notice(option);
      },
      warning: function(option) {
        if (!option) {
          return;
        }
        option.image = warning_icon;
        option.class_name = warning_class;
        return messager.notice(option);
      },
      error: function(option) {
        if (!option) {
          return;
        }
        option.image = error_icon;
        option.class_name = error_class;
        return messager.notice(option);
      }
    };
  }
]);
