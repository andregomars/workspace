﻿
angular.module("eaas-cache-agreement", []).factory("agreement", [
  "$filter", "common", function($filter, common) {
    var GetISANameByCode, charTypeList, checkDuplicateChar, checkErrorField, clearNotOverridesTransmission, createItem, data, editItem, hexToString, hideHasUsedSchema, loadUsedSchemaTypes, query, removeNotOverridesTransmissionWithAPIRequest, reset, stringToHex;
    createItem = {};
    editItem = {};
    data = [];
    query = {
      id: null,
      name: null,
      agreementOneway: false,
      station: false
    };
    reset = function() {
      query.id = null;
      query.name = null;
      return {
        agreementOneway: false,
        station: false
      };
    };
    charTypeList = [
      {
        text: 'Char',
        value: 'Char'
      }, {
        text: 'Hex',
        value: 'Char'
      }
    ];
    stringToHex = function(str) {
      if (!str) {
        return '';
      }
      return str.charCodeAt(0).toString(16).toUpperCase();
    };
    hexToString = function(hex) {
      if (!hex) {
        return '';
      }
      return String.fromCharCode(parseInt(hex, 16));
    };
    GetISANameByCode = function(code, list) {
      var index;
      for (index in list) {
        if (list[index].Code === code) {
          return list[index].Name;
        }
      }
    };
    checkDuplicateChar = function(arrayStr) {
      var hash, index;
      hash = {};
      for (index in arrayStr) {
        if (hash[arrayStr[index]]) {
          return true;
        }
        hash[arrayStr[index]] = true;
      }
      return false;
    };
    clearNotOverridesTransmission = function(tabType, oldBasicTransmissionID, transmissionList) {
      var index, _results;
      if (!transmissionList || !oldBasicTransmissionID) {
        return;
      }
      _results = [];
      for (index in transmissionList) {
        if (tabType === 'local') {
          if ((transmissionList[index].DestinationTransportProtocol && transmissionList[index].DestinationTransportProtocol.Id === oldBasicTransmissionID) || transmissionList[index].DestinationTransportProtocolSettingsID === oldBasicTransmissionID) {
            delete transmissionList[index].DestinationTransportProtocol;
            delete transmissionList[index].DestinationTransportProtocolSettingsID;
            delete transmissionList[index].DestinationTransportProtocolType;
          }
        }
        if (tabType === 'trading') {
          if ((transmissionList[index].SourceTransportProtocol && transmissionList[index].SourceTransportProtocol.Id === oldBasicTransmissionID) || transmissionList[index].SourceTransportProtocolSettingsID === oldBasicTransmissionID) {
            delete transmissionList[index].SourceTransportProtocol;
            delete transmissionList[index].SourceTransportProtocolSettingsID;
            _results.push(delete transmissionList[index].SourceTransportProtocolType);
          } else {
            _results.push(void 0);
          }
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    hideHasUsedSchema = function(schemaTypeArray, schemaList) {
      var index, _results;
      if (!schemaTypeArray || !schemaList) {
        return;
      }
      _results = [];
      for (index in schemaList) {
        if (schemaTypeArray.indexOf(schemaList[index].TransactionType) >= 0) {
          _results.push(schemaList[index].showSelect = false);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    loadUsedSchemaTypes = function(transactionList, currentTransaction) {
      var index, usedSchemaTypes;
      usedSchemaTypes = [];
      for (index in transactionList) {
        if (transactionList[index].Schema && usedSchemaTypes.indexOf(transactionList[index].Schema.TransactionType) < 0) {
          usedSchemaTypes.push(transactionList[index].Schema.TransactionType);
        } else if (transactionList[index].Mapper && transactionList[index].Mapper.SourceSchema && usedSchemaTypes.indexOf(transactionList[index].Mapper.SourceSchema.TransactionType) < 0) {
          usedSchemaTypes.push(transactionList[index].Mapper.SourceSchema.TransactionType);
        }
      }
      for (index in usedSchemaTypes) {
        if (currentTransaction.Schema && usedSchemaTypes[index] === currentTransaction.Schema.TransactionType) {
          delete usedSchemaTypes[index];
        } else if (currentTransaction.Mapper && currentTransaction.Mapper.SourceSchema && usedSchemaTypes[index] === currentTransaction.Mapper.SourceSchema.TransactionType) {
          delete usedSchemaTypes[index];
        }
      }
      return usedSchemaTypes;
    };
    removeNotOverridesTransmissionWithAPIRequest = function(currentAgreement) {
      var index;
      if (!currentAgreement) {
        return;
      }
      delete currentAgreement.LocalStation;
      delete currentAgreement.TradingStation;
      if (currentAgreement.LocalToTrading.AgreementTransactionList && currentAgreement.LocalToTrading.AgreementTransactionList.length > 0) {
        for (index in currentAgreement.LocalToTrading.AgreementTransactionList) {
          delete currentAgreement.LocalToTrading.AgreementTransactionList[index].Schema;
          delete currentAgreement.LocalToTrading.AgreementTransactionList[index].Mapper;
        }
      }
      if (currentAgreement.TradingToLocal.AgreementTransactionList && currentAgreement.TradingToLocal.AgreementTransactionList.length > 0) {
        for (index in currentAgreement.TradingToLocal.AgreementTransactionList) {
          delete currentAgreement.TradingToLocal.AgreementTransactionList[index].Schema;
          delete currentAgreement.TradingToLocal.AgreementTransactionList[index].Mapper;
        }
      }
      if (currentAgreement.LocalToTrading && currentAgreement.LocalToTrading.AgreementTransactionList) {
        for (index in currentAgreement.LocalToTrading.AgreementTransactionList) {
          if ((currentAgreement.LocalToTrading.AgreementTransactionList[index].DestinationTransportProtocol && currentAgreement.LocalToTrading.AgreementTransactionList[index].DestinationTransportProtocol.Id === currentAgreement.LocalToTrading.DestinationTransportProtocolSettingsID) || currentAgreement.LocalToTrading.AgreementTransactionList[index].DestinationTransportProtocolSettingsID === currentAgreement.LocalToTrading.DestinationTransportProtocolSettingsID) {
            delete currentAgreement.LocalToTrading.AgreementTransactionList[index].DestinationTransportProtocol;
            delete currentAgreement.LocalToTrading.AgreementTransactionList[index].DestinationTransportProtocolSettingsID;
            delete currentAgreement.LocalToTrading.AgreementTransactionList[index].DestinationTransportProtocolType;
          }
        }
      }
      if (currentAgreement.TradingToLocal && currentAgreement.TradingToLocal.AgreementTransactionList) {
        for (index in currentAgreement.TradingToLocal.AgreementTransactionList) {
          if (currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides) {
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.ProtocolVersion;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.FunctionalIdentifierCode;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.TransactionSetType;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.DateFormat;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.TimeFormat;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.ResponsibleAgencyCode;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.SenderID;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.ReceiverID;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].X12EnvelopesOverrides.TragetNamespace;
          }
          if ((currentAgreement.TradingToLocal.AgreementTransactionList[index].SourceTransportProtocol && currentAgreement.TradingToLocal.AgreementTransactionList[index].SourceTransportProtocol.Id === currentAgreement.TradingToLocal.SourceTransportProtocolSettingsID) || currentAgreement.TradingToLocal.AgreementTransactionList[index].SourceTransportProtocolSettingsID === currentAgreement.TradingToLocal.SourceTransportProtocolSettingsID) {
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].SourceTransportProtocol;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].SourceTransportProtocolSettingsID;
            delete currentAgreement.TradingToLocal.AgreementTransactionList[index].SourceTransportProtocolType;
          }
          delete currentAgreement.TradingToLocal.AgreementTransactionList[index].DestinationTransportProtocol;
        }
      }
      delete currentAgreement.LocalToTrading.SourceStation;
      delete currentAgreement.LocalToTrading.DestinationStation;
      delete currentAgreement.LocalToTrading.SourceTransportProtocol;
      delete currentAgreement.LocalToTrading.DestinationTransportProtocol;
      delete currentAgreement.TradingToLocal.SourceStation;
      delete currentAgreement.TradingToLocal.DestinationStation;
      delete currentAgreement.TradingToLocal.SourceTransportProtocol;
      return delete currentAgreement.TradingToLocal.DestinationTransportProtocol;
    };
    checkErrorField = function(form) {
      var errorElementTop, errorFieldName;
      errorFieldName = null;
      if (form.$error && form.$error.required) {
        if (form.$error.required[0].$name) {
          errorFieldName = form.$error.required[0].$name;
        } else {
          if (form.$error.required.length > 1) {
            errorFieldName = form.$error.required[1].$name;
          }
        }
      }
      if (!errorFieldName && form.$error && form.$error.pattern) {
        errorFieldName = form.$error.pattern[0].$name;
      }
      if (errorFieldName) {
        if (errorFieldName.indexOf('trading') >= 0) {
          $('#trading_a').click();
        } else {
          $('#local_a').click();
        }
        angular.forEach(form, function(field, name) {
          if (typeof name === 'string' && !name.match('^[\$]')) {
            if (name === errorFieldName) {
              if (field.$pristine) {
                return field.$setViewValue(field.$value);
              }
            }
          }
        });
        errorElementTop = $('[name="' + errorFieldName + '"]').offset().top;
        return $(document).scrollTop(errorElementTop - 100);
      }
    };
    return {
      query: query,
      data: data,
      createItem: createItem,
      editItem: editItem,
      reset: reset,
      charTypeList: charTypeList,
      stringToHex: stringToHex,
      hexToString: hexToString,
      clearNotOverridesTransmission: clearNotOverridesTransmission,
      removeNotOverridesTransmissionWithAPIRequest: removeNotOverridesTransmissionWithAPIRequest,
      loadUsedSchemaTypes: loadUsedSchemaTypes,
      hideHasUsedSchema: hideHasUsedSchema,
      checkDuplicateChar: checkDuplicateChar,
      checkErrorField: checkErrorField,
      GetISANameByCode: GetISANameByCode
    };
  }
]);
