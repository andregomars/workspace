﻿(function() {

  angular.module("eaas-cache-partner", []).factory("partner", [
    function() {
      var createItem, data, editItem, query, reset, viewItem;
      createItem = {};
      editItem = {};
      viewItem = {};
      data = [];
      query = {
        id: null,
        name: null,
        status: null,
        type: null,
        contact: null,
        certificate: null,
        station: null
      };
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          return query = {};
        }
      };
      return {
        query: query,
        data: data,
        editItem: editItem,
        reset: reset
      };
    }
  ]);

}).call(this);
