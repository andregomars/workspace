﻿(function() {

  angular.module("eaas-cache-account", []).factory('account', [
    "common", function(common) {
      var createItem, data, editItem, query, reset, viewItem;
      createItem = {};
      editItem = {};
      viewItem = {};
      data = [];
      query = {
        id: null,
        loginname: null,
        status: null,
        type: null,
        contact: null
      };
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          query.filterType = "all";
          return query.keyWord = "";
        }
      };
      return {
        query: query,
        data: data,
        editItem: editItem,
        reset: reset
      };
    }
  ]);

}).call(this);
