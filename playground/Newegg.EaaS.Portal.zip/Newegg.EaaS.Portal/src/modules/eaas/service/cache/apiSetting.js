(function() {
  angular.module("eaas-cache-apiSetting", []).factory('apiSetting', [
    "messager", function(messager) {
      var apiTimeOut, baseAPIUrl, baseAPIUrl_v2, baseDFISUrl, baseUploadAPIUrl, testFTPAPIUrl;
      baseAPIUrl = 'http://apis.newegg.org/edi/v1/eaas';
      baseAPIUrl_v2 = 'http://apis.newegg.org/eaas/v2/runtime';
      testFTPAPIUrl = '/bts-management/s7bztapp03/runtime/test/ftp-connection';
      baseUploadAPIUrl = 'http://apis.newegg.org/edi/common/v2/file-upload';
      baseDFISUrl = 'http://neg-app-img/EaaS/Message/';
      apiTimeOut = {
        auth: 15000,
        retrieve: 60000,
        operation: 90000
      };
      return {
        baseAPIUrl: baseAPIUrl,
        baseAPIUrl_v2: baseAPIUrl_v2,
        apiTimeOut: apiTimeOut,
        testFTPAPIUrl: testFTPAPIUrl,
        baseUploadAPIUrl: baseUploadAPIUrl,
        baseDFISUrl: baseDFISUrl
      };
    }
  ]);

}).call(this);
