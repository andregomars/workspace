﻿(function() {

  angular.module("eaas-cache-station", []).factory("station", [
    function() {
      var createItem, data, editItem, partner, query, reset, viewItem;
      createItem = {};
      editItem = {};
      viewItem = {};
      partner = null;
      data = [];
      query = {
        id: null,
        partnerid: null,
        name: null,
        status: null,
        type: null,
        contact: null,
        schema: null,
        customsettingvalue: null
      };
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          query.filterType = "all";
          return query.keyWord = "";
        }
      };
      return {
        query: query,
        data: data,
        editItem: editItem,
        reset: reset
      };
    }
  ]);

}).call(this);
