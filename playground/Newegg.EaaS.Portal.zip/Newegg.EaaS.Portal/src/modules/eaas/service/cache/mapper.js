﻿(function() {

  angular.module("eaas-cache-mapper", []).factory('mapper', [
    "common", function(common) {
      var createItem, data, editItem, query, removeItemWithAPIRequest, reset, viewItem;
      createItem = {
        Mapper: {
          OrganizationID: common.currentOrganization.ID
        }
      };
      editItem = {
        Mapper: {
          OrganizationID: common.currentOrganization.ID
        }
      };
      removeItemWithAPIRequest = function(currentMapper) {
        if (!currentMapper) {
          return;
        }
        delete currentMapper.Mapper.SourceSchema;
        delete currentMapper.Mapper.DestinationSchema;
        return delete currentMapper.RequestInfo;
      };
      viewItem = {};
      data = [];
      query = {
        filterType: "all",
        id: null,
        name: null
      };
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          query.filterType = "all";
          return query.keyWord = "";
        }
      };
      return {
        query: query,
        data: data,
        editItem: editItem,
        reset: reset,
        removeItemWithAPIRequest: removeItemWithAPIRequest
      };
    }
  ]);

}).call(this);
