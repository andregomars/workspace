﻿(function() {

  angular.module("eaas-cache-certificate", []).factory("certificate", [
    function() {
      var createItem, data, editItem, query, reset, viewItem;
      createItem = {};
      editItem = {};
      viewItem = {};
      data = [];
      query = {
        id: null,
        subject: null,
        status: null,
        type: null
      };
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          query.filterType = "all";
          return query.keyWord = "";
        }
      };
      return {
        query: query,
        data: data,
        editItem: editItem,
        reset: reset
      };
    }
  ]);

}).call(this);
