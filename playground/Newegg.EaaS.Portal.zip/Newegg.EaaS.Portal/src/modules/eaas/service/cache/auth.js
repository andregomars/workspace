﻿(function() {

  angular.module("eaas-cache-auth", []).factory('auth', [
    "common", function(common) {
      return {};
    }
  ]);

}).call(this);
