﻿
angular.module("eaas-cache-monitor", []).factory('monitor', [
  "common", function(common) {
    var chartColors, data, query, reset;
    chartColors = ["#0B62A4", "#7A92A3", "#95C443", "#93C6EA", "#E3B948", "#B75050", "#4D954D", "#5A8B1A", "#B948B9"];
    data = [];
    query = {
      id: null
    };
    reset = function() {
      if (common.current.isBackPage === true) {
        return common.current.isBackPage = false;
      } else {
        return query.id = null;
      }
    };
    return {
      query: query,
      data: data,
      reset: reset,
      chartColors: chartColors
    };
  }
]);
