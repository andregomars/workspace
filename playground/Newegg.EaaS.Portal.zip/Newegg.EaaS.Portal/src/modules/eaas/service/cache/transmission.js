(function() {

  angular.module("eaas-cache-transmission", []).factory("transmission", [
    "common", "transmissionAPI", 'testFtpAPI', '$q', function(common, transmissionAPI, testFtpAPI, $q) {
      var createItem, data, editItem, getData, getData2, query, reset, testFtpConnection;
      createItem = {};
      editItem = {};
      data = [];
      query = {
        protocolType: null,
        direction: null,
        id: null,
        name: null
      };
      getData = function(item, type) {
        var response;
        item.Loading = true;
        return response = transmissionAPI.search({
          id: item.Id,
          protocolType: item.ProtocolType,
          basicInfoOnly: false,
          encodingProtocol: false
        }, function() {
          item.Loading = false;
          if (response && response.Succeeded) {
            if (item.ProtocolType === null) {
              if (response.ProtocolList && response.ProtocolList.length > 0) {
                return item = response.ProtocolList[0];
              }
            } else {
              if (item.ProtocolType === 'FTP' && response.ProtocolFtpList && response.ProtocolFtpList.length > 0) {
                item.ProtocolFtp = response.ProtocolFtpList[0];
              }
              if (item.ProtocolType === 'MQ' && response.ProtocolMqList && response.ProtocolMqList.length > 0) {
                item.ProtocolMq = response.ProtocolMqList[0];
              }
              if (item.ProtocolType === 'AS2' && response.ProtocolAs2List && response.ProtocolAs2List.length > 0) {
                item.ProtocolAs2 = response.ProtocolAs2List[0];
                if (type && type === 'local') {
                  item.AS2ToID = item.ProtocolAs2.AS2ID;
                }
                if (type && type === 'trading') {
                  return item.AS2ToID = item.ProtocolAs2.AS2ID;
                }
              }
            }
          }
        });
      };
      getData2 = function(parent, item, type) {
        var response;
        parent.AS2ToID = null;
        parent.Loading = true;
        return response = transmissionAPI.search({
          id: item.Id,
          protocolType: item.ProtocolType,
          basicInfoOnly: false,
          encodingProtocol: false
        }, function() {
          parent.Loading = false;
          if (response && response.Succeeded) {
            if (item.ProtocolType === null) {
              if (response.ProtocolList && response.ProtocolList.length > 0) {
                return item = response.ProtocolList[0];
              }
            } else {
              if (item.ProtocolType === 'FTP' && response.ProtocolFtpList && response.ProtocolFtpList.length > 0) {
                item.ProtocolFtp = response.ProtocolFtpList[0];
              }
              if (item.ProtocolType === 'MQ' && response.ProtocolMqList && response.ProtocolMqList.length > 0) {
                item.ProtocolMq = response.ProtocolMqList[0];
              }
              if (item.ProtocolType === 'AS2' && response.ProtocolAs2List && response.ProtocolAs2List.length > 0) {
                item.ProtocolAs2 = response.ProtocolAs2List[0];
                if (type && type === 'local') {
                  parent.AS2ToID = item.ProtocolAs2.AS2ID;
                  item.AS2ToID = item.ProtocolAs2.AS2ID;
                }
                if (type && type === 'trading') {
                  parent.AS2ToID = item.ProtocolAs2.AS2ID;
                  return item.AS2ToID = item.ProtocolAs2.AS2ID;
                }
              }
            }
          }
        });
      };
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          query.protocolType = null;
          query.direction = null;
          query.id = null;
          return query.name = null;
        }
      };
      testFtpConnection = function(ftpParameter) {
        var deferred, response;
        deferred = $q.defer();
        response = testFtpAPI.testFtpConnection(ftpParameter, function() {
          var errorMsg;
          if (response && response.Succeed && response.Data && response.Data.Result && response.Data.Result === 'Succeeded') {
            return deferred.resolve({
              success: 'true'
            });
          } else {
            errorMsg = '';
            if (response.Data && response.Data && response.Data.ResultMessage) {
              errorMsg += response.Data.ResultMessage;
              return deferred.reject({
                success: 'false',
                msg: errorMsg
              });
            } else {
              if (response.ErrorMessage) {
                errorMsg += response.ErrorMessage;
                return deferred.reject({
                  success: 'false',
                  msg: errorMsg
                });
              }
            }
          }
        }, function(error) {
          var errorMsg;
          errorMsg = '';
          deferred.reject({
            success: 'none',
            msg: errorMsg
          });
          return common.ShowAPIError('FTP connection testing function is unavailable.', error.data);
        });
        return deferred.promise;
      };
      return {
        query: query,
        data: data,
        createItem: createItem,
        editItem: editItem,
        reset: reset,
        getData: getData,
        getData2: getData2,
        testFtpConnection: testFtpConnection
      };
    }
  ]);

}).call(this);
