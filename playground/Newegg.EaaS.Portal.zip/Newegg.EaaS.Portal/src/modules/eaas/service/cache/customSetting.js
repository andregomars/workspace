﻿(function() {

  angular.module("eaas-cache-customSettingCache", []).factory("customSettingCache", [
    'customsettingAPI', '$filter', 'messager', 'common', function(customsettingAPI, $filter, messager, common) {
      var ActivateSettingCache, CacheOrganId, CategoryName, CollatorCategoryList, CollatorSettingDisplayName, CollatorTransactionTypeList, GetIndustry, GetSettingCache, GetSettingCacheBySettingId, GetSettingName, HasCache, RefreshData, _organId, _settingCache;
      CategoryName = {
        Industry: 'Industry',
        TransactionType: 'TransactionType',
        IdentityQualifier: 'IdentityQualifier',
        AuthorizationQualifier: 'AuthorizationQualifier',
        SecurityQualifier: 'SecurityQualifier',
        StandardQualifier: 'StandardQualifier',
        X12Standards: 'X12Standards',
        UsageIndicator: 'UsageIndicator',
        GS4: 'GS4',
        GS5: 'GS5',
        GS7: 'GS7',
        TargetNamespace: 'TargetNamespace',
        TrailingSeparatorPolicy: 'TrailingSeparatorPolicy',
        X12CharacterSet: 'X12CharacterSet'
      };
      _settingCache = null;
      _organId = null;
      HasCache = function(organId) {
        if (_settingCache && organId === _organId) {
          return true;
        }
        return false;
      };
      CacheOrganId = function() {
        return _organId;
      };
      RefreshData = function(callBackFunc, organId) {
        _organId = organId;
        return customsettingAPI.search({
          organizationid: organId
        }, function(result) {
          var orderResult;
          if (result && result.Succeeded) {
            orderResult = $filter('orderBy')(result.CustomSettingList, 'Code');
            CollatorCategoryList(orderResult, organId);
            if (callBackFunc) {
              return callBackFunc();
            }
          } else {
            return common.ShowAPIError('Get setting data failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get setting data failed.', error.data);
        });
      };
      GetIndustry = function(id) {
        var index, industry, industryList;
        industryList = _settingCache[CategoryName.Industry].CacheList;
        industry = null;
        for (index in industryList) {
          if (industryList[index].Id === id) {
            industry = industryList[index];
          }
        }
        return industry;
      };
      CollatorTransactionTypeList = function() {
        var index, industry, transactionTypeList, _results;
        if (_settingCache[CategoryName.TransactionType] && _settingCache[CategoryName.TransactionType].CacheList) {
          transactionTypeList = _settingCache[CategoryName.TransactionType].CacheList;
          _results = [];
          for (index in transactionTypeList) {
            industry = GetIndustry(transactionTypeList[index].ParentSettingID);
            if (industry) {
              transactionTypeList[index].industryType = industry.Name;
              _results.push(transactionTypeList[index].industryCodeType = industry.Code);
            } else {
              _results.push(void 0);
            }
          }
          return _results;
        }
      };
      GetSettingCache = function(category) {
        var cacheList, msg;
        cacheList = null;
        if (_settingCache && _settingCache[category] && _settingCache[category].CacheList) {
          cacheList = _settingCache[category].CacheList;
        }
        if (!cacheList || cacheList.length < 1) {
          msg = 'The predefined settings for category \"' + category.toString() + '\" not found, please contact administrator for assistance.';
          messager.error(msg, true);
        }
        return cacheList;
      };
      GetSettingCacheBySettingId = function(category, id) {
        var index, setting;
        setting = null;
        if (_settingCache[category] && _settingCache[category].CacheList) {
          for (index in _settingCache[category].CacheList) {
            if (_settingCache[category].CacheList[index].Id === id) {
              setting = _settingCache[category].CacheList[index];
            }
          }
        }
        return setting;
      };
      CollatorSettingDisplayName = function(settingList) {
        var index, _results;
        _results = [];
        for (index in settingList) {
          _results.push(settingList[index].DisplayName = settingList[index].Code + ' - ' + settingList[index].Name);
        }
        return _results;
      };
      GetSettingName = function(category, code) {
        var index, name;
        name = null;
        if (_settingCache && _settingCache[category] && _settingCache[category].CacheList) {
          for (index in _settingCache[category].CacheList) {
            if (_settingCache[category].CacheList[index].Code === code) {
              name = _settingCache[category].CacheList[index].Name;
            }
          }
        }
        return name;
      };
      ActivateSettingCache = function(delegate, organId) {
        if (HasCache() === false) {
          return RefreshData(delegate, organId);
        } else {
          return delegate();
        }
      };
      CollatorCategoryList = function(dicList, organId) {
        var index;
        _settingCache = {};
        for (index in dicList) {
          if (dicList[index].OrganizationID !== organId) {
            continue;
          }
          if (!_settingCache[dicList[index].Category]) {
            _settingCache[dicList[index].Category] = {};
            _settingCache[dicList[index].Category].CacheList = [];
          }
          _settingCache[dicList[index].Category].CacheList.push(dicList[index]);
        }
        CollatorTransactionTypeList();
        if (dicList.length < 1) {
          return _settingCache = null;
        }
      };
      return {
        CategoryName: CategoryName,
        RefreshData: RefreshData,
        HasCache: HasCache,
        GetSettingCache: GetSettingCache,
        CollatorSettingDisplayName: CollatorSettingDisplayName,
        GetSettingName: GetSettingName,
        ActivateSettingCache: ActivateSettingCache,
        GetSettingCacheBySettingId: GetSettingCacheBySettingId
      };
    }
  ]);

}).call(this);
