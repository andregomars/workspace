﻿
angular.module("eaas-cache-organization", []).factory('organization', [
  "common", function(common) {
    var data, query, reset, viewItem;
    viewItem = {};
    data = [];
    query = {
      id: null,
      name: null
    };
    reset = function() {
      if (common.current.isBackPage === true) {
        return common.current.isBackPage = false;
      } else {
        query.id = null;
        return query.name = null;
      }
    };
    return {
      query: query,
      data: data,
      reset: reset,
      viewItem: viewItem
    };
  }
]);
