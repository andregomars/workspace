﻿(function() {

  angular.module("eaas-cache-actionLog", []).factory("actionLog", [
    function() {
      var data, query, reset;
      data = [];
      query = {};
      reset = function() {
        if (common.current.isBackPage === true) {
          return common.current.isBackPage = false;
        } else {
          return query = {};
        }
      };
      return {
        query: query,
        data: data,
        reset: reset
      };
    }
  ]);

}).call(this);
