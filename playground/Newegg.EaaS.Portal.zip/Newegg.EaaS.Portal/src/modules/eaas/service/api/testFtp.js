﻿(function() {

  angular.module("eaas-api-testFtp", ["ngResource"]).factory('testFtpAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + apiSetting.testFTPAPIUrl, {}, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name',
            ownerID: '@ownerID',
            ownerType: '@ownerType',
            protocolType: '@protocolType',
            encodingProtocol: '@encodingProtocol',
            basicInfoOnly: '@basicInfoOnly'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        testFtpConnection: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "DELETE",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id',
            protocolType: '@protocolType',
            ownerID: '@ownerID',
            ownerType: '@ownerType'
          }
        }
      });
    }
  ]);

}).call(this);
