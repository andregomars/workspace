﻿(function() {

  angular.module("eaas-api-schema", ["ngResource"]).factory('schemaAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/schema", {
        id: '@id',
        name: '@name'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name',
            file: '@file',
            ownerID: '@ownerID',
            ownerType: '@ownerType',
            transactionType: '@transactionType'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id',
            ownerid: '@ownerid',
            ownertype: '@ownertype'
          }
        }
      });
    }
  ]);

}).call(this);
