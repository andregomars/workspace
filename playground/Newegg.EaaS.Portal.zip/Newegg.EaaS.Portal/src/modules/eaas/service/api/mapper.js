﻿(function() {

  angular.module("eaas-api-mapper", ["ngResource"]).factory('mapperAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/mapper/", {}, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name',
            schema: '@schema',
            file: '@file'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "DELETE",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id',
            ownerid: '@ownerid',
            ownertype: '@ownertype'
          }
        }
      });
    }
  ]);

}).call(this);
