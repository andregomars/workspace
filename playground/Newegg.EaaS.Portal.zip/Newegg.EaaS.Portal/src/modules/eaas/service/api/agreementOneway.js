﻿(function() {

  angular.module("eaas-api-agreementOneway", ["ngResource"]).factory('agreementOnewayAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/agreement-oneway", {
        id: '@id',
        agreementID: '@agreementID'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            agreementID: '@agreementID',
            station: '@station',
            protocolX12: '@protocolX12',
            transportProtocol: '@transportProtocol',
            agreementTransactionList: '@agreementTransactionList'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "DELETE",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id'
          }
        }
      });
    }
  ]);

}).call(this);
