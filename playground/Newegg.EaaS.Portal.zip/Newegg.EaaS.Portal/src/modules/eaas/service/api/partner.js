﻿(function() {

  angular.module("eaas-api-partner", ["ngResource"]).factory('partnerAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/partner/:action", {
        action: '@action'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name',
            status: '@status',
            type: '@type',
            contact: '@contact',
            certificate: '@certificate',
            station: '@station'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id'
          }
        },
        updateStatus: {
          method: "GET",
          params: {
            id: '@id'
          }
        }
      });
    }
  ]);

}).call(this);
