﻿(function() {

  angular.module("eaas-api-account", ["ngResource"]).factory('accountAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/account/:action", {
        action: '@action'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            loginname: '@loginname',
            type: '@type',
            status: '@status',
            contact: '@contact'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          params: {
            id: '@id'
          },
          timeout: apiSetting.apiTimeOut.operation
        },
        updateStatus: {
          method: "GET",
          params: {
            id: '@id'
          },
          timeout: apiSetting.apiTimeOut.operation
        }
      });
    }
  ]);

}).call(this);
