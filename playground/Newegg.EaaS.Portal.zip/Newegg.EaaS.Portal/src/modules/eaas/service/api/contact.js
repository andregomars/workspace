﻿(function() {

  angular.module("eaas-api-contact", ["ngResource"]).factory('contactAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/contact/", {}, {
        search: {
          method: "GET",
          params: {
            id: '@id'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        }
      });
    }
  ]);

}).call(this);
