(function() {

  angular.module("eaas-api-loadbalance", ["ngResource"]).factory('loadbalanceAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/maintenance/load-balance/heart-beating", {}, {
        search: {
          method: "GET",
          headers: {
            'Authorization': '0db62b68c71e40620cacc9549e4f3b14&0f76a5caa3c910803adb8f145ac154ea'
          },
          params: {
            organizationID: '@organizationID',
            serverName: '@serverName',
            status: '@status',
            highestPriorityOnly: '@highestPriorityOnly'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        edit: {
          method: "PUT",
          headers: {
            'Authorization': '0db62b68c71e40620cacc9549e4f3b14&0f76a5caa3c910803adb8f145ac154ea'
          },
          params: {
            organizationID: '@organizationID',
            serverName: '@serverName',
            status: '@status',
            isForced: '@isForced',
            priority: '@priority'
          },
          timeout: apiSetting.apiTimeOut.operation
        }
      });
    }
  ]);

}).call(this);
