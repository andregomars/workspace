﻿(function() {

  angular.module("eaas-api-customsetting", ["ngResource"]).factory('customsettingAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/custom-setting/", {}, {
        search: {
          method: "GET",
          params: {
            category: '@category'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id'
          }
        }
      });
    }
  ]);

}).call(this);
