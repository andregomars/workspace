﻿(function() {

  angular.module("eaas-api-versionHistory", ["ngResource"]).factory('versionHistoryAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/maintenance/version-history", {}, {
        search: {
          headers: {
            "If-Modified-Since": "Sat, 28 Nov 2009 01:00:00 GMT"
          },
          method: "GET",
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        }
      });
    }
  ]);

}).call(this);
