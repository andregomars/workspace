﻿
angular.module("eaas-api-message", ["ngResource"]).factory('messageAPI', [
  "$resource", "apiSetting", function($resource, apiSetting) {
    return $resource(apiSetting.baseAPIUrl + "/monitor/message/:action/:action2", {
      action: '@action',
      action2: '@action2'
    }, {
      search: {
        method: "POST",
        isArray: false,
        timeout: apiSetting.apiTimeOut.retrieve
      },
      retry: {
        method: "POST",
        isArray: false,
        timeout: apiSetting.apiTimeOut.operation
      },
      getFile: {
        method: "GET",
        isArray: false,
        timeout: apiSetting.apiTimeOut.retrieve
      }
    });
  }
]);
