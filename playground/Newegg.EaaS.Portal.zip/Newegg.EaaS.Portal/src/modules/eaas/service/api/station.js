﻿(function() {

  angular.module("eaas-api-station", ["ngResource"]).factory('stationAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/station/:action", {
        action: '@action'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            partnerid: '@partnerid',
            contact: '@contact',
            schema: '@schema',
            customSettingValue: '@customSettingValue',
            settingid: '@settingid',
            status: '@status'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id',
            partnerid: '@partnerid'
          }
        },
        updateStatus: {
          method: "GET",
          params: {
            id: '@id'
          }
        }
      });
    }
  ]);

}).call(this);
