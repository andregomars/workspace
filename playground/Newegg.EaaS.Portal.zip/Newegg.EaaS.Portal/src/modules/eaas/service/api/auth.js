﻿(function() {

  angular.module("eaas-api-auth", ["ngResource"]).factory('authAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/auth/:action", {
        action: '@action'
      }, {
        request: {
          method: "GET",
          params: {
            loginName: '@loginname',
            password: '@type',
            loginExpires: '@loginExpires',
            expirationTimeUnit: '@expirationTimeUnit',
            expirationTimeSpan: '@expirationTimeSpan'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.auth
        }
      });
    }
  ]);

}).call(this);
