﻿(function() {

  angular.module("eaas-api-agreementTransaction", ["ngResource"]).factory('agreementTransactionAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/agreement-transaction", {
        id: '@id',
        name: '@name'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "DELETE",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id'
          }
        }
      });
    }
  ]);

}).call(this);
