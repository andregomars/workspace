﻿(function() {

  angular.module("eaas-api-monitor", ["ngResource"]).factory('monitorAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/monitor/statistics/:action", {
        action: '@action'
      }, {
        search: {
          method: "POST",
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        }
      });
    }
  ]);

}).call(this);
