﻿(function() {

  angular.module("eaas-api-certificate", ["ngResource"]).factory('certificateAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/certificate/", {}, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            status: '@status',
            validto: '@type',
            purpose: '@purpose',
            isUsed: '@isUsed',
            file: null
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id',
            ownerid: '@ownerid',
            ownertype: '@ownertype'
          }
        }
      });
    }
  ]);

}).call(this);
