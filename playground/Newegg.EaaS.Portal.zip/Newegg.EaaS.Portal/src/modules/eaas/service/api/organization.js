﻿(function() {

  angular.module("eaas-api-organization", ["ngResource"]).factory('organizationAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/organization", {
        id: '@id',
        name: '@name',
        contact: '@contact',
        certificate: '@certificate'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name',
            contact: '@contact',
            certificate: '@certificate'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          params: {
            id: '@id'
          },
          timeout: apiSetting.apiTimeOut.operation
        }
      });
    }
  ]);

}).call(this);
