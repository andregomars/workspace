﻿(function() {

  angular.module("eaas-api-agreement", ["ngResource"]).factory('agreementAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/agreement/:action", {
        action: '@action'
      }, {
        search: {
          method: "GET",
          params: {
            id: '@id',
            name: '@name',
            status: '@status',
            agreementOneway: '@agreementOneway',
            station: '@station',
            localStationID: '@localStationID',
            tradingStationID: '@tradingStationID'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "DELETE",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id'
          }
        },
        updateStatus: {
          method: "GET",
          params: {
            id: '@id'
          }
        }
      });
    }
  ]);

}).call(this);
