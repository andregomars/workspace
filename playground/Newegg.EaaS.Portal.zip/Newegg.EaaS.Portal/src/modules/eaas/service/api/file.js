﻿(function() {

  angular.module("eaas-api-file", ["ngResource"]).factory('fileAPI', [
    "$resource", "apiSetting", function($resource, apiSetting) {
      return $resource(apiSetting.baseAPIUrl + "/file/", {}, {
        search: {
          method: "GET",
          params: {
            id: '@id'
          },
          isArray: false,
          timeout: apiSetting.apiTimeOut.retrieve
        },
        create: {
          method: "POST",
          timeout: apiSetting.apiTimeOut.operation
        },
        edit: {
          method: "PUT",
          timeout: apiSetting.apiTimeOut.operation
        },
        remove: {
          method: "Delete",
          timeout: apiSetting.apiTimeOut.operation,
          params: {
            id: '@id',
            ownerid: '@ownerid',
            ownertype: '@ownertype'
          }
        }
      });
    }
  ]);

}).call(this);
