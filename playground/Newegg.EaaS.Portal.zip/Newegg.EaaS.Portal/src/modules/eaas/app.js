﻿(function() {

  angular.module('eaas', ['eaas-system', 'eaas-service', 'eaas-directive']);

}).call(this);
