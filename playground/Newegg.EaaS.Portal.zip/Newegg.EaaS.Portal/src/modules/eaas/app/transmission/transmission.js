﻿(function() {

  angular.module('eaas-transmission', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/transmission", {
        templateUrl: "/modules/eaas/app/transmission/transmission.tpl.html",
        controller: 'EaaSTransmissionCtrl'
      });
    }
  ]).controller('EaaSTransmissionCtrl', [
    "$scope", "$window", "messager", "common", "transmission", "transmissionAPI", function($scope, $window, messager, common, transmission, transmissionAPI) {
      var pageName;
      $scope.query = angular.copy(transmission.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Name',
            value: 'name'
          }, {
            text: 'Description',
            value: 'description'
          }
        ];
        $scope.query.queryField = 'name';
        $scope.query.protocolType = null;
        $scope.query.direction = null;
        common.InitQueryFields($scope.query);
      }
      $scope.query.pageSize = common.getPageSize(400, 130);
      $scope.query.basicInfoOnly = true;
      $scope.query.encodingprotocol = false;
      $scope.owner = {
        Id: common.currentOrganization.Id,
        Name: common.currentOrganization.Name,
        Type: 'Organization'
      };
      $scope.common = common;
      pageName = common.currentRoutePath();
      $scope.owner = {
        Id: common.currentOrganization.Id,
        Name: common.currentOrganization.Name,
        Type: 'Organization'
      };
      pageName = common.currentRoutePath();
      $scope.initPartnerOwnerInfo = function() {
        $scope.query.ownerID = common.current.link[pageName].pageParameter.Partner.Id;
        $scope.query.ownerType = 'Partner';
        $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
        $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
        return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
      };
      $scope.initStationOwnerInfo = function() {
        $scope.query.ownerID = common.current.link[pageName].pageParameter.Station.Id;
        $scope.query.ownerType = 'Station';
        $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
        $scope.owner.Name = common.current.link[pageName].pageParameter.Station.Name;
        return $scope.owner.Type = common.current.link[pageName].pageParameter.Station.PartnerType + ' Station';
      };
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
          if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
            $scope.initStationOwnerInfo();
          } else {
            if (common.current.link[pageName].pageParameter.Partner) {
              $scope.initPartnerOwnerInfo();
            }
          }
        }
      } else {
        common.current.link[pageName] = null;
        $scope.query.ownerID = null;
        $scope.query.ownerType = null;
        transmission.reset();
      }
      $scope.add = function() {
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          return common.navigate('transmission/create', {
            Station: common.current.link[pageName].pageParameter.Station,
            Partner: common.current.link[pageName].pageParameter.Partner
          });
        } else {
          if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
            return common.navigate('transmission/create', {
              Partner: common.current.link[pageName].pageParameter.Partner
            });
          } else {
            return common.navigate('transmission/create');
          }
        }
      };
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.filterType = "all";
      $scope.showLoading = true;
      $scope.search = function() {
        var requestItem, response;
        $scope.message = 'Loading...';
        requestItem = angular.copy($scope.query);
        transmission.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return response = transmissionAPI.search(requestItem, function() {
          if (response && response.Succeeded) {
            $scope.query.totalItems = response.TotalRecordCount;
            $scope.data = response.ProtocolList;
            transmission.data = response.ProtocolList;
            return common.loadOwnerInfo($scope.data);
          } else {
            return common.ShowAPIError('Get transmission data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get transmission data failed.', error.data);
        });
      };
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      if ($scope.query && $scope.query.protocolType) {
        $scope.filterType = $scope.query.protocolType;
      } else if ($scope.query && $scope.query.direction) {
        $scope.filterType = $scope.query.direction;
      }
      $scope.promise = $scope.search();
      $scope.filterAll = function(type) {
        $scope.query.protocolType = null;
        $scope.query.direction = null;
        return $scope.filter(type);
      };
      $scope.filterTransmissionType = function(type) {
        $scope.query.protocolType = type;
        $scope.query.direction = null;
        return $scope.filter(type);
      };
      $scope.filterDirection = function(type) {
        $scope.query.protocolType = null;
        $scope.query.direction = type;
        return $scope.filter(type);
      };
      $scope.filter = function(type) {
        $scope.filterType = type;
        return $scope.advancedSearch();
      };
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.remove = function(entity) {
        return common.ConfirmBox("Do you want to remove the \"" + entity.Name + "\" transmission?", null, function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.removeTransmission(entity);
        });
      };
      $scope.removeTransmission = function(entity) {
        var response;
        return response = transmissionAPI.remove({
          id: entity.Id,
          protocolType: entity.ProtocolType,
          ownerID: entity.OwnerID,
          ownerType: entity.OwnerType
        }, function() {
          if (response && response.Succeeded) {
            messager.success("Remove transmission successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError('Remove transmission failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Remove transmission failed.', error.data);
        });
      };
      return $scope.edit = function(editItem) {
        transmission.editItem.Protocol = editItem;
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          return common.navigate('transmission/edit', {
            Station: common.current.link[pageName].pageParameter.Station,
            Partner: common.current.link[pageName].pageParameter.Partner
          });
        } else {
          if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
            return common.navigate('transmission/edit', {
              Partner: common.current.link[pageName].pageParameter.Partner
            });
          } else {
            return common.navigate('transmission/edit');
          }
        }
      };
    }
  ]);

}).call(this);
