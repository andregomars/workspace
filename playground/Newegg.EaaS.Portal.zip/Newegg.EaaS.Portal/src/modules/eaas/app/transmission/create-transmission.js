﻿
angular.module('eaas-create-transmission', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/transmission/create", {
      templateUrl: "/modules/eaas/app/transmission/create-transmission.tpl.html",
      controller: 'EaaSCreateTransmissionCtrl'
    });
  }
]).controller('EaaSCreateTransmissionCtrl', [
  "$scope", "$fileUploader", "messager", "common", "transmission", "transmissionAPI", "certificate", 'certificateAPI', 'partnerAPI', 'stationAPI', '$q', function($scope, $fileUploader, messager, common, transmission, transmissionAPI, certificate, certificateAPI, partnerAPI, stationAPI, $q) {
    var pageName, uploader;
    $scope.transferObj = {
      isSucceed: true,
      action: 'create',
      objName: 'transmission',
      title: 'Transmission has been created successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.certificate = {
      showValid: false
    };
    $scope.uploadCertificate = null;
    $scope.selectedCertificate = null;
    $scope.isSubmit = false;
    $scope.port = 21;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.template = '%SourceFileName%';
    $scope.pattern = '*';
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization'
    };
    pageName = common.currentRoutePath();
    $scope.initStationOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link.station.Name;
      return $scope.owner.Type = common.current.link.station.PartnerType + ' Station';
    };
    $scope.initPartnerOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        $scope.initStationOwnerInfo();
      } else {
        if (common.current.link[pageName].pageParameter.Partner) {
          $scope.initPartnerOwnerInfo();
        }
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      }
    }
    $scope.enableChooseStation = true;
    $scope.enableChoosePartner = true;
    $scope.belongId = null;
    $scope.belongType = null;
    $scope.loadBelongTo = false;
    $scope.setOwnerByUerRole = true;
    $scope.fromPageNavigate = function() {
      if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner && common.current.link[pageName].pageParameter.Station) {
        $scope.belongType = 'Station';
        $scope.belongId = common.current.link[pageName].pageParameter.Station.Id;
        $scope.autoSetOwnerInfo = false;
        $scope.setOwnerByUerRole = false;
        $scope.loadBelongTo = true;
        $scope.enableChoosePartner = false;
        return $scope.enableChooseStation = false;
      } else {
        if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          $scope.belongType = 'Partner';
          $scope.belongId = common.current.link[pageName].pageParameter.Partner.Id;
          $scope.autoSetOwnerInfo = false;
          $scope.setOwnerByUerRole = false;
          $scope.loadBelongTo = true;
          return $scope.enableChoosePartner = false;
        } else {
          $scope.autoSetOwnerInfo = true;
          return $scope.loadBelongTo = true;
        }
      }
    };
    $scope.promise = $scope.fromPageNavigate();
    $scope.testFtpConnection = function() {
      var testFTPObject;
      $scope.isTestingFtp = true;
      $scope.testResult = '';
      $scope.showResult = false;
      testFTPObject = {
        Server: $scope.server,
        Port: $scope.port,
        UserName: $scope.userName,
        Password: $scope.ftpPassword,
        Path: $scope.remotePath,
        PassiveMode: $scope.passiveMode
      };
      return transmission.testFtpConnection(testFTPObject).then(function(result) {
        $scope.testSuccess = result.success;
        $scope.isTestingFtp = false;
        if ($scope.testSuccess !== 'none') {
          return $scope.showResult = true;
        }
      }, function(result) {
        $scope.testResult = result.msg;
        $scope.testSuccess = result.success;
        $scope.isTestingFtp = false;
        if ($scope.testSuccess !== 'none') {
          return $scope.showResult = true;
        }
      });
    };
    $scope.needMDNChanged = function() {
      if (!$scope.needMDN) {
        return $scope.needSignedMdn = null;
      }
    };
    $scope.mapperFile = {};
    $scope.uploadFile = false;
    $scope.changeUpload = function(change) {
      $scope.uploadFile = change;
      if (change) {
        if ($scope.uploadCertificate && $scope.uploadCertificate.showValid && uploader.queue && uploader.queue.length > 0) {
          $scope.certificate = angular.copy($scope.uploadCertificate);
        } else {
          $scope.certificate = {
            showValid: false
          };
        }
      }
      if (change === false) {
        if ($scope.selectedCertificate !== null) {
          return $scope.certificate = angular.copy($scope.selectedCertificate);
        } else {
          return $scope.certificate = {
            showValid: false
          };
        }
      }
    };
    $scope.encryptionAlgorithm = 'DES3';
    $scope.mdnHashingAlgorithm = 'SHA1';
    $scope.messageShouldBeSigned = true;
    $scope.messageShouldBeCompressed = false;
    $scope.messageShouldBeEncrypted = true;
    $scope.needMDN = true;
    $scope.needSignedMdn = true;
    $scope.passiveMode = false;
    $scope.mqTestingDelivered = false;
    $scope.transmissionType = 'AS2';
    $scope.direction = 'Sending';
    $scope.isSendingMQ = function() {
      return $scope.transmissionType === 'MQ' && $scope.direction === 'Sending';
    };
    $scope.isRecvingMQ = function() {
      return $scope.transmissionType === 'MQ' && $scope.direction !== 'Sending';
    };
    $scope.save = function() {
      if ($scope.transmissionForm.$valid) {
        $scope.ProtocolRequest = {
          Name: $scope.name,
          Description: $scope.description,
          ProtocolType: $scope.transmissionType,
          Direction: $scope.direction
        };
        $scope.ProtocolRequest.OrganizationID = common.currentOrganization.Id;
        $scope.ProtocolRequest.OwnerType = $scope.belongType;
        $scope.ProtocolRequest.OwnerID = $scope.belongId;
        transmission.createItem = {};
        if ($scope.transmissionType === 'AS2') {
          transmission.createItem.ProtocolAS2 = $scope.ProtocolRequest;
          transmission.createItem.ProtocolAS2.AS2ID = $scope.as2ID;
          transmission.createItem.ProtocolAS2.URL = $scope.as2Link;
          transmission.createItem.ProtocolAS2.MessageShouldBeSigned = $scope.messageShouldBeSigned;
          transmission.createItem.ProtocolAS2.MessageShouldBeCompressed = $scope.messageShouldBeCompressed;
          transmission.createItem.ProtocolAS2.MessageShouldBeEncrypted = $scope.messageShouldBeEncrypted;
          transmission.createItem.ProtocolAS2.EncryptionAlgorithm = $scope.encryptionAlgorithm;
          transmission.createItem.ProtocolAS2.NeedMDN = $scope.needMDN;
          transmission.createItem.ProtocolAS2.NeedSignedMdn = $scope.needSignedMdn;
          transmission.createItem.ProtocolAS2.MdnHashingAlgorithm = $scope.mdnHashingAlgorithm;
          if ($scope.certificate.showValid) {
            if ($scope.uploadFile) {
              $scope.certificate.FileList = [];
              $scope.certificate.FileList.push($scope.mapperFile);
              $scope.mapperFile.OwnerType = common.ownerType.certificate;
              $scope.mapperFile.OwnerID = 0;
            }
            transmission.createItem.ProtocolAS2.Certificate = $scope.certificate;
            if ($scope.certificate.Id) {
              transmission.createItem.ProtocolAS2.CertificateID = $scope.certificate.Id;
            }
          } else {
            transmission.createItem.ProtocolAS2.Certificate = null;
          }
          if (!transmission.createItem.ProtocolAS2.CertificateID && transmission.createItem.ProtocolAS2.Certificate) {
            transmission.createItem.ProtocolAS2.Certificate.Purpose = 'Signature';
          }
          if (transmission.createItem.ProtocolAS2.CertificateID && transmission.createItem.ProtocolAS2.Certificate) {
            delete transmission.createItem.ProtocolAS2.Certificate;
          }
        }
        if ($scope.transmissionType === 'FTP') {
          transmission.createItem.ProtocolFtp = $scope.ProtocolRequest;
          transmission.createItem.ProtocolFtp.Server = $scope.server;
          transmission.createItem.ProtocolFtp.Port = $scope.port;
          transmission.createItem.ProtocolFtp.UserName = $scope.userName;
          transmission.createItem.ProtocolFtp.Password = $scope.ftpPassword;
          transmission.createItem.ProtocolFtp.Path = $scope.remotePath;
          transmission.createItem.ProtocolFtp.FileNameTemplate = $scope.template;
          transmission.createItem.ProtocolFtp.PassiveMode = $scope.passiveMode;
          if ($scope.direction === 'Sending') {
            transmission.createItem.ProtocolFtp.FileNameTemplate = $scope.template;
          }
          if ($scope.direction === 'Receiving') {
            transmission.createItem.ProtocolFtp.FileNamePattern = $scope.pattern;
          }
        }
        if ($scope.transmissionType === 'MQ') {
          transmission.createItem.ProtocolMq = $scope.ProtocolRequest;
          if ($scope.direction === 'Sending') {
            transmission.createItem.ProtocolMq.QueueName = $scope.mqName;
            transmission.createItem.ProtocolMq.PublishAPI = $scope.mqPublishAPI;
            transmission.createItem.ProtocolMq.Password = $scope.mqPassword;
          }
          if ($scope.direction === 'Receiving') {
            transmission.createItem.ProtocolMq.SubscriberAPI = $scope.mqSubscriberAPI;
            transmission.createItem.ProtocolMq.TestingDelivered = false;
          } else {
            transmission.createItem.ProtocolMq.TestingDelivered = $scope.mqTestingDelivered;
          }
        }
        if ($scope.transmissionType === 'AS2' && $scope.certificate.Status === 'ExpiresIn30Days') {
          return messager.confirm('Warning', 'The currently selected certificate will expire, whether you continue to add operation.')(function() {
            return $scope.RequestAPI();
          });
        } else {
          return $scope.RequestAPI();
        }
      }
    };
    $scope.RequestAPI = function() {
      var requestItem;
      requestItem = angular.copy(transmission.createItem);
      delete requestItem.Protocol;
      if (requestItem.ProtocolAS2 && requestItem.ProtocolAS2.CertificateID) {
        delete requestItem.ProtocolAS2.Certificate;
      }
      return transmissionAPI.create(requestItem, function(result) {
        $scope.isSubmit = false;
        if (result.Succeeded === true) {
          $scope.transferObj.obj = result.ProtocolList[0];
          return common.navigate('transfer', $scope.transferObj);
        } else {
          if (uploader.queue && uploader.queue.length > 0) {
            uploader.queue[0].isUploaded = false;
          }
          return common.ShowAPIError('Create Transmission Failed', result);
        }
      }, function(error) {
        $scope.isSubmit = false;
        if (uploader.queue && uploader.queue.length > 0) {
          uploader.queue[0].isUploaded = false;
        }
        return common.ShowAPIError('Create Transmission Failed', error.data);
      });
    };
    $scope.getUserSelectedCertificate = function() {
      var index;
      certificate = {
        showValid: false
      };
      for (index in $scope.certificateList) {
        if ($scope.certificateList[index].selected === true) {
          $scope.certificateList[index].showValid = true;
          certificate = $scope.certificateList[index];
        }
      }
      return certificate;
    };
    $scope.singleSelect = function(certificate) {
      var index, _results;
      _results = [];
      for (index in $scope.certificateList) {
        if ($scope.certificateList[index].Id === certificate.Id) {
          continue;
        } else {
          _results.push($scope.certificateList[index].selected = false);
        }
      }
      return _results;
    };
    $scope.getCertificateData = function() {
      var response;
      if ($scope.certificateList && $scope.certificateList.length > 0) {
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      } else {
        $scope.showCertificateLoading = true;
        return response = certificateAPI.search({
          purpose: 'Signature'
        }, function() {
          $scope.showCertificateLoading = false;
          if (response && response.Succeeded) {
            $scope.certificateList = response.CertificateList;
            $scope.initCertificateData();
            return $scope.syncCertificateData();
          }
        });
      }
    };
    $scope.syncCertificateData = function() {
      if ($scope.certificate) {
        certificate = $scope.getSelectedCertificateById($scope.certificate.Id);
        if (certificate) {
          return certificate.selected = true;
        }
      }
    };
    $scope.getSelectedCertificateById = function(id) {
      var index;
      for (index in $scope.certificateList) {
        if ($scope.certificateList[index].Id === id) {
          return $scope.certificateList[index];
        }
      }
    };
    $scope.filterUsedCertificate = function(certificate) {
      var index, _results;
      _results = [];
      for (index in $scope.filterCertificateList) {
        if ($scope.filterCertificateList[index].OwnerType === 'Protocol' && $scope.filterCertificateList[index].ThumbPrint === certificate.ThumbPrint) {
          _results.push(certificate.show = false);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.initCertificateData = function() {
      var index, _results;
      $scope.filterCertificateList = $scope.certificateList;
      _results = [];
      for (index in $scope.certificateList) {
        $scope.certificateList[index].selected = false;
        $scope.certificateList[index].show = true;
        if (common.validateCertificate($scope.certificateList[index]) === false) {
          $scope.certificateList[index].show = false;
          continue;
        }
        if ($scope.certificateList[index].OwnerType !== 'Organization') {
          _results.push($scope.certificateList[index].show = false);
        } else {
          _results.push($scope.filterUsedCertificate($scope.certificateList[index]));
        }
      }
      return _results;
    };
    $scope.openCertificateDialog = function() {
      $scope.addCertificateModal = true;
      return $scope.promiseCertificate = $scope.getCertificateData();
    };
    $scope.closeCertificateDialog = function() {
      return $scope.addCertificateModal = false;
    };
    $scope.SelectedCertificateOK = function() {
      var response;
      certificate = $scope.getUserSelectedCertificate();
      if (certificate.Id) {
        return response = certificateAPI.search({
          file: true,
          id: certificate.Id
        }, function() {
          var fullCertificate;
          if (response && response.Succeeded) {
            if (response.CertificateList && response.CertificateList.length > 0) {
              fullCertificate = response.CertificateList[0];
              fullCertificate.showValid = certificate.showValid;
              $scope.certificate = fullCertificate;
              $scope.selectedCertificate = angular.copy(fullCertificate);
              return $scope.addCertificateModal = false;
            }
          } else {
            return messager.error("Get certificate data error.");
          }
        });
      } else {
        $scope.certificate = certificate;
        $scope.selectedCertificate = angular.copy(certificate);
        return $scope.addCertificateModal = false;
      }
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=certificate.cer&filetype=certificate&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = false;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) === 'cer' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'pfx') {
            valid = true;
          }
          if (valid === false) {
            messager.error("File extension name must be cer or pfx.");
          }
          $scope.mapperFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        if (common.validateCertificate(msg.Certificate) === false) {
          messager.error("The certificate file is expired.");
          uploader.queue[0].isUploaded = false;
          $scope.isSubmit = false;
          return;
        }
        if (msg.Certificate.Status !== 'Valid') {
          messager.info("The certificate file will be expired in 30 days.");
        }
        $scope.mapperFile.Url = msg.File.Url;
        $scope.mapperFile.OriginalName = msg.File.OriginalName;
        $scope.mapperFile.Size = msg.File.Size;
        $scope.mapperFile.SubType = 'Main';
        $scope.mapperFile.Hash = msg.File.Hash;
        $scope.uploadCertificate = {};
        $scope.uploadCertificate.Subject = msg.Certificate.Subject;
        $scope.uploadCertificate.ThumbPrint = msg.Certificate.ThumbPrint;
        $scope.uploadCertificate.ValidFrom = msg.Certificate.ValidFrom;
        $scope.uploadCertificate.ValidTo = msg.Certificate.ValidTo;
        $scope.uploadCertificate.IssueBy = msg.Certificate.IssueBy;
        $scope.uploadCertificate.IssueTo = msg.Certificate.IssueTo;
        $scope.uploadCertificate.showValid = true;
        $scope.certificate = angular.copy($scope.uploadCertificate);
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        $scope.isSubmit = false;
        if (msg.Errors && msg.Errors.length > 0 && msg.Certificate) {
          return messager.error(msg.Errors[0].Message + '<br/>ThumbPrint:' + msg.Certificate.ThumbPrint);
        } else {
          return messager.error("The certificate file is not correct.");
        }
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.mapperFile = {};
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      return common.ShowAPIError('Upload file Failed', msg);
    });
    uploader.bind('afteraddingfile', function(event, item) {});
    uploader.bind('clearAll', function(event, item) {
      if (uploader.queue && uploader.queue.length === 0) {
        return $scope.certificate = {
          showValid: false
        };
      }
    });
    $scope.submit = function() {
      if ($scope.transmissionForm.$valid) {
        if ($scope.transmissionType === 'AS2' && $scope.uploadFile && $scope.uploadValid && uploader.queue && uploader.queue.length > 0) {
          $scope.isSubmit = true;
          uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.mapperFile.OriginalName + "&filetype=certificate&format=json";
          return uploader.uploadItem(uploader.queue[0]);
        } else {
          $scope.isSubmit = true;
          $scope.message = 'Processing...';
          return $scope.promise = $scope.save();
        }
      }
    };
    return $scope.isAddAS2 = function() {
      if ($scope.isSubmit === true) {
        return false;
      }
      return $scope.uploadFile && $scope.transmissionType === 'AS2';
    };
  }
]);
