﻿
angular.module('eaas-edit-transmission', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/transmission/edit", {
      templateUrl: "/modules/eaas/app/transmission/edit-transmission.tpl.html",
      controller: 'EaaSEditTransmissionCtrl'
    });
  }
]).controller('EaaSEditTransmissionCtrl', [
  "$scope", "$location", "$fileUploader", "$routeParams", "messager", "common", "transmission", "transmissionAPI", "certificate", 'certificateAPI', 'partnerAPI', 'stationAPI', '$q', function($scope, $location, $fileUploader, $routeParams, messager, common, transmission, transmissionAPI, certificate, certificateAPI, partnerAPI, stationAPI, $q) {
    var pageName, uploader;
    pageName = common.currentRoutePath();
    if (!transmission.editItem.Protocol && (!common.current.link || !common.current.link[pageName])) {
      $location.path('/transmission', {});
    }
    $scope.transferObj = {
      isSucceed: true,
      action: 'edit',
      objName: 'transmission',
      title: 'Transmission has been updated successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.selectedCertificate = null;
    $scope.transmissionType = null;
    $scope.direction = null;
    $scope.certificate = {
      showValid: false
    };
    $scope.uploadCertificate = null;
    $scope.selectedCertificate = null;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization'
    };
    $scope.initStationOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link.station.Name;
      return $scope.owner.Type = common.current.link.station.PartnerType + ' Station';
    };
    $scope.initPartnerOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        $scope.initStationOwnerInfo();
      } else {
        if (common.current.link[pageName].pageParameter.Partner) {
          $scope.initPartnerOwnerInfo();
        }
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      }
    }
    $scope.enableChooseStation = true;
    $scope.enableChoosePartner = true;
    $scope.belongId = null;
    $scope.belongType = null;
    $scope.loadBelongTo = false;
    $scope.fromPageNavigate = function() {
      if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner && common.current.link[pageName].pageParameter.Station) {
        $scope.belongType = 'Station';
        $scope.belongId = common.current.link[pageName].pageParameter.Station.Id;
        $scope.enableChoosePartner = false;
        $scope.enableChooseStation = false;
      } else {
        if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          $scope.belongType = 'Partner';
          $scope.belongId = common.current.link[pageName].pageParameter.Partner.Id;
          $scope.enableChoosePartner = false;
        } else {
          $scope.belongType = $scope.currentItem.OwnerType;
          $scope.belongId = $scope.currentItem.OwnerID;
        }
      }
      $scope.autoSetOwnerInfo = false;
      return $scope.loadBelongTo = true;
    };
    $scope.needMDNChanged = function() {
      if (!$scope.currentItem.NeedMDN) {
        return $scope.currentItem.NeedSignedMdn = null;
      }
    };
    $scope.mapperFile = {};
    $scope.uploadFile = false;
    $scope.changeUpload = function(change) {
      $scope.uploadFile = change;
      if (change) {
        if ($scope.uploadCertificate && $scope.uploadCertificate.showValid && uploader.queue && uploader.queue.length > 0) {
          $scope.certificate = angular.copy($scope.uploadCertificate);
        } else {
          $scope.certificate = {
            showValid: false
          };
        }
      }
      if (change === false) {
        if ($scope.selectedCertificate !== null) {
          return $scope.certificate = angular.copy($scope.selectedCertificate);
        } else {
          $scope.certificate = angular.copy($scope.currentItem.Certificate);
          return $scope.certificate.showValid = true;
        }
      }
    };
    $scope.bindingData = function() {
      var response;
      return response = transmissionAPI.search({
        basicInfoOnly: false,
        encodingProtocol: true,
        id: transmission.editItem.Protocol.Id,
        protocolType: transmission.editItem.Protocol.ProtocolType
      }, function() {
        if (response && response.Succeeded) {
          delete transmission.editItem.ProtocolFTP;
          delete transmission.editItem.ProtocolMQ;
          delete transmission.editItem.ProtocolAS2;
          if (transmission.editItem.Protocol.ProtocolType === 'AS2') {
            $scope.currentItem = response.ProtocolAs2List[0];
          }
          if (transmission.editItem.Protocol.ProtocolType === 'FTP') {
            $scope.currentItem = response.ProtocolFtpList[0];
          }
          if (transmission.editItem.Protocol.ProtocolType === 'MQ') {
            $scope.currentItem = response.ProtocolMqList[0];
          }
          $scope.transmissionType = transmission.editItem.Protocol.ProtocolType;
          $scope.direction = $scope.currentItem.Direction;
          if ($scope.currentItem.ProtocolType === 'AS2') {
            if ($scope.currentItem.Certificate) {
              $scope.certificate = angular.copy($scope.currentItem.Certificate);
              $scope.certificate.showValid = true;
            } else {
              $scope.currentItem.Certificate = {
                showValid: false,
                Id: -1
              };
            }
          }
          return $scope.fromPageNavigate();
        } else {
          return common.ShowAPIError('Get transmission data Failed', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get transmission data Failed', error.data);
      });
    };
    $scope.promise = $scope.bindingData();
    $scope.isSendingMQ = function() {
      return $scope.transmissionType === 'MQ' && $scope.direction === 'Sending';
    };
    $scope.isRecvingMQ = function() {
      return $scope.transmissionType === 'MQ' && $scope.direction !== 'Sending';
    };
    $scope.testFtpConnection = function() {
      var testFTPObject;
      $scope.isTestingFtp = true;
      $scope.testResult = '';
      $scope.showResult = false;
      testFTPObject = {
        Server: $scope.currentItem.Server,
        Port: $scope.currentItem.Port,
        UserName: $scope.currentItem.UserName,
        Password: $scope.currentItem.Password,
        Path: $scope.currentItem.Path,
        PassiveMode: $scope.currentItem.PassiveMode
      };
      return transmission.testFtpConnection(testFTPObject).then(function(result) {
        debugger;        $scope.testSuccess = result.success;
        $scope.isTestingFtp = false;
        if ($scope.testSuccess !== 'none') {
          return $scope.showResult = true;
        }
      }, function(result) {
        $scope.testResult = result.msg;
        $scope.testSuccess = result.success;
        $scope.isTestingFtp = false;
        if ($scope.testSuccess !== 'none') {
          return $scope.showResult = true;
        }
      });
    };
    $scope.save = function() {
      if ($scope.transmissionForm.$valid) {
        $scope.ProtocolRequest = {
          Id: $scope.currentItem.Id,
          Name: $scope.currentItem.Name,
          Description: $scope.currentItem.Description,
          ProtocolType: $scope.currentItem.ProtocolType,
          Direction: $scope.currentItem.Direction
        };
        $scope.ProtocolRequest.OrganizationID = common.currentOrganization.Id;
        $scope.ProtocolRequest.OwnerType = $scope.belongType;
        $scope.ProtocolRequest.OwnerID = $scope.belongId;
        if ($scope.transmissionType === 'AS2') {
          transmission.editItem.ProtocolAS2 = $scope.ProtocolRequest;
          transmission.editItem.ProtocolAS2.AS2ID = $scope.currentItem.AS2ID;
          transmission.editItem.ProtocolAS2.URL = $scope.currentItem.URL;
          transmission.editItem.ProtocolAS2.MessageShouldBeSigned = $scope.currentItem.MessageShouldBeSigned;
          transmission.editItem.ProtocolAS2.MessageShouldBeCompressed = $scope.currentItem.MessageShouldBeCompressed;
          transmission.editItem.ProtocolAS2.MessageShouldBeEncrypted = $scope.currentItem.MessageShouldBeEncrypted;
          transmission.editItem.ProtocolAS2.EncryptionAlgorithm = $scope.currentItem.EncryptionAlgorithm;
          transmission.editItem.ProtocolAS2.NeedMDN = $scope.currentItem.NeedMDN;
          transmission.editItem.ProtocolAS2.NeedSignedMdn = $scope.currentItem.NeedSignedMdn;
          transmission.editItem.ProtocolAS2.MdnHashingAlgorithm = $scope.currentItem.MdnHashingAlgorithm;
          if ($scope.certificate.showValid) {
            if ($scope.uploadFile) {
              $scope.certificate.FileList = [];
              $scope.certificate.FileList.push($scope.mapperFile);
            }
            transmission.editItem.ProtocolAS2.Certificate = $scope.certificate;
            if ($scope.certificate.Id) {
              transmission.editItem.ProtocolAS2.CertificateID = $scope.certificate.Id;
            }
          } else {
            transmission.editItem.ProtocolAS2.Certificate = null;
            transmission.editItem.ProtocolAS2.CertificateID = null;
          }
          if (!transmission.editItem.ProtocolAS2.CertificateID && transmission.editItem.ProtocolAS2.Certificate) {
            transmission.editItem.ProtocolAS2.Certificate.Purpose = 'Signature';
          }
          if (transmission.editItem.ProtocolAS2.CertificateID && transmission.editItem.ProtocolAS2.Certificate) {
            delete transmission.editItem.ProtocolAS2.Certificate;
          }
        }
        if ($scope.transmissionType === 'FTP') {
          transmission.editItem.ProtocolFTP = $scope.ProtocolRequest;
          transmission.editItem.ProtocolFTP.Server = $scope.currentItem.Server;
          transmission.editItem.ProtocolFTP.Port = $scope.currentItem.Port;
          transmission.editItem.ProtocolFTP.UserName = $scope.currentItem.UserName;
          transmission.editItem.ProtocolFTP.Password = $scope.currentItem.Password;
          transmission.editItem.ProtocolFTP.Path = $scope.currentItem.Path;
          transmission.editItem.ProtocolFTP.FileNameTemplate = $scope.currentItem.FileNameTemplate;
          transmission.editItem.ProtocolFTP.PassiveMode = $scope.currentItem.PassiveMode;
          if ($scope.direction === 'Sending') {
            transmission.editItem.ProtocolFTP.FileNameTemplate = $scope.currentItem.FileNameTemplate;
          }
          if ($scope.direction === 'Receiving') {
            transmission.editItem.ProtocolFTP.FileNamePattern = $scope.currentItem.FileNamePattern;
          }
        }
        if ($scope.transmissionType === 'MQ') {
          transmission.editItem.ProtocolMQ = $scope.ProtocolRequest;
          if ($scope.direction === 'Sending') {
            transmission.editItem.ProtocolMQ.QueueName = $scope.currentItem.QueueName;
            transmission.editItem.ProtocolMQ.PublishAPI = $scope.currentItem.PublishAPI;
            transmission.editItem.ProtocolMQ.Password = $scope.currentItem.Password;
          }
          if ($scope.direction === 'Receiving') {
            transmission.editItem.ProtocolMQ.SubscriberAPI = $scope.currentItem.SubscriberAPI;
          }
          transmission.editItem.ProtocolMQ.TestingDelivered = $scope.currentItem.TestingDelivered;
        }
        if ($scope.transmissionType === 'AS2' && $scope.certificate.Status === 'ExpiresIn30Days') {
          return messager.confirm('Warning', 'The currently selected certificate will expire, whether you continue to add operation.')(function() {
            return $scope.RequestAPI();
          });
        } else {
          return $scope.RequestAPI();
        }
      }
    };
    $scope.RequestAPI = function() {
      var requestItem;
      requestItem = angular.copy(transmission.editItem);
      delete requestItem.Protocol;
      return transmissionAPI.edit(requestItem, function(result) {
        $scope.isSubmit = false;
        if (result.Succeeded === true) {
          $scope.transferObj.obj = {
            Id: $scope.currentItem.Id
          };
          return common.navigate('transfer', $scope.transferObj);
        } else {
          return common.ShowAPIError('Edit transmission failed', result);
        }
      }, function(error) {
        common.ShowAPIError('Edit transmission failed', error.data);
        return $scope.isSubmit = false;
      });
    };
    $scope.getUserSelectedCertificate = function() {
      var index;
      certificate = {
        showValid: false,
        Id: -1
      };
      for (index in $scope.certificateList) {
        if ($scope.certificateList[index].selected === true) {
          $scope.certificateList[index].showValid = true;
          certificate = $scope.certificateList[index];
        }
      }
      return certificate;
    };
    $scope.singleSelect = function(certificate) {
      var index, _results;
      _results = [];
      for (index in $scope.certificateList) {
        if ($scope.certificateList[index].Id === certificate.Id) {
          continue;
        } else {
          _results.push($scope.certificateList[index].selected = false);
        }
      }
      return _results;
    };
    $scope.getCertificateData = function() {
      var response;
      if ($scope.certificateList && $scope.certificateList.length > 0) {
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      } else {
        $scope.showCertificateLoading = true;
        return response = certificateAPI.search({
          purpose: 'Signature'
        }, function() {
          $scope.showCertificateLoading = false;
          if (response && response.Succeeded) {
            $scope.certificateList = response.CertificateList;
            $scope.initCertificateData();
            return $scope.syncCertificateData();
          }
        });
      }
    };
    $scope.syncCertificateData = function() {
      if ($scope.certificate) {
        certificate = $scope.getSelectedCertificateById($scope.certificate.Id);
        if (certificate) {
          return certificate.selected = true;
        }
      }
    };
    $scope.getSelectedCertificateById = function(id) {
      var index;
      for (index in $scope.certificateList) {
        if ($scope.certificateList[index].Id === id) {
          return $scope.certificateList[index];
        }
      }
    };
    $scope.filterUsedCertificate = function(certificate) {
      if (certificate.OwnerType === 'Protocol' && certificate.OwnerID === $scope.currentItem.Id) {
        return certificate.show = true;
      }
    };
    $scope.initCertificateData = function() {
      var index, _results;
      $scope.filterCertificateList = $scope.certificateList;
      _results = [];
      for (index in $scope.certificateList) {
        $scope.certificateList[index].selected = false;
        $scope.certificateList[index].show = true;
        if (common.validateCertificate($scope.certificateList[index]) === false) {
          $scope.certificateList[index].show = false;
          continue;
        }
        if ($scope.certificateList[index].OwnerType !== 'Organization') {
          $scope.certificateList[index].show = false;
        }
        _results.push($scope.filterUsedCertificate($scope.certificateList[index]));
      }
      return _results;
    };
    $scope.openCertificateDialog = function() {
      $scope.addCertificateModal = true;
      return $scope.promiseCertificate = $scope.getCertificateData();
    };
    $scope.closeCertificateDialog = function() {
      return $scope.addCertificateModal = false;
    };
    $scope.SelectedCertificateOK = function() {
      var response;
      certificate = $scope.getUserSelectedCertificate();
      if (!certificate || !certificate.Id || certificate.Id === $scope.currentItem.Certificate.Id && certificate.Id !== -1) {
        certificate = $scope.currentItem.Certificate;
        certificate.showValid = true;
        $scope.certificate = certificate;
        $scope.selectedCertificate = angular.copy(certificate);
        return $scope.addCertificateModal = false;
      } else if (certificate.Id === -1) {
        $scope.certificate = certificate;
        $scope.selectedCertificate = angular.copy(certificate);
        return $scope.addCertificateModal = false;
      } else {
        return response = certificateAPI.search({
          file: true,
          id: certificate.Id
        }, function() {
          var fullCertificate;
          if (response && response.Succeeded) {
            if (response.CertificateList && response.CertificateList.length > 0) {
              fullCertificate = response.CertificateList[0];
              fullCertificate.showValid = certificate.showValid;
              $scope.certificate = fullCertificate;
              $scope.selectedCertificate = angular.copy(fullCertificate);
              return $scope.addCertificateModal = false;
            }
          } else {
            return messager.error("Get certificate data error.");
          }
        });
      }
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=certificate.cer&filetype=certificate&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = false;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) === 'cer' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'pfx') {
            valid = true;
          }
          if (valid === false) {
            messager.error("File extension name must be cer or pfx.");
          }
          $scope.mapperFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        if (common.validateCertificate(msg.Certificate) === false) {
          uploader.queue[0].isUploaded = false;
          messager.error("The certificate file is expired.");
          $scope.isSubmit = false;
          return;
        }
        if (msg.Certificate.Status !== 'Valid') {
          messager.info("The certificate file will be expired in 30 days.");
        }
        $scope.mapperFile.Url = msg.File.Url;
        $scope.mapperFile.OriginalName = msg.File.OriginalName;
        $scope.mapperFile.Size = msg.File.Size;
        $scope.mapperFile.SubType = 'Main';
        $scope.mapperFile.Hash = msg.File.Hash;
        $scope.uploadCertificate = {};
        $scope.uploadCertificate.Subject = msg.Certificate.Subject;
        $scope.uploadCertificate.ThumbPrint = msg.Certificate.ThumbPrint;
        $scope.uploadCertificate.ValidFrom = msg.Certificate.ValidFrom;
        $scope.uploadCertificate.ValidTo = msg.Certificate.ValidTo;
        $scope.uploadCertificate.IssueBy = msg.Certificate.IssueBy;
        $scope.uploadCertificate.IssueTo = msg.Certificate.IssueTo;
        $scope.uploadCertificate.showValid = true;
        $scope.certificate = angular.copy($scope.uploadCertificate);
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        $scope.isSubmit = false;
        uploader.queue[0].isUploaded = false;
        if (msg.Errors && msg.Errors.length > 0 && msg.Certificate) {
          return messager.error(msg.Errors[0].Message + '<br/>ThumbPrint:' + msg.Certificate.ThumbPrint);
        } else {
          return messager.error("The certificate file is not correct.");
        }
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.mapperFile = {};
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      return common.ShowAPIError('Upload file Failed', msg);
    });
    uploader.bind('afteraddingfile', function(event, item) {});
    uploader.bind('clearAll', function(event, item) {
      if (uploader.queue && uploader.queue.length === 0) {
        return $scope.certificate = {
          showValid: false
        };
      }
    });
    $scope.submit = function() {
      if ($scope.transmissionForm.$valid) {
        if ($scope.transmissionType === 'AS2' && $scope.uploadFile && $scope.uploadValid) {
          $scope.isSubmit = true;
          uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.mapperFile.OriginalName + "&filetype=certificate&format=json";
          return uploader.uploadAll();
        } else {
          $scope.isSubmit = true;
          $scope.message = 'Processing...';
          return $scope.promise = $scope.save();
        }
      }
    };
    return $scope.isAddAS2 = function() {
      if ($scope.isSubmit === true) {
        return false;
      }
      return $scope.uploadFile && $scope.transmissionType === 'AS2';
    };
  }
]);
