﻿(function() {

  angular.module('eaas-view-transmission', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/transmission/view", {
        templateUrl: "/modules/eaas/app/transmission/view-transmission.tpl.html",
        controller: 'EaaSViewTransmissionCtrl'
      });
    }
  ]).controller('EaaSViewTransmissionCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "transmission", "schemaAPI", '$fileUploader', 'partnerAPI', 'stationAPI', 'transmissionAPI', function($scope, $http, $window, $filter, messager, common, transmission, schemaAPI, $fileUploader, partnerAPI, stationAPI, transmissionAPI) {
      var pageName;
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'transmission';
      $scope.viewError = false;
      $scope.isSendingMQ = function() {
        return $scope.transmissionType === 'MQ' && $scope.direction === 'Sending';
      };
      $scope.isRecvingMQ = function() {
        return $scope.transmissionType === 'MQ' && $scope.direction !== 'Sending';
      };
      $scope.belongId = null;
      $scope.belongType = null;
      $scope.initViewObject = function() {
        var mdnControlContent, messageControlContent, passiveMode, testingDeliveredContent;
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.currentItem.InUser;
        $scope.generalView.InDate = $scope.currentItem.InDate;
        $scope.generalView.EditUser = $scope.currentItem.EditUser;
        $scope.generalView.EditDate = $scope.currentItem.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Name', $scope.currentItem.Name));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Description', $scope.currentItem.Description));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Type', $scope.currentItem.ProtocolType));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Direction', $scope.currentItem.Direction));
        $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
        if ($scope.transmissionType === 'MQ') {
          $scope.mqView = common.buildViewObject('Message Queue Settings');
          if ($scope.isSendingMQ() === true) {
            $scope.mqView.viewAttList.push(common.buildViewAttr('Message Queue Name', $scope.currentItem.QueueName));
            $scope.mqView.viewAttList.push(common.buildViewAttr('Message Publish API', $scope.currentItem.PublishAPI));
          }
          if ($scope.isRecvingMQ() === true) {
            $scope.mqView.viewAttList.push(common.buildViewAttr('Message Subscriber API', $scope.currentItem.SubscriberAPI));
          }
          if ($scope.currentItem.TestingDelivered) {
            testingDeliveredContent = '';
            if ($scope.currentItem.TestingDelivered === true) {
              testingDeliveredContent = "Yes";
            } else {
              testingDeliveredContent = "No";
            }
            $scope.mqView.viewAttList.push(common.buildViewAttr('Allow Testing Data to be delivered', testingDeliveredContent));
          }
          $scope.mqView.viewAttList = common.clearAttrListNullValue($scope.mqView.viewAttList);
        }
        if ($scope.transmissionType === 'FTP') {
          $scope.ftpView = common.buildViewObject('FTP Transmission Settings');
          $scope.ftpView.viewAttList.push(common.buildViewAttr('Server', $scope.currentItem.Server));
          $scope.ftpView.viewAttList.push(common.buildViewAttr('Port', $scope.currentItem.Port));
          $scope.ftpView.viewAttList.push(common.buildViewAttr('User Name', $scope.currentItem.UserName));
          $scope.ftpView.viewAttList.push(common.buildViewAttr('Remote Path', $scope.currentItem.Path));
          $scope.ftpView.viewAttList.push(common.buildViewAttr('Filename Template', $scope.currentItem.FileNameTemplate));
          $scope.ftpView.viewAttList.push(common.buildViewAttr('Filename Pattern', $scope.currentItem.FileNamePattern));
          if ($scope.currentItem.PassiveMode) {
            if ($scope.currentItem.PassiveMode === true) {
              passiveMode = "Yes";
            } else {
              passiveMode = "No";
            }
          }
          $scope.ftpView.viewAttList.push(common.buildViewAttr('Passive Mode', passiveMode));
          $scope.ftpView.viewAttList = common.clearAttrListNullValue($scope.ftpView.viewAttList);
        }
        if ($scope.transmissionType === 'AS2') {
          $scope.as2View = common.buildViewObject('AS2 Transmission Settings');
          $scope.as2View.viewAttList.push(common.buildViewAttr('AS2 ID', $scope.currentItem.AS2ID));
          $scope.as2View.viewAttList.push(common.buildViewAttr('AS2 Link', $scope.currentItem.URL));
          messageControlContent = [];
          if ($scope.currentItem.MessageShouldBeSigned && $scope.currentItem.MessageShouldBeSigned === true) {
            messageControlContent.push({
              value: 'Message should be signed',
              viewModels: 'checkbox'
            });
          }
          if ($scope.currentItem.MessageShouldBeCompressed && $scope.currentItem.MessageShouldBeCompressed === true) {
            messageControlContent.push({
              value: 'Message should be compressed',
              viewModels: 'checkbox'
            });
          }
          if ($scope.currentItem.MessageShouldBeEncrypted && $scope.currentItem.MessageShouldBeEncrypted === true) {
            messageControlContent.push({
              value: 'Message should be encrypted',
              viewModels: 'checkbox'
            });
          }
          if (messageControlContent.length > 0) {
            if (messageControlContent.length === 1) {
              $scope.as2View.viewAttList.push(common.buildViewAttr('Message Control', messageControlContent[0].value, true, ['checkBoxView'], [true]));
            } else {
              messageControlContent[messageControlContent.length - 1].colspan = 20;
              $scope.as2View.viewAttList.push(common.buildViewAttr('Message Control', '', true, ['multipleAttrView', 'viewMultipleAttList'], [true, messageControlContent]));
            }
          }
          if ($scope.currentItem.MessageShouldBeEncrypted && $scope.currentItem.MessageShouldBeEncrypted === true) {
            $scope.as2View.viewAttList.push(common.buildViewAttr('Encryption Algorithm', $scope.currentItem.EncryptionAlgorithm));
          }
          mdnControlContent = [];
          if ($scope.currentItem.NeedMDN && $scope.currentItem.NeedMDN === true) {
            mdnControlContent.push({
              value: 'Request MDN',
              viewModels: 'checkbox'
            });
          }
          if ($scope.currentItem.NeedMDN && $scope.currentItem.NeedMDN === true && $scope.currentItem.NeedSignedMdn && $scope.currentItem.NeedSignedMdn === true) {
            mdnControlContent.push({
              value: 'Request Signed MDN',
              viewModels: 'checkbox'
            });
          }
          if (mdnControlContent.length > 0) {
            if (mdnControlContent.length === 1) {
              $scope.as2View.viewAttList.push(common.buildViewAttr('MDN Control', mdnControlContent[0].value, true, ['checkBoxView'], [true]));
            } else {
              mdnControlContent[mdnControlContent.length - 1].colspan = 20;
              $scope.as2View.viewAttList.push(common.buildViewAttr('MDN Control', '', true, ['multipleAttrView', 'viewMultipleAttList'], [true, mdnControlContent]));
            }
          }
          if ($scope.currentItem.NeedSignedMdn === true && $scope.currentItem.NeedMDN === true) {
            $scope.as2View.viewAttList.push(common.buildViewAttr('Signing Algorithm', $scope.currentItem.MdnHashingAlgorithm));
          }
          return $scope.as2View.viewAttList = common.clearAttrListNullValue($scope.as2View.viewAttList);
        }
      };
      $scope.initData = function() {
        $scope.transmissionType = $scope.protocolType;
        $scope.direction = $scope.currentItem.Direction;
        if ($scope.currentItem.ProtocolType === 'AS2') {
          if ($scope.currentItem.Certificate) {
            $scope.certificate = angular.copy($scope.currentItem.Certificate);
          }
        }
        transmission.viewItem = angular.copy($scope.currentItem);
        $scope.belongId = $scope.currentItem.OwnerID;
        $scope.belongType = $scope.currentItem.OwnerType;
        $scope.loadBelongTo = true;
        return $scope.initViewObject();
      };
      $scope.getProtocolType = function() {
        var response;
        return response = transmissionAPI.search({
          id: $scope.id
        }, function(response) {
          if (response && response.Succeeded) {
            if (response.ProtocolList && response.ProtocolList.length > 0) {
              $scope.protocolType = response.ProtocolList[0].ProtocolType;
              return $scope.promise = $scope.getData();
            } else {
              return $scope.viewError = true;
            }
          } else {
            return common.ShowAPIError('Get transmission data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get transmission data failed', error.data);
        });
      };
      $scope.getData = function() {
        var response;
        return response = transmissionAPI.search({
          id: $scope.id,
          protocolType: $scope.protocolType,
          encodingProtocol: true,
          basicInfoOnly: false
        }, function() {
          if (response && response.Succeeded) {
            if ($scope.protocolType === null) {
              if (response.ProtocolList && response.ProtocolList.length > 0) {
                $scope.currentItem = response.ProtocolList[0];
                $scope.protocolType = 'AS2';
              }
              if (response.ProtocolFtpList && response.ProtocolFtpList.length > 0) {
                $scope.currentItem = response.ProtocolFtpList[0];
                $scope.protocolType = 'FTP';
              }
              if (response.ProtocolMqList && response.ProtocolMqList.length > 0) {
                $scope.currentItem = response.ProtocolMqList[0];
                $scope.protocolType = 'MQ';
              }
            }
            if ($scope.protocolType === 'AS2') {
              $scope.currentItem = response.ProtocolAs2List[0];
            }
            if ($scope.protocolType === 'FTP') {
              $scope.currentItem = response.ProtocolFtpList[0];
            }
            if ($scope.protocolType === 'MQ') {
              $scope.currentItem = response.ProtocolMqList[0];
            }
            return $scope.promise = $scope.initData();
          } else {
            return common.ShowAPIError('Get transmission data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get transmission data failed', error.data);
        });
      };
      pageName = common.currentRoutePath();
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
        $scope.id = common.current.link[pageName].pageParameter.Id;
        $scope.authItem = angular.copy(common.current.link[pageName].pageParameter);
        $scope.protocolType = null;
        if (common.current.link[pageName].pageParameter.ProtocolType) {
          $scope.protocolType = common.current.link[pageName].pageParameter.ProtocolType;
          $scope.promise = $scope.getData();
        } else {
          $scope.promise = $scope.getProtocolType();
        }
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
          $scope.id = common.current.link[pageName].pageParameter.Id;
          $scope.authItem = angular.copy(common.current.link[pageName].pageParameter);
          $scope.protocolType = null;
          if (common.current.link[pageName].pageParameter.ProtocolType) {
            $scope.protocolType = common.current.link[pageName].pageParameter.ProtocolType;
            $scope.promise = $scope.getData();
          } else {
            $scope.promise = $scope.getProtocolType();
          }
        }
      } else {
        common.navigate('transmission');
      }
      return $scope.edit = function() {
        transmission.editItem.Protocol = $scope.currentItem;
        return common.navigate("transmission/edit");
      };
    }
  ]);

}).call(this);
