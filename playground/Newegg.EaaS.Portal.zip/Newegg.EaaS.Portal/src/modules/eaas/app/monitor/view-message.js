(function() {

  angular.module('eaas-view-message', ['ngRoute', 'duScroll', 'angular-follow']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/message/view", {
        templateUrl: "/modules/eaas/app/monitor/view-message.tpl.html",
        controller: 'EaaSMessageDetailCtrl'
      });
    }
  ]).controller('EaaSMessageDetailCtrl', [
    "$scope", "common", "messager", "message", "messageAPI", function($scope, common, messager, message, messageAPI) {
      var pageName;
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.query = {};
      $scope.query.action = 'tracedetail';
      pageName = common.currentRoutePath();
      $scope.initQueryParameter = function() {
        $scope.currentLevel = common.current.link[common.currentRoutePath()].pageParameter.MessageDetail.Level;
        $scope.query.MasterId = common.current.link[common.currentRoutePath()].pageParameter.MessageDetail.MasterId;
        $scope.query.TransactionId = common.current.link[common.currentRoutePath()].pageParameter.MessageDetail.TransactionId;
        return $scope.query.Level = common.current.link[common.currentRoutePath()].pageParameter.MessageDetail.Level;
      };
      if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.MessageDetail && common.current.link[pageName].pageParameter.MessageDetail.MasterId) {
        $scope.initQueryParameter();
      } else {
        common.navigate('message');
      }
      if (!common.current.link[common.currentRoutePath()].pageParameter) {
        common.back();
      }
      $scope.initQueryParameter();
      $scope.initData = function() {
        var response;
        return response = messageAPI.search($scope.query, function() {
          var index, messageInfo;
          if (response && response.Succeeded) {
            messageInfo = response.MessageInfo;
            if (messageInfo.TraceDetailList && messageInfo.TraceDetailList.length > 0) {
              for (index in messageInfo.TraceDetailList) {
                if (messageInfo.TraceDetailList[index].MessageTypeName && messageInfo.TraceDetailList[index].MessageTypeName === 'Unknown') {
                  messageInfo.TraceDetailList[index].MessageTypeDisplayName = '';
                } else {
                  messageInfo.TraceDetailList[index].MessageTypeDisplayName = messageInfo.TraceDetailList[index].MessageTypeName;
                }
              }
            }
            return $scope.data = messageInfo;
          } else {
            return common.ShowAPIError('Get message detail failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get message detail failed.', error.data);
        });
      };
      $scope.promise = $scope.initData();
      $scope.refresh = function() {
        return $scope.promise = $scope.initData();
      };
      return $scope.retry = function(item) {
        var confirmContent;
        confirmContent = "Are you sure you want to reprocess this message?";
        return common.ConfirmBox(confirmContent, null, function() {
          var requestItem, response;
          requestItem = {};
          requestItem.action = "trace";
          requestItem.action2 = "retry";
          requestItem.MasterId = item.MasterId;
          requestItem.TransactionId = item.TransactionId;
          requestItem.SplitId = item.SplitId;
          requestItem.SubStep = item.SubStep;
          return response = messageAPI.retry(requestItem, function() {
            var successContent;
            if (response && response.Succeeded) {
              successContent = "Request retry operation is successful, please wait for background processing.";
              if ($scope.currentLevel === 'File') {
                successContent = "Request retry operation is successful, Please go to Message page to query the latest result. The message you are trying to re-process may generating different messages due to X12 file disassembling or XML content spliting, it's perfectly normal.";
              }
              return messager.success(successContent);
            } else {
              return common.ShowAPIError('Retry operation failed.', response);
            }
          }, function(error) {
            return common.ShowAPIError('Retry operation failed.', error.data);
          });
        });
      };
    }
  ]);

}).call(this);
