﻿
angular.module('eaas-statistics', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/statistics", {
      templateUrl: "/modules/eaas/app/monitor/statistics.tpl.html",
      controller: 'EaaSStatisticsCtrl'
    });
  }
]).controller('EaaSStatisticsCtrl', [
  "$scope", "$filter", "$interval", "messager", "common", "monitor", "monitorAPI", "organizationAPI", "partnerAPI", "stationAPI", function($scope, $filter, $interval, messager, common, monitor, monitorAPI, organizationAPI, partnerAPI, stationAPI) {
    $scope.common = common;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.query = angular.copy(monitor.query);
    $scope.chartColors = angular.copy(monitor.chartColors);
    $scope.leftID_Total = 'chart_Total_1_parent';
    $scope.rightID_Total = 'chart_Total_2_parent';
    $scope.leftID_failed = 'chart_Failed_1_parent';
    $scope.rightID_failed = 'chart_Failed_2_parent';
    $scope.leftID_avg = 'chart_Avg_1_parent';
    $scope.rightID_avg = 'chart_Avg_2_parent';
    $scope.initCondition = function() {
      $scope.chart_TotalMessage_1_Show = true;
      $scope.chart_TotalMessage_2_Show = true;
      $scope.chart_FailedMessage_1_Show = true;
      $scope.chart_FailedMessage_2_Show = true;
      $scope.chart_AvgMessage_1_Show = true;
      $scope.chart_AvgMessage_2_Show = true;
      $scope.currentStartDate = moment().startOf("week").startOf("day");
      $scope.currentEndDate = moment().endOf("week").startOf("day");
      $scope.query.Period = "Daily";
      $scope.query.dateRange = moment().range($scope.currentStartDate, $scope.currentEndDate);
      $scope.LocalPartnerID = null;
      return $scope.LocalStationID = null;
    };
    $scope.initCacheCondition = function() {
      $scope.cacheLocalPartnerId = $scope.query.LocalPartnerID;
      $scope.cacheLocalStationId = $scope.query.LocalStationID;
      return $scope.query.dateRange = moment().range($scope.query.StartTime, $scope.query.EndTime);
    };
    if (common.current.isBackPage === false) {
      common.InitQueryFields($scope.query);
      $scope.initCondition();
    } else {
      $scope.initCacheCondition();
      common.current.isBackPage = false;
    }
    $scope.orderByType = function(data) {
      if (!data) {
        return [];
      }
      return $filter('orderBy')(data, 'MessageTypeName');
    };
    $scope.getData = function() {
      var avgResponse, failedResponse, totalResponse;
      $scope.loadingDic = true;
      if ($scope.searchForm.$valid) {
        $scope.loadPieChart_TotalMessage([]);
        $scope.loadLineChart_TotalMessage([]);
        $scope.loadBarChart_FailedMessage([]);
        $scope.loadLineChart_FailedMessage([]);
        $scope.loadBarChart_AvgMessage([]);
        $scope.loadLineChart_AvgMessage([]);
        $scope.totalQuery = angular.copy($scope.query);
        $scope.totalQuery.action = 'totalmessage';
        if ($scope.query.dateRange && $scope.query.dateRange.start && $scope.query.dateRange.end) {
          $scope.totalQuery.StartTime = $scope.query.dateRange.start.format('MM/DD/YYYY HH:mm:ss');
          $scope.totalQuery.EndTime = $scope.query.dateRange.end.format('MM/DD/YYYY 23:59:59');
          $scope.query.StartTime = $scope.query.dateRange.start.format('MM/DD/YYYY HH:mm:ss');
          $scope.query.EndTime = $scope.query.dateRange.end.format('MM/DD/YYYY 23:59:59');
        } else {
          messager.error('Must select date range.');
          return;
        }
        totalResponse = monitorAPI.search($scope.totalQuery, function() {
          if (totalResponse && totalResponse.Succeeded) {
            $scope.tempData_total_1 = $scope.orderByType(totalResponse.TotalMessageQuantityList);
            return $scope.tempData_total_2 = $scope.orderByType(totalResponse.MessageQuantityDetailList);
          } else {
            return common.ShowAPIError('Query total message data failed.', totalResponse);
          }
        }, function(error) {
          return common.ShowAPIError('Query total message data failed.', error.data);
        });
        $scope.totalQuery.action = 'failedmessage';
        failedResponse = monitorAPI.search($scope.totalQuery, function() {
          if (failedResponse && failedResponse.Succeeded) {
            $scope.tempData_failed_1 = $scope.orderByType(failedResponse.FailedMessageQuantityList);
            return $scope.tempData_failed_2 = $scope.orderByType(failedResponse.MessageQuantityDetailList);
          } else {
            return common.ShowAPIError('Query failed message data error.', failedResponse);
          }
        }, function(error) {
          return common.ShowAPIError('Query failed message data error.', error.data);
        });
        $scope.totalQuery.action = 'avgresponsetime';
        return avgResponse = monitorAPI.search($scope.totalQuery, function() {
          if (avgResponse && avgResponse.Succeeded) {
            $scope.tempData_avg_1 = $scope.orderByType(avgResponse.AvgResponseTimeList);
            $scope.tempData_avg_2 = $scope.orderByType(avgResponse.AvgResponseTimeDetailList);
          } else {
            common.ShowAPIError('Query avg response time data failed.', avgResponse);
          }
          return $scope.loadingDic = false;
        }, function(error) {
          common.ShowAPIError('Query avg response time data failed.', error.data);
          return $scope.loadingDic = false;
        });
      }
    };
    $scope.search = function() {
      $scope.$on('$destroy', $interval.cancel($scope.statisticsTimer));
      if ($scope.searchForm.$valid && $scope.query.LocalStationID !== -1) {
        $scope.promise = $scope.getData();
        return monitor.query = angular.copy($scope.query);
      } else {
        return messager.error('Must select a local partner and local station.');
      }
    };
    $scope.GetDataRangeStr = function() {
      var endTime, startTime;
      startTime = $scope.query.dateRange.start.format('MM/DD');
      endTime = $scope.query.dateRange.end.format('MM/DD');
      return "" + startTime + " ~ " + endTime;
    };
    $scope.setPeriodType = function(type) {
      $scope.query.Period = type;
      return $scope.search();
    };
    $scope.chart_Total_count = 0;
    $scope.chart_Total_data = [];
    $scope.loadPieChart_TotalMessage = function(data) {
      var index, totalCount;
      $scope.chart_Total_count = 0;
      totalCount = 0;
      for (index in data) {
        totalCount += data[index].Count;
      }
      $scope.chart_Total_count = totalCount;
      for (index in data) {
        data[index].label = data[index].MessageTypeName;
        data[index].value = Math.round(data[index].Count / totalCount * 100);
      }
      if (!data || data.length === 0) {
        return $scope.chart_TotalMessage_1_Show = false;
      } else {
        $scope.chart_Total_data = data;
        $scope.chart_TotalMessage_1_Show = true;
        document.getElementById('chart_Total_1').innerHTML = '';
        return Morris.Donut({
          element: 'chart_Total_1',
          data: data,
          formatter: function(y, a) {
            return y + "%" + ', ' + a.Count;
          },
          colors: monitor.chartColors
        });
      }
    };
    $scope.loadLineChart_TotalMessage = function(data) {
      var index, labelList, tempData;
      $scope.data_Total = [];
      tempData = [];
      labelList = [];
      for (index in data) {
        if (labelList.indexOf(data[index].MessageTypeName) < 0) {
          labelList.push(data[index].MessageTypeName);
        }
        if (tempData[data[index].TimeDesc] === void 0) {
          tempData[data[index].TimeDesc] = {
            y: data[index].TimeDesc
          };
          tempData[data[index].TimeDesc][data[index].MessageTypeName] = data[index].Count;
        } else {
          tempData[data[index].TimeDesc][data[index].MessageTypeName] = data[index].Count;
        }
      }
      for (index in tempData) {
        $scope.data_Total.push(tempData[index]);
      }
      if (!data || data.length === 0) {
        return $scope.chart_TotalMessage_2_Show = false;
      } else {
        $scope.data_Total = $filter('orderBy')($scope.data_Total, 'y');
        $scope.chart_TotalMessage_2_Show = true;
        document.getElementById('chart_Total_2').innerHTML = '';
        return Morris.Line({
          element: 'chart_Total_2',
          data: $scope.data_Total,
          hideHover: 'auto',
          xkey: 'y',
          ykeys: labelList,
          labels: labelList,
          lineColors: monitor.chartColors,
          parseTime: false,
          lineWidth: 2,
          pointSize: 4
        });
      }
    };
    $scope.chart_Failed_TotalCount = 0;
    $scope.loadBarChart_FailedMessage = function(data) {
      var MessageTypeKeys, MessageTypeLabels, index, lastData;
      lastData = [
        {
          y: $scope.GetDataRangeStr()
        }
      ];
      MessageTypeKeys = [];
      MessageTypeLabels = [];
      $scope.chart_Failed_TotalCount = 0;
      for (index in data) {
        $scope.chart_Failed_TotalCount += data[index].Count;
        lastData[0][data[index].MessageType] = data[index].Count;
        MessageTypeKeys.push(data[index].MessageType);
        MessageTypeLabels.push(data[index].MessageTypeName);
      }
      if (!data || data.length === 0) {
        return $scope.chart_FailedMessage_1_Show = false;
      } else {
        $scope.chart_FailedMessage_1_Show = true;
        document.getElementById('chart_Failed_1').innerHTML = '';
        return Morris.Bar({
          element: 'chart_Failed_1',
          data: lastData,
          hideHover: 'auto',
          xkey: 'y',
          ykeys: MessageTypeKeys,
          labels: MessageTypeLabels,
          barColors: monitor.chartColors,
          parseTime: false
        });
      }
    };
    $scope.loadLineChart_FailedMessage = function(data) {
      var index, labelList_Failed, tempData_Failed;
      $scope.data_Failed = [];
      tempData_Failed = [];
      labelList_Failed = [];
      for (index in data) {
        if (labelList_Failed.indexOf(data[index].MessageTypeName) < 0) {
          labelList_Failed.push(data[index].MessageTypeName);
        }
        if (tempData_Failed[data[index].TimeDesc] === void 0) {
          tempData_Failed[data[index].TimeDesc] = {
            y: data[index].TimeDesc
          };
          tempData_Failed[data[index].TimeDesc][data[index].MessageTypeName] = data[index].Count;
        } else {
          tempData_Failed[data[index].TimeDesc][data[index].MessageTypeName] = data[index].Count;
        }
      }
      for (index in tempData_Failed) {
        $scope.data_Failed.push(tempData_Failed[index]);
      }
      if (!data || data.length === 0) {
        return $scope.chart_FailedMessage_2_Show = false;
      } else {
        $scope.data_Failed = $filter('orderBy')($scope.data_Failed, 'y');
        $scope.chart_FailedMessage_2_Show = true;
        document.getElementById('chart_Failed_2').innerHTML = '';
        return Morris.Line({
          element: 'chart_Failed_2',
          data: $scope.data_Failed,
          hideHover: 'auto',
          xkey: 'y',
          ykeys: labelList_Failed,
          labels: labelList_Failed,
          lineColors: monitor.chartColors,
          parseTime: false,
          lineWidth: 2,
          pointSize: 4
        });
      }
    };
    $scope.chart_Avg_value = 0;
    $scope.loadBarChart_AvgMessage = function(data) {
      var MessageTypeKeys, MessageTypeLabels, index, lastData, totalValue;
      lastData = [
        {
          y: $scope.GetDataRangeStr()
        }
      ];
      MessageTypeKeys = [];
      MessageTypeLabels = [];
      $scope.chart_Avg_value = 0;
      if (!data || data.length === 0) {
        return $scope.chart_AvgMessage_1_Show = false;
      } else {
        totalValue = 0;
        for (index in data) {
          totalValue += data[index].AvgResponseTime;
          lastData[0][data[index].MessageType] = data[index].AvgResponseTime;
          MessageTypeKeys.push(data[index].MessageType);
          MessageTypeLabels.push(data[index].MessageTypeName);
        }
        $scope.chart_Avg_value = Math.round(totalValue / data.length);
        $scope.chart_AvgMessage_1_Show = true;
        document.getElementById('chart_Avg_1').innerHTML = '';
        return Morris.Bar({
          element: 'chart_Avg_1',
          data: lastData,
          hideHover: 'auto',
          xkey: 'y',
          ykeys: MessageTypeKeys,
          labels: MessageTypeLabels,
          barColors: monitor.chartColors,
          parseTime: false
        });
      }
    };
    $scope.loadLineChart_AvgMessage = function(data) {
      var index, labelList_Avg, tempData_Avg;
      $scope.data_Avg = [];
      tempData_Avg = [];
      labelList_Avg = [];
      for (index in data) {
        if (labelList_Avg.indexOf(data[index].MessageTypeName) < 0) {
          labelList_Avg.push(data[index].MessageTypeName);
        }
        if (tempData_Avg[data[index].TimeDesc] === void 0) {
          tempData_Avg[data[index].TimeDesc] = {
            y: data[index].TimeDesc
          };
          tempData_Avg[data[index].TimeDesc][data[index].MessageTypeName] = data[index].AvgResponseTime;
        } else {
          tempData_Avg[data[index].TimeDesc][data[index].MessageTypeName] = data[index].AvgResponseTime;
        }
      }
      for (index in tempData_Avg) {
        $scope.data_Avg.push(tempData_Avg[index]);
      }
      if (!data || data.length === 0) {
        return $scope.chart_AvgMessage_2_Show = false;
      } else {
        $scope.data_Avg = $filter('orderBy')($scope.data_Avg, 'y');
        $scope.chart_AvgMessage_2_Show = true;
        document.getElementById('chart_Avg_2').innerHTML = '';
        return Morris.Area({
          element: 'chart_Avg_2',
          data: $scope.data_Avg,
          hideHover: 'auto',
          xkey: 'y',
          ykeys: labelList_Avg,
          labels: labelList_Avg,
          lineColors: monitor.chartColors,
          parseTime: false,
          lineWidth: 2,
          pointSize: 4
        });
      }
    };
    $scope.chooseOrgan = true;
    $scope.choosePartner = true;
    $scope.chooseStation = true;
    $scope.getOrganData = function() {
      var response;
      return response = organizationAPI.search({}, function() {
        if (response && response.Succeeded) {
          return $scope.organList = response.OrganizationList;
        } else {
          return common.ShowAPIError('Get organization data failed.', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get organization data failed.', error.data);
      });
    };
    $scope.getPartnerData = function() {
      return partnerAPI.search({
        contact: false,
        certificate: false,
        station: false,
        type: 'Local'
      }, function(result) {
        if (result && result.Succeeded) {
          $scope.partnerList = result.PartnerList;
          $scope.orignalPartnerList = result.PartnerList;
          $scope.partnerList.splice($scope.partnerList.length, 0, {
            Id: 0,
            Name: 'Unknown'
          });
          return $scope.getStationData();
        } else {
          return common.ShowAPIError('Get partner data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get partner data failed.', error.data);
      });
    };
    $scope.getStationData = function() {
      return stationAPI.search({
        contact: false,
        schema: false,
        customsettingvalue: false
      }, function(result) {
        if (result && result.Succeeded) {
          $scope.orignalStationList = result.StationList;
          if (common.currentUser.OrganizationID) {
            $scope.query.OrganizationID = common.currentUser.OrganizationID;
            $scope.ownerOrganChanged();
            $scope.chooseOrgan = false;
            if ($scope.cacheLocalPartnerId || $scope.cacheLocalPartnerId === 0) {
              $scope.query.LocalPartnerID = $scope.cacheLocalPartnerId;
              $scope.ownerPartnerChanged();
            } else {
              $scope.query.LocalPartnerID = $scope.partnerList[0].Id;
              $scope.ownerPartnerChanged();
            }
            if ($scope.cacheLocalStationId || $scope.cacheLocalStationId === 0) {
              $scope.query.LocalStationID = $scope.cacheLocalStationId;
            }
          }
          if (common.currentUser.PartnerID) {
            $scope.ownerOrganChanged();
            $scope.query.LocalPartnerID = common.currentUser.PartnerID;
            $scope.ownerPartnerChanged();
            $scope.choosePartner = false;
          }
          if (common.currentUser.StationID) {
            $scope.query.LocalStationID = common.currentUser.StationID;
            $scope.chooseStation = false;
          }
          $scope.loadingDic = false;
          return $scope.statisticsTimer = $interval($scope.search, 500);
        } else {
          return common.ShowAPIError('Get station data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get partner data failed.', error.data);
      });
    };
    $scope.initOwnerComboBox = function() {
      if (common.currentUser.OrganizationID) {
        $scope.chooseOrgan = false;
        $scope.query.OrganizationID = common.currentUser.OrganizationID;
      }
      if (common.currentUser.PartnerID) {
        $scope.choosePartner = false;
        $scope.query.LocalPartnerID = common.currentUser.PartnerID;
      }
      if (common.currentUser.StationID) {
        $scope.chooseStation = false;
        return $scope.query.LocalStationID = common.currentUser.StationID;
      }
    };
    $scope.ownerOrganChanged = function() {
      var index;
      $scope.partnerList = [];
      for (index in $scope.orignalPartnerList) {
        if ($scope.orignalPartnerList[index].OrganizationID === $scope.query.OrganizationID) {
          $scope.partnerList.push($scope.orignalPartnerList[index]);
        }
      }
      $scope.partnerList.splice($scope.partnerList.length, 0, {
        Id: 0,
        Name: 'Unknown'
      });
      return $scope.query.LocalPartnerID = $scope.partnerList[0].Id;
    };
    $scope.ownerPartnerChanged = function() {
      var index;
      $scope.stationList = [];
      for (index in $scope.orignalStationList) {
        if ($scope.orignalStationList[index].PartnerID === $scope.query.LocalPartnerID) {
          $scope.stationList.push($scope.orignalStationList[index]);
        }
      }
      $scope.stationList.splice($scope.stationList.length, 0, {
        Id: 0,
        Name: 'Unknown'
      });
      return $scope.query.LocalStationID = $scope.stationList[0].Id;
    };
    $scope.initOwnerComboBox();
    $scope.loadingDic = true;
    $scope.getOrganData();
    $scope.getPartnerData();
    $scope.chart_total_hideLeft = false;
    $scope.chart_failed_hideLeft = false;
    $scope.chart_avg_hideLeft = false;
    $scope.isRefresh = false;
    return $scope.foldChart = function(type) {
      var foldElement, foldName, hideLeft, leftElement, leftName, rightElement, rightName;
      $scope.isRefresh = true;
      leftName = "chart_" + type + "_1_parent";
      rightName = "chart_" + type + "_2_parent";
      foldName = "chart_" + type + "_fold";
      foldElement = $('#' + foldName);
      leftElement = $('#' + leftName);
      rightElement = $('#' + rightName);
      leftElement.removeClass("ng-hide");
      rightElement.removeClass("ng-hide");
      leftElement.removeClass("col-lg-4");
      rightElement.removeClass("col-lg-7");
      leftElement.removeClass("col-lg-11");
      rightElement.removeClass("col-lg-11");
      foldElement.removeClass("eaas-fold-left");
      foldElement.removeClass("eaas-fold-right");
      hideLeft = false;
      if (type === 'Total') {
        $scope.chart_total_hideLeft = !$scope.chart_total_hideLeft;
        hideLeft = $scope.chart_total_hideLeft;
      } else if (type === 'Failed') {
        $scope.chart_failed_hideLeft = !$scope.chart_failed_hideLeft;
        hideLeft = $scope.chart_failed_hideLeft;
      } else if (type === 'Avg') {
        $scope.chart_avg_hideLeft = !$scope.chart_avg_hideLeft;
        hideLeft = $scope.chart_avg_hideLeft;
      }
      if (hideLeft === true) {
        leftElement.addClass("ng-hide");
        foldElement.addClass("eaas-fold-right");
        rightElement.addClass("col-lg-11");
      } else {
        leftElement.addClass("col-lg-4");
        foldElement.addClass("eaas-fold-left");
        rightElement.addClass("col-lg-7");
      }
      if (type === 'Total') {
        return $scope.tempData_total_1 = angular.copy($scope.tempData_total_1);
      } else if (type === 'Failed') {
        return $scope.tempData_failed_1 = angular.copy($scope.tempData_failed_1);
      } else if (type === 'Avg') {
        return $scope.tempData_avg_1 = angular.copy($scope.tempData_avg_1);
      }
    };
  }
]);
