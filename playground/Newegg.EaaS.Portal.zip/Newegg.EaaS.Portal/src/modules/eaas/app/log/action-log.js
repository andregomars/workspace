﻿
angular.module('edi-eaas-actionLog', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/action-log", {
      templateUrl: "/modules/eaas/app/log/action-log.tpl.html",
      controller: 'eaasActionLogCtrl'
    });
  }
]).controller('eaasActionLogCtrl', [
  "$scope", "$location", "actionLog", "progress", "messager", 'common', 'actionLogAPI', 'accountAPI', 'partnerAPI', 'stationAPI', 'agreementAPI', 'schemaAPI', 'mapperAPI', 'transmissionAPI', 'certificateAPI', '$filter', 'fileAPI', 'contactAPI', function($scope, $location, actionLog, progress, messager, common, actionLogAPI, accountAPI, partnerAPI, stationAPI, agreementAPI, schemaAPI, mapperAPI, transmissionAPI, certificateAPI, $filter, fileAPI, contactAPI) {
    var pageName;
    $scope.objectTypeList = [
      {
        id: 'All',
        name: 'All'
      }, {
        id: 'Organization',
        name: 'Organization'
      }, {
        id: 'Partner',
        name: 'Partner'
      }, {
        id: 'Station',
        name: 'Station'
      }, {
        id: 'Agreement',
        name: 'Agreement'
      }, {
        id: 'Account',
        name: 'Account'
      }, {
        id: 'Schema',
        name: 'Schema'
      }, {
        id: 'Mapper',
        name: 'Mapper'
      }, {
        id: 'Transmission',
        name: 'Protocol'
      }, {
        id: 'Certificate',
        name: 'Certificate'
      }
    ];
    $scope.objectTypeChanged = function() {
      var i;
      $scope.actionList = [];
      if ($scope.query.ObjectType === 'All') {
        $scope.actionList.push($scope.actionDic[99]);
        i = 0;
        while (i < 12) {
          if ($scope.actionDic[i]) {
            $scope.actionList.push($scope.actionDic[i]);
          }
          i++;
        }
      }
      if ($scope.query.ObjectType === 'Organization') {
        $scope.actionList.push($scope.actionDic[99]);
        $scope.actionList.push($scope.actionDic[0]);
        $scope.actionList.push($scope.actionDic[1]);
        $scope.actionList.push($scope.actionDic[2]);
      }
      if ($scope.query.ObjectType === 'Partner') {
        $scope.setBusinessObjectActionDic();
      }
      if ($scope.query.ObjectType === 'Station') {
        $scope.setBusinessObjectActionDic();
      }
      if ($scope.query.ObjectType === 'Agreement') {
        $scope.setBusinessObjectActionDic();
      }
      if ($scope.query.ObjectType === 'Schema') {
        $scope.setResourceActionDic();
      }
      if ($scope.query.ObjectType === 'Mapper') {
        $scope.setResourceActionDic();
      }
      if ($scope.query.ObjectType === 'Protocol') {
        $scope.setResourceActionDic();
      }
      if ($scope.query.ObjectType === 'Certificate') {
        $scope.actionList.push($scope.actionDic[99]);
        $scope.actionList.push($scope.actionDic[0]);
        $scope.actionList.push($scope.actionDic[2]);
        $scope.actionList.push($scope.actionDic[8]);
        $scope.actionList.push($scope.actionDic[9]);
      }
      if ($scope.query.ObjectType === 'Account') {
        $scope.actionList.push($scope.actionDic[99]);
        $scope.actionList.push($scope.actionDic[0]);
        $scope.actionList.push($scope.actionDic[1]);
        $scope.actionList.push($scope.actionDic[2]);
        $scope.actionList.push($scope.actionDic[4]);
        $scope.actionList.push($scope.actionDic[5]);
        $scope.actionList.push($scope.actionDic[6]);
        $scope.actionList.push($scope.actionDic[7]);
      }
      return $scope.query.Action = $scope.actionList[0].name;
    };
    $scope.setResourceActionDic = function() {
      $scope.actionList.push($scope.actionDic[99]);
      $scope.actionList.push($scope.actionDic[0]);
      $scope.actionList.push($scope.actionDic[1]);
      return $scope.actionList.push($scope.actionDic[2]);
    };
    $scope.setBusinessObjectActionDic = function() {
      $scope.actionList.push($scope.actionDic[99]);
      $scope.actionList.push($scope.actionDic[0]);
      $scope.actionList.push($scope.actionDic[1]);
      $scope.actionList.push($scope.actionDic[2]);
      $scope.actionList.push($scope.actionDic[9]);
      $scope.actionList.push($scope.actionDic[10]);
      return $scope.actionList.push($scope.actionDic[11]);
    };
    $scope.actionDic = {
      99: {
        id: 99,
        name: 'All'
      },
      0: {
        id: 0,
        name: 'Create'
      },
      1: {
        id: 1,
        name: 'Update'
      },
      2: {
        id: 2,
        name: 'Delete'
      },
      4: {
        id: 4,
        name: 'Login'
      },
      5: {
        id: 5,
        name: 'Logout'
      },
      6: {
        id: 6,
        name: 'Agent'
      },
      7: {
        id: 7,
        name: 'ChangePassword'
      },
      8: {
        id: 8,
        name: 'Upload'
      },
      9: {
        id: 9,
        name: 'Deploy'
      },
      10: {
        id: 10,
        name: 'Disable'
      },
      11: {
        id: 11,
        name: 'Enable'
      }
    };
    $scope.actionDicName = {
      All: 'All',
      Create: 'Create',
      Update: 'Update',
      Delete: 'Delete',
      Retrieve: 'Retrieve',
      Login: 'Login',
      Logout: 'Logout',
      Agent: 'Agent',
      ChangePassword: 'ChangePassword',
      Upload: 'Upload',
      Deploy: 'Deploy',
      Disable: 'Disable',
      Enable: 'Enable'
    };
    $scope.actionList = [
      {
        id: 99,
        name: 'All'
      }, {
        id: 0,
        name: 'Create'
      }, {
        id: 1,
        name: 'Update'
      }, {
        id: 2,
        name: 'Delete'
      }, {
        id: 4,
        name: 'Login'
      }, {
        id: 5,
        name: 'Logout'
      }, {
        id: 6,
        name: 'Agent'
      }, {
        id: 7,
        name: 'ChangePassword'
      }, {
        id: 8,
        name: 'Upload'
      }, {
        id: 9,
        name: 'Deploy'
      }, {
        id: 10,
        name: 'Disable'
      }, {
        id: 11,
        name: 'Enable'
      }
    ];
    $scope.statusList = [
      {
        id: 99,
        name: 'All'
      }, {
        id: 0,
        name: 'Successful'
      }, {
        id: 1,
        name: 'Failed'
      }
    ];
    $scope.initCondition = function() {
      $scope.query.ObjectType = 'All';
      $scope.query.Action = 'All';
      $scope.query.Status = 'All';
      $scope.query.ActionUser = null;
      $scope.query.ObjectReference = null;
      if (common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.ObjectType) {
          $scope.query.ObjectType = common.current.link[pageName].pageParameter.ObjectType;
          $scope.objectTypeChanged();
        }
        if (common.current.link[pageName].pageParameter.Action) {
          $scope.query.Action = common.current.link[pageName].pageParameter.Action;
        }
        if (common.current.link[pageName].pageParameter.Status) {
          $scope.query.Status = common.current.link[pageName].pageParameter.Status;
        }
        if (common.current.link[pageName].pageParameter.ObjectReference) {
          $scope.query.ObjectReference = common.current.link[pageName].pageParameter.ObjectReference;
        }
        if (common.current.link[pageName].pageParameter.ObjectID) {
          $scope.query.ObjectID = common.current.link[pageName].pageParameter.ObjectID;
        }
        if (common.current.link[pageName].pageParameter.ActionUser) {
          $scope.query.ActionUser = common.current.link[pageName].pageParameter.ActionUser;
        }
        if (common.current.link[pageName].pageParameter.ActionDateFrom && common.current.link[pageName].pageParameter.ActionDateTo) {
          $scope.query.actionDateRange = {};
          $scope.query.actionDateRange.start = moment(common.current.link[pageName].pageParameter.ActionDateFrom);
          $scope.query.actionDateRange.end = moment(common.current.link[pageName].pageParameter.ActionDateTo);
          $scope.query.ActionDateFrom = $scope.query.actionDateRange.start.format('MM/DD/YYYY HH:mm:ss');
          $scope.query.ActionDateTo = $scope.query.actionDateRange.end.format('MM/DD/YYYY 23:59:59');
          return $scope.query.actionDateRange = moment().range($scope.query.ActionDateFrom, $scope.query.ActionDateTo);
        } else {
          if (common.current.link[pageName].prePageName && common.current.link[pageName].prePageName === '/') {
            return $scope.query.actionDateRange = null;
          } else {
            $scope.currentStartDate = moment(new Date() - (6 * 1000 * 60 * 60 * 24));
            $scope.currentEndDate = moment(new Date());
            return $scope.query.actionDateRange = moment().range($scope.currentStartDate, $scope.currentEndDate);
          }
        }
      } else {
        $scope.currentStartDate = moment(new Date() - (6 * 1000 * 60 * 60 * 24));
        $scope.currentEndDate = moment(new Date());
        return $scope.query.actionDateRange = moment().range($scope.currentStartDate, $scope.currentEndDate);
      }
    };
    $scope.common = common;
    pageName = $location.$$path;
    $scope.query = angular.copy(actionLog.query);
    if (common.current.isBackPage === false) {
      common.InitQueryFields($scope.query);
      $scope.initCondition();
    } else {
      if ($scope.query.ActionDateFrom && $scope.query.ActionDateTo) {
        $scope.query.actionDateRange = moment().range($scope.query.ActionDateFrom, $scope.query.ActionDateTo);
      } else {
        $scope.query.actionDateRange = null;
      }
      common.current.isBackPage = false;
    }
    $scope.query.pageSize = common.getTablePageSize(60, 230);
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.pageChanged = function(page) {
      $scope.query.currentPage = page;
      $scope.query.startpageindex = page - 1;
      $scope.query.endpageindex = page - 1;
      return $scope.promise = $scope.search();
    };
    $scope.showPagination = function() {
      return $scope.query.totalItems > $scope.query.pageSize;
    };
    $scope.prepareCondition = function(requestItem) {
      if (requestItem.ObjectType === 'All') {
        requestItem.ObjectType = null;
      }
      if (requestItem.Action === 'All') {
        requestItem.Action = null;
      }
      if (requestItem.Status === 'All') {
        return requestItem.Status = null;
      }
    };
    $scope.getObjectAttr = function(log) {
      var requestCondition, response;
      log.loadAttr = true;
      requestCondition = {
        id: log.ObjectID
      };
      if (log.ObjectType === 'Account') {
        return response = accountAPI.search({
          id: log.ObjectID,
          contact: true
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.AccountList && response.AccountList.length > 0) {
            log.objectAttr = response.AccountList[0];
            return log.objectAttr.Name = log.objectAttr.LoginName;
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Partner') {
        return response = partnerAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.PartnerList && response.PartnerList.length > 0) {
            return log.objectAttr = response.PartnerList[0];
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Station') {
        return response = stationAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.StationList && response.StationList.length > 0) {
            return log.objectAttr = response.StationList[0];
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Agreement') {
        return response = agreementAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.AgreementList && response.AgreementList.length > 0) {
            return log.objectAttr = response.AgreementList[0];
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Schema') {
        return response = schemaAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.SchemaList && response.SchemaList.length > 0) {
            return log.objectAttr = response.SchemaList[0];
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Mapper') {
        return response = mapperAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.MapperList && response.MapperList.length > 0) {
            return log.objectAttr = response.MapperList[0];
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Protocol') {
        return response = transmissionAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.ProtocolList && response.ProtocolList.length > 0) {
            return log.objectAttr = response.ProtocolList[0];
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else if (log.ObjectType === 'Certificate') {
        return response = certificateAPI.search({
          id: log.ObjectID
        }, function() {
          log.loadAttr = false;
          if (response && response.Succeeded && response.CertificateList && response.CertificateList.length > 0) {
            log.objectAttr = response.CertificateList[0];
            return log.objectAttr.Name = log.objectAttr.Subject;
          } else {
            log.objectAttr = {};
            return log.objectAttr.Name = log.ObjectID;
          }
        });
      } else {
        log.objectAttr = {};
        log.objectAttr.Name = log.ObjectID;
        return log.loadAttr = false;
      }
    };
    $scope.initDataRender = function() {
      var index, _results;
      _results = [];
      for (index in $scope.logList) {
        _results.push($scope.getObjectAttr($scope.logList[index]));
      }
      return _results;
    };
    $scope.search = function() {
      var requestItem;
      if ($scope.query.actionDateRange && $scope.query.actionDateRange.start && $scope.query.actionDateRange.end) {
        $scope.query.ActionDateFrom = $scope.query.actionDateRange.start.format('MM/DD/YYYY HH:mm:ss');
        $scope.query.ActionDateTo = $scope.query.actionDateRange.end.format('MM/DD/YYYY 23:59:59');
      } else {
        $scope.query.ActionDateFrom = null;
        $scope.query.ActionDateTo = null;
      }
      requestItem = angular.copy($scope.query);
      actionLog.query = angular.copy($scope.query);
      $scope.prepareCondition(requestItem);
      common.clearQueryParameter(requestItem);
      return actionLogAPI.search(requestItem, function(result) {
        if ($scope.query.ObjectID) {
          delete $scope.query.ObjectID;
        }
        if (result && result.Succeeded) {
          $scope.query.totalItems = result.TotalRecordCount;
          return $scope.logList = result.ActionLogList;
        } else {
          return common.ShowAPIError('Get action log data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get action log data failed.', error.data);
      });
    };
    $scope.advancedSearch = function() {
      $scope.query.currentPage = 1;
      return $scope.pageChanged(1);
    };
    $scope.promise = $scope.search();
    $scope.navigate = false;
    $scope.showRowDetail = function(log) {
      if ($scope.navigate === false) {
        return log.showDetail = !log.showDetail;
      }
    };
    $scope.showAdvancedSearch = false;
    $scope.showAdvanced = function() {
      return $scope.showAdvancedSearch = !$scope.showAdvancedSearch;
    };
    $scope.showRowBackGround = function(index) {
      if ((index + 1) % 2 === 0) {
        return true;
      }
      return false;
    };
    $scope.navigateFileView = function(log) {
      return fileAPI.search({
        Id: log.ObjectID
      }, function(result) {
        var objectModel;
        if (result && result.Succeeded) {
          if (result.FileList && result.FileList.length > 0) {
            objectModel = {
              ObjectType: result.FileList[0].OwnerType,
              ObjectID: result.FileList[0].OwnerID
            };
            return $scope.navigateObjectView(objectModel);
          }
        } else {
          return common.ShowAPIError('Get file data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get file data failed.', error.data);
      });
    };
    $scope.navigateContactView = function(log) {
      return contactAPI.search({
        Id: log.ObjectID
      }, function(result) {
        var objectModel;
        if (result && result.Succeeded) {
          if (result.ContactList && result.ContactList.length > 0) {
            objectModel = {
              ObjectType: result.ContactList[0].OwnerType,
              ObjectID: result.ContactList[0].OwnerID
            };
            return $scope.navigateObjectView(objectModel);
          }
        } else {
          return common.ShowAPIError('Get contact data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get contact data failed.', error.data);
      });
    };
    $scope.navigateObjectView = function(object) {
      if (object.ObjectType === 'Account') {
        return common.navigate('account/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Partner') {
        return common.navigate('partner/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Station') {
        return common.navigate('station/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Agreement') {
        return common.navigate('agreement/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Schema') {
        return common.navigate('schema/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Mapper') {
        return common.navigate('mapper/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Protocol') {
        return common.navigate('transmission/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Certificate') {
        return common.navigate('certificate/view', {
          Id: object.ObjectID
        });
      } else if (object.ObjectType === 'Organization') {
        return common.navigate('organization/detail', {
          Id: object.ObjectID
        });
      }
    };
    return $scope.viewObject = function(log) {
      $scope.navigate = true;
      if (log.ObjectType === 'File') {
        return $scope.promise = $scope.navigateFileView(log);
      } else if (log.ObjectType === 'Contact') {
        return $scope.promise = $scope.navigateContactView(log);
      } else {
        $scope.navigateObjectView(log);
        return $scope.navigate = false;
      }
    };
  }
]);
