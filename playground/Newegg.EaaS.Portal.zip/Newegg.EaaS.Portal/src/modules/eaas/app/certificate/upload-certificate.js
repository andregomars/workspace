﻿
angular.module('eaas-upload-certificate', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/certificate/upload", {
      templateUrl: "/modules/eaas/app/certificate/upload-certificate.tpl.html",
      controller: 'EaaSUploadCertificateCtrl'
    });
  }
]).controller('EaaSUploadCertificateCtrl', [
  "$scope", "$http", "$window", "progress", 'common', '$fileUploader', 'messager', 'certificateAPI', 'partnerAPI', 'stationAPI', function($scope, $http, $window, progress, common, $fileUploader, messager, certificateAPI, partnerAPI, stationAPI) {
    var uploader;
    $scope.transferObj = {
      isSucceed: true,
      action: 'upload',
      objName: 'certificate',
      title: 'Certificate has been created successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.showFileInfo = false;
    $scope.common = common;
    $scope.purposeType = 'Encryption';
    $scope.certificate = {};
    $scope.mapperFile = {};
    $scope.uploadValid = false;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.belongId = null;
    $scope.belongType = null;
    $scope.loadBelongTo = true;
    $scope.isCheckPassword = false;
    $scope.uploadurl = common.apiURL.upload + "?fullname=certificate.cer&filetype=certificate&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = true;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) !== 'cer' && item.name.slice(item.name.lastIndexOf('.') + 1) !== 'pfx' && item.name.slice(item.name.lastIndexOf('.') + 1) !== 'p12') {
            valid = false;
            messager.error("File extension name must be cer or pfx or p12.");
          }
          if (valid === true && (item.name.slice(item.name.lastIndexOf('.') + 1) === 'pfx' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'p12')) {
            $scope.isCheckPassword = true;
          }
          if (valid === true && (item.name.slice(item.name.lastIndexOf('.') + 1) === 'pfx' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'p12')) {
            messager.info("For PFX or P12 certificate, usually this kind of certificate is containning private key which is protected by a password, to create a certificate based on these files, the password must be provided.");
          }
          $scope.mapperFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        if (common.validateCertificate(msg.Certificate) === false) {
          uploader.queue[0].isUploaded = false;
          $scope.promise = null;
          messager.error("The certificate file is expired.");
          $scope.isSubmit = false;
          return;
        }
        if (msg.Certificate.Status !== 'Valid') {
          messager.info("The certificate file will be expired in 30 days.");
        }
        $scope.mapperFile.Url = msg.File.Url;
        $scope.mapperFile.OriginalName = msg.File.OriginalName;
        $scope.mapperFile.Size = msg.File.Size;
        $scope.mapperFile.SubType = 'Main';
        $scope.mapperFile.Hash = msg.File.Hash;
        $scope.certificate.Subject = msg.Certificate.Subject;
        $scope.certificate.ThumbPrint = msg.Certificate.ThumbPrint;
        $scope.certificate.ValidFrom = msg.Certificate.ValidFrom;
        $scope.certificate.ValidTo = msg.Certificate.ValidTo;
        $scope.certificate.IssueBy = msg.Certificate.IssueBy;
        $scope.certificate.IssueTo = msg.Certificate.IssueTo;
        $scope.certificate.Password = $scope.password;
        $scope.showFileInfo = true;
        $scope.message = 'Processing...';
        $scope.minDuration = 0;
        return $scope.promise = $scope.save();
      } else {
        $scope.isSubmit = false;
        uploader.queue[0].isUploaded = false;
        $scope.promise = null;
        if (msg.Errors && msg.Errors.length > 0 && msg.Certificate) {
          return messager.error(msg.Errors[0].Message + '<br/>ThumbPrint:' + msg.Certificate.ThumbPrint);
        } else {
          return messager.error("The certificate file is not correct.");
        }
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.mapperFile = {};
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      return common.ShowAPIError('Upload file Failed', msg);
    });
    $scope.submit = function() {
      if ($scope.uploadValid === false) {
        messager.error("Please choose correct file to upload.");
        return;
      }
      if (!uploader.queue || uploader.queue.length < 1) {
        messager.error("Please choose certificate file to upload.");
        return;
      }
      if ($scope.certificateFileForm.$valid) {
        $scope.isSubmit = true;
        $scope.message = 'Uploading...';
        if ($scope.password) {
          uploader.queue[0].url = common.apiURL.upload + "?password=" + $scope.password + "&fullname=" + $scope.mapperFile.OriginalName + "&filetype=certificate&format=json";
        } else {
          uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.mapperFile.OriginalName + "&filetype=certificate&format=json";
        }
        return uploader.uploadAll();
      }
    };
    return $scope.save = function() {
      var requestDataModel;
      if ($scope.certificateFileForm.$valid) {
        $scope.certificate.OrganizationID = common.currentOrganization.Id;
        $scope.certificate.OwnerType = $scope.belongType;
        $scope.certificate.OwnerID = $scope.belongId;
        requestDataModel = {};
        requestDataModel.Certificate = $scope.certificate;
        requestDataModel.Certificate.FileList = [];
        requestDataModel.Certificate.FileList.push($scope.mapperFile);
        $scope.mapperFile.OwnerType = common.ownerType.certificate;
        $scope.mapperFile.OwnerID = 0;
        requestDataModel.Certificate.Purpose = $scope.purposeType;
        return certificateAPI.create(requestDataModel, function(result) {
          $scope.isSubmit = false;
          if (uploader.queue && uploader.queue.length > 0) {
            uploader.queue[0].isUploaded = false;
          }
          if (result.Succeeded) {
            $scope.transferObj.obj = result.CertificateList[0];
            return common.navigate('transfer', $scope.transferObj);
          } else {
            return common.ShowAPIError('Create Certificate Failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Create Certificate Failed', error.data);
        });
      } else {
        $scope.isSubmit = false;
        if (uploader.queue && uploader.queue.length > 0) {
          return uploader.queue[0].isUploaded = false;
        }
      }
    };
  }
]).controller('UploadCtrl', [
  "$scope", function($scope) {
    return $scope.url = "www.test.com";
  }
]);
