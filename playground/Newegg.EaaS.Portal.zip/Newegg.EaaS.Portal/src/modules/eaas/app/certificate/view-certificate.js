(function() {

  angular.module('eaas-view-certificate', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/certificate/view", {
        templateUrl: "/modules/eaas/app/certificate/view-certificate.tpl.html",
        controller: 'EaaSViewCertificateCtrl'
      });
    }
  ]).controller('EaaSViewCertificateCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "certificate", "mapperAPI", '$fileUploader', 'partnerAPI', 'stationAPI', 'certificateAPI', '$location', function($scope, $http, $window, $filter, messager, common, certificate, mapperAPI, $fileUploader, partnerAPI, stationAPI, certificateAPI, $location) {
      var pageName;
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'certificate';
      $scope.viewError = false;
      $scope.belongId = null;
      $scope.belongType = null;
      $scope.getCertificateInfo = function() {
        return certificateAPI.search({
          file: true,
          id: $scope.certificateId
        }, function(result) {
          if (result && result.Succeeded) {
            if (result.CertificateList && result.CertificateList.length > 0) {
              $scope.certificate = result.CertificateList[0];
              $scope.currentItem = result.CertificateList[0];
              certificate.viewItem = angular.copy(result.CertificateList[0]);
              $scope.belongId = $scope.currentItem.OwnerID;
              $scope.belongType = $scope.currentItem.OwnerType;
              $scope.loadBelongTo = true;
              return $scope.initViewObject();
            } else {
              certificate.viewItem = void 0;
              return $scope.viewError = true;
            }
          } else {
            return common.ShowAPIError('Get certificate data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get certificate data failed', error.data);
        });
      };
      $scope.initViewObject = function() {
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.certificate.InUser;
        $scope.generalView.InDate = $scope.certificate.InDate;
        $scope.generalView.EditUser = $scope.certificate.EditUser;
        $scope.generalView.EditDate = $scope.certificate.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Status', $scope.certificate.Status, true, ['statusCertificateView'], [true]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Certificate File', $scope.certificate.FileList[0].OriginalName, true, ['downloadView', 'url'], [true, $scope.certificate.FileList[0].Url]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Subject', $scope.certificate.Subject));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Thumbprint', $scope.certificate.ThumbPrint));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Issued to', $scope.certificate.IssueTo));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Issued by', $scope.certificate.IssueBy));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Valid from', $scope.certificate.ValidFrom, true, ['momentView'], [true]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Valid to', $scope.certificate.ValidTo, true, ['momentView'], [true]));
        return $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
      };
      pageName = $location.$$path;
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
        $scope.certificateId = common.current.link[pageName].pageParameter.Id;
        return $scope.promise = $scope.getCertificateInfo();
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        $scope.certificate = angular.copy(certificate.viewItem);
        if ($scope.certificate) {
          $scope.currentItem = angular.copy(certificate.viewItem);
          $scope.certificateId = $scope.currentItem.Id;
          return $scope.promise = $scope.getCertificateInfo();
        } else {
          return $scope.viewError = true;
        }
      } else {
        return common.navigate('certificate');
      }
    }
  ]);

}).call(this);
