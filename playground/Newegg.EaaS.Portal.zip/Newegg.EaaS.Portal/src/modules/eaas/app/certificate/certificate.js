﻿(function() {

  angular.module('eaas-certificate', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/certificate", {
        templateUrl: "/modules/eaas/app/certificate/certificate.tpl.html",
        controller: 'EaaSCertificateCtrl'
      });
    }
  ]).controller('EaaSCertificateCtrl', [
    "$scope", "$location", "$http", "$window", "$filter", "progress", "messager", "certificate", 'common', 'certificateAPI', 'fileAPI', function($scope, $location, $http, $window, $filter, progress, messager, certificate, common, certificateAPI, fileAPI) {
      $scope.common = common;
      $scope.query = angular.copy(certificate.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Subject',
            value: 'subject'
          }, {
            text: 'Thumbprint',
            value: 'thumbprint'
          }, {
            text: 'Issue To',
            value: 'issueTo'
          }, {
            text: 'Issue By',
            value: 'issueBy'
          }
        ];
        $scope.query.queryField = 'subject';
        $scope.query.status = null;
        common.InitQueryFields($scope.query);
      } else {
        common.current.isBackPage = false;
      }
      $scope.query.pageSize = common.getPageSize(590, 190);
      $scope.showLoading = true;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      $scope.initStatus = function() {
        var certificate_temp, index, now, validTime, _results;
        _results = [];
        for (index in $scope.certificateList) {
          certificate_temp = $scope.certificateList[index];
          validTime = Date.parse($filter('moment')(certificate_temp.ValidTo, 'M/D/YYYY'));
          now = new Date().getTime();
          if (validTime < now) {
            certificate_temp.CStatus = 'expired';
          } else {
            certificate_temp.CStatus = 'valid';
          }
          if (certificate_temp.Subject.length > 36) {
            certificate_temp.DisplaySubject = certificate_temp.Subject.substring(0, 33) + '...';
          } else {
            certificate_temp.DisplaySubject = certificate_temp.Subject;
          }
          if (certificate_temp.IssueBy && certificate_temp.IssueBy.length > 40) {
            _results.push(certificate_temp.DisplayIssueBy = certificate_temp.IssueBy.substring(0, 40) + '...');
          } else {
            _results.push(certificate_temp.DisplayIssueBy = certificate_temp.IssueBy);
          }
        }
        return _results;
      };
      $scope.search = function() {
        var requestItem;
        $scope.message = 'Loading...';
        requestItem = angular.copy($scope.query);
        certificate.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return certificateAPI.search(requestItem, function(result) {
          if (result && result.Succeeded) {
            $scope.certificateList = result.CertificateList;
            $scope.query.totalItems = result.TotalRecordCount;
            $scope.initStatus();
            common.loadOwnerInfo($scope.certificateList);
            return $scope.getAllFileInfo();
          } else {
            return common.ShowAPIError('Get certificate data failed.', result);
          }
        }, function(error) {
          $scope.showLoading = false;
          return common.ShowAPIError('Get certificate data failed.', error.data);
        });
      };
      $scope.getAllFileInfo = function() {
        var index, _results;
        _results = [];
        for (index in $scope.certificateList) {
          _results.push($scope.getFileInfo($scope.certificateList[index]));
        }
        return _results;
      };
      $scope.getFileInfo = function(certificate) {
        return common.fileResourceObtainer.getFileList('Certificate', certificate);
      };
      $scope.filterType = "all";
      $scope.query.file = false;
      if ($scope.query && $scope.query.status) {
        $scope.filterType = $scope.query.status;
      }
      $scope.promise = $scope.search();
      $scope.filter = function(type) {
        $scope.filterType = type;
        if (type === 'all') {
          $scope.query.status = null;
        } else {
          $scope.query.status = type;
        }
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.remove = function(entity) {
        return messager.confirm(function() {
          return messager.success("Remove certificate successfully.");
        });
      };
      $scope.location = function(url) {
        return $location.path("/" + url);
      };
      $scope.navigate = function(url, item) {
        return $location.path("/" + url + "/" + item.Name);
      };
      $scope.remove = function(entity) {
        var message, warnMsg;
        if (entity.IssueTo) {
          message = "Are you sure you want to remove the certificate \"" + entity.IssueTo + "\" ?";
          warnMsg = "If the certificate was referenced by any partners, it cannot be removed.";
        } else {
          message = "Are you sure you want to remove the certificate?";
          warnMsg = null;
        }
        return common.ConfirmBox(message, warnMsg, function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.removeCertificate(entity);
        });
      };
      return $scope.removeCertificate = function(entity) {
        var response;
        return response = certificateAPI.remove({
          id: entity.Id
        }, function() {
          if (response && response.Succeeded) {
            messager.success("Remove certificate successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError('Remove certificate  failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Remove certificate  failed.', error.data);
        });
      };
    }
  ]).controller('UploadCtrl', [
    "$scope", function($scope) {
      return $scope.url = "www.test.com";
    }
  ]);

}).call(this);
