﻿(function() {

  angular.module('eaas-feature', ['ngRoute', 'pascalprecht.translate', 'angular-follow']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/feature", {
        templateUrl: "/modules/eaas/app/feature/feature.tpl.html",
        controller: 'EaaSFeatureCtrl'
      }).when("/feature/partner", {
        templateUrl: "/modules/eaas/app/feature/feature.tpl.html",
        controller: 'EaaSFeatureCtrl'
      }).when("/feature/agreement", {
        templateUrl: "/modules/eaas/app/feature/feature.tpl.html",
        controller: 'EaaSFeatureCtrl'
      }).when("/feature/monitor", {
        templateUrl: "/modules/eaas/app/feature/feature.tpl.html",
        controller: 'EaaSFeatureCtrl'
      });
    }
  ]).controller('EaaSFeatureCtrl', [
    "$scope", "$location", "common", "$http", '$anchorScroll', "progress", "messager", "$rootScope", function($scope, $location, common, $http, $anchorScroll, progress, messager, $rootScope) {
      var i, _i;
      $scope.pageName = common.currentRoutePath();
      $scope.imagesHasLoaded = false;
      $scope.featureimages = [];
      if ($scope.pageName && $scope.pageName.indexOf("feature") > 0) {
        for (i = _i = 0; _i <= 25; i = ++_i) {
          $scope.featureimages.push("/modules/eaas/img/feature/feature_" + (i + 1) + ".png");
        }
        return $scope.imagesHasLoaded = true;
      } else {
        $scope.loadImages = function() {
          var _j;
          if ($scope.imagesHasLoaded === false && $rootScope.__featurePanel === true) {
            for (i = _j = 0; _j <= 25; i = ++_j) {
              $scope.featureimages.push("/modules/eaas/img/feature/feature_" + (i + 1) + ".png");
            }
            return $scope.imagesHasLoaded = true;
          }
        };
        return $scope.$watch("__featurePanel", (function() {
          return $scope.loadImages();
        }), true);
      }
    }
  ]).directive("scrollTo", [
    "$window", function($window) {
      return {
        restrict: "AC",
        compile: function() {
          var document, scrollInto;
          scrollInto = function(idOrName) {
            var el;
            if (!idOrName) {
              $window.scrollTo(0, 0);
            }
            el = document.getElementById(idOrName);
            if (!el) {
              el = document.getElementsByName(idOrName);
              if (el && el.length) {
                el = el[0];
              } else {
                el = null;
              }
            }
            if (el) {
              $window.scrollTo(0, el.offsetTop);
            }
          };
          document = $window.document;
          return function(scope, element, attr) {
            element.bind("click", function(event) {
              scrollInto(attr.scrollTo);
            });
          };
        }
      };
    }
  ]);

}).call(this);
