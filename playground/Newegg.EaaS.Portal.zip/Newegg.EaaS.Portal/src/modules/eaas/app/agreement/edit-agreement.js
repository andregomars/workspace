﻿
angular.module('eaas-edit-agreement', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/agreement/edit", {
      templateUrl: "/modules/eaas/app/agreement/edit-agreement.tpl.html",
      controller: 'EaaSEditAgreementCtrl'
    });
  }
]).controller('EaaSEditAgreementCtrl', [
  "$scope", "$location", "messager", "common", "partnerAPI", "agreement", "agreementAPI", "agreementOnewayAPI", '$filter', "transmissionAPI", "schemaAPI", "mapperAPI", 'customSettingCache', 'transmission', function($scope, $location, messager, common, partnerAPI, agreement, agreementAPI, agreementOnewayAPI, $filter, transmissionAPI, schemaAPI, mapperAPI, customSettingCache, transmission) {
    if (!agreement.editItem || !agreement.editItem.Id) {
      return $location.path('/agreement', {});
    } else {
      $scope.transferObj = {
        isSucceed: true,
        action: 'edit',
        objName: 'agreement',
        title: 'Agreement has been updated successfully! The configuration has been updated, it may need 15 minutes to take effect.'
      };
      $scope.isSubmit = false;
      common.initUnSavedConfirm($scope);
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.local_ISA6Value_Name = 'local_ISA6Value';
      $scope.local_ISA8Value_Name = 'local_ISA8Value';
      $scope.trading_ISA6Value_Name = 'trading_ISA6Value';
      $scope.trading_ISA8Value_Name = 'trading_ISA8Value';
      $scope.selectPartnerType = null;
      $scope.selectLocalPartner = null;
      $scope.selectLocalStation = null;
      $scope.selectTradingPartner = null;
      $scope.selectTradingStation = null;
      $scope.getSetting = function() {
        if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
          return customSettingCache.RefreshData($scope.bindingData, common.currentOrganization.Id);
        } else {
          return $scope.promise = $scope.getAgreemenGenrialInfo();
        }
      };
      $scope.getAgreemenGenrialInfo = function() {
        var response;
        return response = agreementAPI.search({
          id: $scope.editItem.Id
        }, function() {
          if (response && response.Succeeded) {
            if (response.AgreementList && response.AgreementList.length > 0) {
              $scope.viewAgreement = response.AgreementList[0];
              return $scope.promise = $scope.bindingData();
            }
          } else {
            return common.ShowAPIError('Get agreement data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get agreement data failed.', error.data);
        });
      };
      $scope.HandleCustomeSettingDisplay = function() {
        var index;
        $scope.ISA1List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.AuthorizationQualifier));
        customSettingCache.CollatorSettingDisplayName($scope.ISA1List);
        $scope.ISA3List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.SecurityQualifier));
        customSettingCache.CollatorSettingDisplayName($scope.ISA3List);
        $scope.ISA5List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.IdentityQualifier));
        customSettingCache.CollatorSettingDisplayName($scope.ISA5List);
        $scope.ISA7List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.IdentityQualifier));
        customSettingCache.CollatorSettingDisplayName($scope.ISA7List);
        $scope.ISA12List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.X12Standards));
        customSettingCache.CollatorSettingDisplayName($scope.ISA12List);
        $scope.ISA15List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.UsageIndicator));
        customSettingCache.CollatorSettingDisplayName($scope.ISA15List);
        $scope.dateFormatList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.GS4));
        $scope.timeFormatList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.GS5));
        $scope.protocolVersionList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.X12Standards));
        customSettingCache.CollatorSettingDisplayName($scope.protocolVersionList);
        $scope.responsibleAgencyCodeList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.GS7));
        customSettingCache.CollatorSettingDisplayName($scope.responsibleAgencyCodeList);
        $scope.functionalIdentifierCodeList = [];
        $scope.orignalFunctionalIdentifierCodeList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TransactionType));
        for (index in $scope.orignalFunctionalIdentifierCodeList) {
          if ($scope.orignalFunctionalIdentifierCodeList[index].Code === 'FA' || $scope.orignalFunctionalIdentifierCodeList[index].Code === 'UKN') {
            continue;
          } else {
            $scope.functionalIdentifierCodeList.push($scope.orignalFunctionalIdentifierCodeList[index]);
          }
        }
        customSettingCache.CollatorSettingDisplayName($scope.orignalFunctionalIdentifierCodeList);
        customSettingCache.CollatorSettingDisplayName($scope.functionalIdentifierCodeList);
        $scope.characterSetList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.X12CharacterSet));
        if ($scope.characterSetList) {
          $scope.local_selectedCharacterSet = $scope.characterSetList[0];
          $scope.trading_selectedCharacterSet = $scope.characterSetList[0];
        }
        $scope.trailingSeparatorPolicyList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TrailingSeparatorPolicy));
        if ($scope.trailingSeparatorPolicyList) {
          return $scope.trading_selectedTrailingSeparatorPolicy = $scope.trailingSeparatorPolicyList[0];
        }
      };
      $scope.charTypeList = agreement.charTypeList;
      $scope.local_dataElementSeparator_Type = $scope.charTypeList[0];
      $scope.local_componentElementSeparator_Type = $scope.charTypeList[0];
      $scope.local_segmentTerminator_Type = $scope.charTypeList[0];
      $scope.local_replaceChar_Type = $scope.charTypeList[0];
      $scope.local_controlStandardsID_Type = $scope.charTypeList[0];
      $scope.charTypeChanged2 = function(type) {
        if (type === 'dataElementSeparator') {
          return $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char);
        } else if (type === 'componentElementSeparator') {
          return $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char);
        } else if (type === 'segmentTerminator') {
          return $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char);
        } else if (type === 'replaceChar') {
          return $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char);
        } else if (type === 'controlStandardsID') {
          return $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char);
        }
      };
      $scope.charTypeChanged = function(type) {
        if (type === 'dataElementSeparator') {
          if ($scope.local_dataElementSeparator_Type.text === 'Hex') {
            return $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char);
          } else {
            return $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char = agreement.hexToString($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_hex);
          }
        } else if (type === 'componentElementSeparator') {
          if ($scope.local_componentElementSeparator_Type.text === 'Hex') {
            return $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char);
          } else {
            return $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char = agreement.hexToString($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_hex);
          }
        } else if (type === 'segmentTerminator') {
          if ($scope.local_segmentTerminator_Type.text === 'Hex') {
            return $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char);
          } else {
            return $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char = agreement.hexToString($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_hex);
          }
        } else if (type === 'replaceChar') {
          if ($scope.local_replaceChar_Type.text === 'Hex') {
            return $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char);
          } else {
            return $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char = agreement.hexToString($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_hex);
          }
        } else if (type === 'controlStandardsID') {
          if ($scope.local_controlStandardsID_Type.text === 'Hex') {
            return $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char);
          } else {
            return $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char = agreement.hexToString($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_hex);
          }
        }
      };
      $scope.localISA1Changed = function() {
        if ($scope.editItem.LocalToTrading.ProtocolX12.AuthorizationQualifier && $scope.editItem.LocalToTrading.ProtocolX12.AuthorizationQualifier === '00') {
          return $scope.editItem.LocalToTrading.ProtocolX12.AuthorizationValue = null;
        }
      };
      $scope.localISA3Changed = function() {
        if ($scope.editItem.LocalToTrading.ProtocolX12.SecurityQualifier && $scope.editItem.LocalToTrading.ProtocolX12.SecurityQualifier === '00') {
          return $scope.editItem.LocalToTrading.ProtocolX12.SecurityValue = null;
        }
      };
      $scope.tradingISA1Changed = function() {
        if ($scope.editItem.TradingToLocal.ProtocolX12.AuthorizationQualifier && $scope.editItem.TradingToLocal.ProtocolX12.AuthorizationQualifier === '00') {
          return $scope.editItem.TradingToLocal.ProtocolX12.AuthorizationValue = null;
        }
      };
      $scope.tradingISA3Changed = function() {
        if ($scope.editItem.TradingToLocal.ProtocolX12.SecurityQualifier && $scope.editItem.TradingToLocal.ProtocolX12.SecurityQualifier === '00') {
          return $scope.editItem.TradingToLocal.ProtocolX12.SecurityValue = null;
        }
      };
      $scope.initX12EnvelopesOverrides = function() {
        $scope.X12EnvelopesOverrides = {};
        $scope.X12EnvelopesOverrides.ProtocolVersion = $scope.editItem.LocalToTrading.ProtocolX12.GroupHeaderVersion;
        $scope.X12EnvelopesOverrides.FunctionalIdentifierCode = $scope.functionalIdentifierCodeList[0].Code;
        $scope.X12EnvelopesOverrides.DateFormat = $scope.dateFormatList[0].Code;
        $scope.X12EnvelopesOverrides.TimeFormat = $scope.timeFormatList[0].Code;
        $scope.X12EnvelopesOverrides.ResponsibleAgencyCode = $scope.editItem.LocalToTrading.ProtocolX12.GroupResponsibleAgencyCode;
        return $scope.X12EnvelopesOverrides.TransactionSetType = '110';
      };
      $scope.editItem = angular.copy(agreement.editItem);
      $scope.bindingData = function() {
        $scope.promise = $scope.getPartnerInfo();
        return agreementOnewayAPI.search({
          agreementID: $scope.editItem.Id,
          protocolX12: true,
          transportProtocol: true,
          agreementTransactionList: true
        }, function(onewayResponse) {
          if (onewayResponse && onewayResponse.Succeeded) {
            $scope.editItem.LocalToTrading = onewayResponse.AgreementOnewayList[0];
            $scope.editItem.TradingToLocal = onewayResponse.AgreementOnewayList[1];
            if ($scope.editItem.LocalToTrading.ProtocolX12) {
              if ($scope.editItem.LocalToTrading.ProtocolX12.UseControlStandardsIdAsRepetitionCharacter === true) {
                $scope.editItem.LocalToTrading.ProtocolX12.isa11Usage = 'R';
              } else {
                $scope.editItem.LocalToTrading.ProtocolX12.isa11Usage = 'U';
              }
              if ($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID && $scope.editItem.LocalToTrading.ProtocolX12.UseControlStandardsIdAsRepetitionCharacter === true) {
                $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char = String.fromCharCode($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID);
                $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char);
              }
              if ($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator) {
                $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char = String.fromCharCode($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator);
                $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char);
              }
              if ($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator) {
                $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char = String.fromCharCode($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator);
                $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char);
              }
              if ($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator) {
                $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char = String.fromCharCode($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator);
                $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char);
              }
              if ($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar) {
                $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char = String.fromCharCode($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar);
                $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_hex = agreement.stringToHex($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char);
              }
            }
            if ($scope.editItem.LocalToTrading.ProtocolX12.UseControlStandardsIdAsRepetitionCharacter === true) {
              $scope.editItem.LocalToTrading.ProtocolX12.isa11Usage;
            }
            return $scope.promise = $scope.HandleCustomeSettingDisplay();
          } else {
            return common.ShowAPIError('Get agreement-oneway data failed', onewayResponse);
          }
        }, function(error) {
          return common.ShowAPIError('Get agreement-oneway data failed', error.data);
        });
      };
      $scope.getPartnerInfo = function() {
        partnerAPI.search({
          id: $scope.editItem.LocalStation.PartnerID
        }, function(result) {
          if (result && result.Succeeded) {
            $scope.editItem.LocalStation.PartnerName = result.PartnerList[0].Name;
            $scope.selectLocalPartner = result.PartnerList[0];
            return $scope.selectLocalStation = $scope.editItem.LocalStation;
          } else {
            return common.ShowAPIError('Get local partner info failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get local partner info failed.', error.Data);
        });
        return partnerAPI.search({
          id: $scope.editItem.TradingStation.PartnerID
        }, function(result) {
          if (result && result.Succeeded) {
            $scope.editItem.TradingStation.PartnerName = result.PartnerList[0].Name;
            $scope.selectTradingPartner = result.PartnerList[0];
            return $scope.selectTradingStation = $scope.editItem.TradingStation;
          } else {
            return common.ShowAPIError('Get trading partner info failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get local partner info failed.', error.Data);
        });
      };
      $scope.promise = $scope.getSetting();
      $scope.findSettingCode = function(settingList, code) {
        var index, listIndex, setting;
        listIndex = -1;
        for (index in settingList) {
          if (settingList[index].Code === code) {
            setting = settingList[index];
            listIndex = index;
          }
        }
        return listIndex;
      };
      $scope.syncSetting = function() {
        var listIndex;
        if ($scope.editItem.LocalToTrading.ProtocolX12.SenderID) {
          listIndex = $scope.findSettingCode($scope.ISA5List, $scope.editItem.LocalToTrading.ProtocolX12.SenderID);
          if (listIndex !== -1) {
            $scope.editItem.LocalToTrading.ProtocolX12.SenderIDQualifier = $scope.ISA5List[listIndex].Code;
          }
        }
        if ($scope.editItem.TradingToLocal.ProtocolX12.SenderID) {
          listIndex = $scope.findSettingCode($scope.ISA5List, $scope.editItem.TradingToLocal.ProtocolX12.SenderID);
          if (listIndex !== -1) {
            $scope.editItem.TradingToLocal.ProtocolX12.SenderIDQualifier = $scope.ISA5List[listIndex].Code;
          }
        }
        if ($scope.editItem.LocalToTrading.ProtocolX12.ReceiverID) {
          listIndex = $scope.findSettingCode($scope.ISA7List, $scope.editItem.LocalToTrading.ProtocolX12.ReceiverID);
          if (listIndex !== -1) {
            $scope.editItem.LocalToTrading.ProtocolX12.ReceiverIDQualifier = $scope.ISA7List[listIndex].Code;
          }
        }
        if ($scope.editItem.TradingToLocal.ProtocolX12.ReceiverID) {
          listIndex = $scope.findSettingCode($scope.ISA7List, $scope.editItem.TradingToLocal.ProtocolX12.ReceiverID);
          if (listIndex !== -1) {
            return $scope.editItem.TradingToLocal.ProtocolX12.ReceiverIDQualifier = $scope.ISA7List[listIndex].Code;
          }
        }
      };
      $scope.onISA5Changed = function(direction) {
        if (direction === 'local') {
          $scope.local_ISA6Code = $scope.local_selectedISA5.Code;
        }
        if (direction === 'trading') {
          return $scope.trading_ISA6Code = $scope.trading_selectedISA5.Code;
        }
      };
      $scope.onISA7Changed = function(direction) {
        if (direction === 'local') {
          $scope.local_ISA8Code = $scope.local_selectedISA7.Code;
        }
        if (direction === 'trading') {
          return $scope.trading_ISA8Code = $scope.trading_selectedISA7.Code;
        }
      };
      $scope.isa6_Change = function(direction) {
        return $scope.syncSetting();
      };
      $scope.isa8_Change = function(direction) {
        return $scope.syncSetting();
      };
      $scope.save = function() {
        var checkCharArray, checkTransactionListMsg, checkTransactionListNotEmpty, index;
        agreement.checkErrorField($scope.agreementForm);
        if ($scope.agreementForm.$valid) {
          $scope.local_dataElementSeparator_Type = $scope.charTypeList[0];
          $scope.local_componentElementSeparator_Type = $scope.charTypeList[0];
          $scope.local_segmentTerminator_Type = $scope.charTypeList[0];
          $scope.local_replaceChar_Type = $scope.charTypeList[0];
          $scope.charTypeChanged('dataElementSeparator');
          $scope.charTypeChanged('componentElementSeparator');
          $scope.charTypeChanged('segmentTerminator');
          $scope.charTypeChanged('replaceChar');
          if ($scope.editItem.LocalToTrading.ProtocolX12.isa11Usage === 'R') {
            $scope.editItem.LocalToTrading.ProtocolX12.UseControlStandardsIdAsRepetitionCharacter = true;
            if ($scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char) {
              $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID = $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID_char.charCodeAt(0);
            }
          } else {
            $scope.editItem.LocalToTrading.ProtocolX12.ControlStandardsID = 'U'.charCodeAt(0);
            $scope.editItem.LocalToTrading.ProtocolX12.UseControlStandardsIdAsRepetitionCharacter = false;
          }
          if ($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char) {
            $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator = $scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char.charCodeAt(0);
          }
          if ($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char) {
            $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator = $scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char.charCodeAt(0);
          }
          if ($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char) {
            $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator = $scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char.charCodeAt(0);
          }
          if ($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char) {
            $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar = $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char.charCodeAt(0);
          }
          $scope.request = {
            Agreement: $scope.editItem
          };
          $scope.request.Agreement.EncodingProtocolType = 'X12';
          checkCharArray = [];
          checkCharArray.push($scope.editItem.LocalToTrading.ProtocolX12.DataElementSeparator_char);
          checkCharArray.push($scope.editItem.LocalToTrading.ProtocolX12.ComponentSeparator_char);
          checkCharArray.push($scope.editItem.LocalToTrading.ProtocolX12.SegmentTerminator_char);
          if ($scope.editItem.LocalToTrading.ProtocolX12.ReplaceSeparatorsInPayload === true && $scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char) {
            checkCharArray.push($scope.editItem.LocalToTrading.ProtocolX12.ReplaceChar_char);
          }
          if (agreement.checkDuplicateChar(checkCharArray) === true) {
            messager.error('Data element separator, component element separator,segment terminator and replace separators value cannot be repeated.');
            return;
          }
          if ((!$scope.editItem.LocalToTrading.AgreementTransactionList || $scope.editItem.LocalToTrading.AgreementTransactionList.length === 0) && (!$scope.editItem.TradingToLocal.AgreementTransactionList || $scope.editItem.TradingToLocal.AgreementTransactionList.length === 0)) {
            messager.error('Must contain a supported business transaction.');
            return;
          }
          checkTransactionListNotEmpty = true;
          checkTransactionListMsg = 'In the [' + $scope.editItem.LocalStation.Name + ' -> ' + $scope.editItem.TradingStation.Name + ']';
          if ($scope.editItem.LocalToTrading.AgreementTransactionList && $scope.editItem.LocalToTrading.AgreementTransactionList.length > 0) {
            for (index in $scope.editItem.LocalToTrading.AgreementTransactionList) {
              if (!$scope.editItem.LocalToTrading.AgreementTransactionList[index].MapperID) {
                checkTransactionListMsg = checkTransactionListMsg + ' supported business transactions, you must specify the source schema and mapper.';
                checkTransactionListNotEmpty = false;
                break;
              }
            }
          }
          if (checkTransactionListNotEmpty === false) {
            messager.error(checkTransactionListMsg);
            return;
          }
          checkTransactionListMsg = 'In the [' + $scope.editItem.TradingStation.Name + ' -> ' + $scope.editItem.LocalStation.Name + ']';
          if ($scope.editItem.TradingToLocal.AgreementTransactionList && $scope.editItem.TradingToLocal.AgreementTransactionList.length > 0) {
            for (index in $scope.editItem.TradingToLocal.AgreementTransactionList) {
              if (!$scope.editItem.TradingToLocal.AgreementTransactionList[index].MapperID) {
                checkTransactionListMsg = checkTransactionListMsg + ' supported business transactions, you must specify the source schema and mapper.';
                checkTransactionListNotEmpty = false;
                break;
              }
              if (!$scope.editItem.TradingToLocal.AgreementTransactionList[index].DestinationTransportProtocolSettingsID) {
                checkTransactionListMsg = checkTransactionListMsg + ' Supported business transactions, you must specify the destination transmission.';
                checkTransactionListNotEmpty = false;
                break;
              }
            }
          }
          if (checkTransactionListNotEmpty === false) {
            messager.error(checkTransactionListMsg);
            return;
          }
          $scope.editItem.LocalToTrading.ProtocolX12.ReceiverIDName = agreement.GetISANameByCode($scope.editItem.LocalToTrading.ProtocolX12.ReceiverIDQualifier, $scope.ISA7List);
          $scope.editItem.LocalToTrading.ProtocolX12.SenderIDName = agreement.GetISANameByCode($scope.editItem.LocalToTrading.ProtocolX12.SenderIDQualifier, $scope.ISA5List);
          $scope.editItem.LocalToTrading.ProtocolX12.SecurityName = agreement.GetISANameByCode($scope.editItem.LocalToTrading.ProtocolX12.SecurityQualifier, $scope.ISA3List);
          $scope.editItem.LocalToTrading.ProtocolX12.AuthorizationName = agreement.GetISANameByCode($scope.editItem.LocalToTrading.ProtocolX12.AuthorizationQualifier, $scope.ISA1List);
          $scope.editItem.TradingToLocal.ProtocolX12.ReceiverIDName = agreement.GetISANameByCode($scope.editItem.TradingToLocal.ProtocolX12.ReceiverIDQualifier, $scope.ISA7List);
          $scope.editItem.TradingToLocal.ProtocolX12.SenderIDName = agreement.GetISANameByCode($scope.editItem.TradingToLocal.ProtocolX12.SenderIDQualifier, $scope.ISA5List);
          $scope.editItem.TradingToLocal.ProtocolX12.SecurityName = agreement.GetISANameByCode($scope.editItem.TradingToLocal.ProtocolX12.SecurityQualifier, $scope.ISA3List);
          $scope.editItem.TradingToLocal.ProtocolX12.AuthorizationName = agreement.GetISANameByCode($scope.editItem.TradingToLocal.ProtocolX12.AuthorizationQualifier, $scope.ISA1List);
          $scope.isSubmit = true;
          $scope.submitMessage = 'Processing...';
          return $scope.submitPromise = $scope.submitAgreementItem();
        }
      };
      $scope.submitAgreementItem = function() {
        var equestItem;
        equestItem = angular.copy($scope.request);
        agreement.removeNotOverridesTransmissionWithAPIRequest(equestItem.Agreement);
        return agreementAPI.edit(equestItem, function(result) {
          if (result.Succeeded === true) {
            $scope.transferObj.obj = result.AgreementList[0];
            common.navigate('transfer', $scope.transferObj);
          } else {
            common.ShowAPIError('Edit Agreement Failed', result);
          }
          return $scope.isSubmit = false;
        }, function(error) {
          common.ShowAPIError('Edit Agreement Failed', error.data);
          return $scope.isSubmit = false;
        });
      };
      $scope.currentTransaction = null;
      $scope.localTransactionList = [];
      $scope.tradingTransactionList = [];
      $scope.addTransaction = function(transactionList) {
        return transactionList.push({
          Status: "Active"
        });
      };
      $scope.removeTransaction = function(transactionList, index) {
        return transactionList.splice(index, 1);
      };
      $scope.selectOperationType = null;
      $scope.selectLocalTransmission = null;
      $scope.selectTradingTransmission = null;
      $scope.getTransmissionList = function() {
        return transmissionAPI.search({
          encodingprotocol: false
        }, function(result) {
          if (result && result.Succeeded) {
            $scope.transmissionList = result.ProtocolList;
            $scope.filterTransmissionList();
            return $scope.syncTransmissionList();
          } else {
            return common.ShowAPIError('Get transmission data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get transmission data failed', error.data);
        });
      };
      $scope.SetUserSelectedTransmission = function() {
        var index, selectedTransmission;
        selectedTransmission = null;
        for (index in $scope.transmissionList) {
          if ($scope.transmissionList[index].Selected === true) {
            selectedTransmission = $scope.transmissionList[index];
          }
        }
        if ($scope.selectOperationType === 'local') {
          if (selectedTransmission) {
            $scope.editItem.LocalToTrading.DestinationTransportProtocolSettingsID = selectedTransmission.Id;
            $scope.editItem.LocalToTrading.DestinationTransportProtocolType = selectedTransmission.ProtocolType;
          }
          $scope.editItem.LocalToTrading.DestinationTransportProtocol = selectedTransmission;
        }
        if ($scope.selectOperationType === 'trading') {
          if (selectedTransmission) {
            $scope.editItem.TradingToLocal.SourceTransportProtocolSettingsID = selectedTransmission.Id;
            $scope.editItem.TradingToLocal.SourceTransportProtocolType = selectedTransmission.ProtocolType;
          }
          $scope.editItem.TradingToLocal.SourceTransportProtocol = selectedTransmission;
        }
        if ($scope.selectOperationType === 'transaction') {
          if ($scope.selectTransmissionDirection === 'source') {
            $scope.currentTransaction.SourceTransportProtocolType = null;
            $scope.currentTransaction.SourceTransportProtocolSettingsID = null;
            $scope.currentTransaction.SourceTransportProtocol = selectedTransmission;
            if (selectedTransmission) {
              $scope.currentTransaction.SourceTransportProtocolType = selectedTransmission.ProtocolType;
              return $scope.currentTransaction.SourceTransportProtocolSettingsID = selectedTransmission.Id;
            }
          } else {
            $scope.currentTransaction.DestinationTransportProtocol = selectedTransmission;
            $scope.currentTransaction.DestinationTransportProtocolType = null;
            $scope.currentTransaction.DestinationTransportProtocolSettingsID = null;
            if (selectedTransmission) {
              $scope.currentTransaction.DestinationTransportProtocolType = selectedTransmission.ProtocolType;
              return $scope.currentTransaction.DestinationTransportProtocolSettingsID = selectedTransmission.Id;
            }
          }
        }
      };
      $scope.singleSelectTransmission = function(transmission) {
        var index, _results;
        _results = [];
        for (index in $scope.transmissionList) {
          if ($scope.transmissionList[index].Id === transmission.Id) {
            continue;
          } else {
            _results.push($scope.transmissionList[index].Selected = false);
          }
        }
        return _results;
      };
      $scope.syncTransmissionList = function() {
        var index, _results;
        _results = [];
        for (index in $scope.transmissionList) {
          if ($scope.selectOperationType === 'transaction') {
            if ($scope.selectTransmissionDirection === 'source' && $scope.currentTransaction.SourceTransportProtocol) {
              if ($scope.transmissionList[index].Id === $scope.currentTransaction.SourceTransportProtocol.Id) {
                $scope.transmissionList[index].Selected = true;
              }
            }
            if ($scope.selectTransmissionDirection === 'destination' && $scope.currentTransaction.DestinationTransportProtocol) {
              if ($scope.transmissionList[index].Id === $scope.currentTransaction.DestinationTransportProtocol.Id) {
                $scope.transmissionList[index].Selected = true;
              }
            }
            if ($scope.tabType === 'local' && $scope.selectTransmissionDirection === 'destination' && !$scope.currentTransaction.DestinationTransportProtocol && $scope.editItem.LocalToTrading.DestinationTransportProtocol) {
              if ($scope.transmissionList[index].Id === $scope.editItem.LocalToTrading.DestinationTransportProtocol.Id) {
                $scope.transmissionList[index].Selected = true;
              }
            }
            if ($scope.tabType === 'trading' && $scope.selectTransmissionDirection === 'source' && !$scope.currentTransaction.SourceTransportProtocol && $scope.editItem.TradingToLocal.SourceTransportProtocol) {
              if ($scope.transmissionList[index].Id === $scope.editItem.TradingToLocal.SourceTransportProtocol.Id) {
                _results.push($scope.transmissionList[index].Selected = true);
              } else {
                _results.push(void 0);
              }
            } else {
              _results.push(void 0);
            }
          } else {
            if ($scope.selectOperationType === 'local' && $scope.editItem.LocalToTrading.DestinationTransportProtocol) {
              if ($scope.transmissionList[index].Id === $scope.editItem.LocalToTrading.DestinationTransportProtocol.Id) {
                $scope.transmissionList[index].Selected = true;
              }
            }
            if ($scope.selectOperationType === 'trading' && $scope.editItem.TradingToLocal.SourceTransportProtocol) {
              if ($scope.transmissionList[index].Id === $scope.editItem.TradingToLocal.SourceTransportProtocol.Id) {
                _results.push($scope.transmissionList[index].Selected = true);
              } else {
                _results.push(void 0);
              }
            } else {
              _results.push(void 0);
            }
          }
        }
        return _results;
      };
      $scope.filterTransmissionList = function() {
        var index, _results;
        _results = [];
        for (index in $scope.transmissionList) {
          $scope.transmissionList[index].showSelect = true;
          if ($scope.selectOperationType === 'transaction') {
            if ($scope.tabType === 'local' && $scope.selectTransmissionDirection === 'destination') {
              $scope.filterTransactionTransmissionList($scope.transmissionList[index], 'Sending', $scope.currentTransaction.SourceTransportProtocol, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
            }
            if ($scope.tabType === 'trading' && $scope.selectTransmissionDirection === 'source') {
              $scope.filterTransactionTransmissionList($scope.transmissionList[index], 'Receiving', $scope.currentTransaction.DestinationTransportProtocol, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
            }
            if ($scope.tabType === 'trading' && $scope.selectTransmissionDirection === 'destination') {
              $scope.filterTransactionTransmissionList($scope.transmissionList[index], 'Sending', $scope.currentTransaction.SourceTransportProtocol, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
            }
            $scope.filterTransactionTransmissionList2($scope.transmissionList[index], $scope.tabType, $scope.selectTransmissionDirection);
          } else {
            if ($scope.selectOperationType === 'local') {
              $scope.filterTransmissionListBelongTo($scope.transmissionList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
              if ($scope.transmissionList[index].Direction !== 'Sending') {
                $scope.transmissionList[index].showSelect = false;
              }
              $scope.filterTransactionTransmissionList2($scope.transmissionList[index], $scope.selectOperationType, 'destination');
            }
            if ($scope.selectOperationType === 'trading') {
              $scope.filterTransmissionListBelongTo($scope.transmissionList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
              if ($scope.transmissionList[index].Direction !== 'Receiving') {
                $scope.transmissionList[index].showSelect = false;
              }
              $scope.filterTransactionTransmissionList2($scope.transmissionList[index], $scope.selectOperationType, 'source');
            }
          }
          _results.push($scope.transmissionList = $filter('orderBy')($scope.transmissionList, 'ownerSort'));
        }
        return _results;
      };
      $scope.filterTransactionTransmissionList = function(transmission, direction, compareTransmission, partnerId, stationId) {
        $scope.filterTransmissionListBelongTo(transmission, true, partnerId, stationId);
        if (transmission.Direction !== direction) {
          return transmission.showSelect = false;
        }
      };
      $scope.filterTransactionTransmissionList2 = function(transmission, tabType, direction) {
        if (tabType === 'local') {
          if ($scope.selectOperationType === 'local') {
            if (direction === 'destination' && transmission.ProtocolType === 'MQ') {
              transmission.showSelect = false;
            }
          } else {
            if (direction === 'source' && transmission.ProtocolType !== 'MQ') {
              transmission.showSelect = false;
            }
            if (direction === 'destination' && (transmission.ProtocolType === 'MQ' || transmission.ProtocolType === 'AS2')) {
              transmission.showSelect = false;
            }
          }
        }
        if (tabType === 'trading') {
          if ($scope.selectOperationType === 'trading') {
            if (direction === 'source' && transmission.ProtocolType === 'MQ') {
              return transmission.showSelect = false;
            }
          } else {
            if (direction === 'source' && (transmission.ProtocolType === 'MQ' || transmission.ProtocolType === 'AS2')) {
              transmission.showSelect = false;
            }
            if (direction === 'destination' && transmission.ProtocolType !== 'MQ') {
              return transmission.showSelect = false;
            }
          }
        }
      };
      $scope.filterTransmissionListBelongTo = function(transmission, needFilter, partnerId, stationId) {
        if (transmission.OwnerType === common.ownerType.organization) {
          transmission.showSelect = true;
          if (common.currentUser.Type === common.ownerType.partner || common.currentUser.Type === common.ownerType.station) {
            transmission.ownerSort = 3;
          } else {
            transmission.ownerSort = 1;
          }
        }
        if (transmission.OwnerType === common.ownerType.partner) {
          transmission.ownerSort = 2;
          if (needFilter && partnerId !== transmission.OwnerID) {
            transmission.showSelect = false;
          }
        }
        if (transmission.OwnerType === common.ownerType.station) {
          if (common.currentUser.Type === common.ownerType.partner || common.currentUser.Type === common.ownerType.station) {
            transmission.ownerSort = 1;
          } else {
            transmission.ownerSort = 3;
          }
          if (needFilter && stationId !== transmission.OwnerID) {
            return transmission.showSelect = false;
          }
        }
      };
      $scope.openTransmissionDialog = function(operationType) {
        $scope.isBasicSelect = true;
        $scope.tabType = operationType;
        $scope.transmissionList = null;
        $scope.selectOperationType = operationType;
        $scope.transmissionModal = true;
        return $scope.promiseTransmission = $scope.getTransmissionList();
      };
      $scope.openTransmissionDialogByTransaction = function(transactionList, index, direction, tabType) {
        $scope.isBasicSelect = false;
        $scope.tabType = tabType;
        $scope.transmissionList = null;
        $scope.selectOperationType = 'transaction';
        $scope.selectTransmissionDirection = direction;
        $scope.currentTransaction = transactionList[index];
        $scope.transmissionModal = true;
        return $scope.promiseTransmission = $scope.getTransmissionList();
      };
      $scope.closeTransmissionDialog = function() {
        return $scope.transmissionModal = false;
      };
      $scope.isBasicSelect = true;
      $scope.SelectedTransmissionOK = function() {
        if (($scope.isBasicSelect = true)) {
          if ($scope.tabType === 'local') {
            if ($scope.editItem.LocalToTrading.DestinationTransportProtocol) {
              $scope.oldBasicTransmissionID = angular.copy($scope.editItem.LocalToTrading.DestinationTransportProtocol.Id);
            }
          } else {
            if ($scope.editItem.TradingToLocal.SourceTransportProtocol) {
              $scope.oldBasicTransmissionID = angular.copy($scope.editItem.TradingToLocal.SourceTransportProtocol.Id);
            }
          }
        }
        $scope.SetUserSelectedTransmission();
        $scope.transmissionModal = false;
        if ($scope.selectOperationType !== 'transaction' && $scope.tabType === 'local' && $scope.editItem.LocalToTrading.DestinationTransportProtocol && $scope.editItem.LocalToTrading.DestinationTransportProtocol.ProtocolType && $scope.editItem.LocalToTrading.DestinationTransportProtocol.ProtocolType === 'AS2') {
          transmission.getData2($scope.editItem.LocalToTrading, $scope.editItem.LocalToTrading.DestinationTransportProtocol, $scope.tabType);
        }
        if ($scope.selectOperationType !== 'transaction' && $scope.tabType === 'trading' && $scope.editItem.TradingToLocal.SourceTransportProtocol && $scope.editItem.TradingToLocal.SourceTransportProtocol.ProtocolType && $scope.editItem.TradingToLocal.SourceTransportProtocol.ProtocolType === 'AS2') {
          transmission.getData2($scope.editItem.TradingToLocal, $scope.editItem.TradingToLocal.SourceTransportProtocol, $scope.tabType);
        }
        if ($scope.isBasicSelect) {
          if ($scope.tabType === 'local') {
            return agreement.clearNotOverridesTransmission($scope.tabType, $scope.oldBasicTransmissionID, $scope.editItem.LocalToTrading.AgreementTransactionList);
          } else {
            return agreement.clearNotOverridesTransmission($scope.tabType, $scope.oldBasicTransmissionID, $scope.editItem.TradingToLocal.AgreementTransactionList);
          }
        }
      };
      $scope.syncSchemaList = function() {
        var index, _results;
        if (!$scope.currentTransaction.Mapper) {
          $scope.currentTransaction.Mapper = {};
        }
        _results = [];
        for (index in $scope.schemaList) {
          $scope.schemaList[index].ViewTransactionType = customSettingCache.GetSettingName(customSettingCache.CategoryName.TransactionType, $scope.schemaList[index].TransactionType);
          if ($scope.currentTransaction.Mapper.SourceSchema && $scope.currentTransaction.Mapper.SourceSchema && $scope.schemaList[index].Id === $scope.currentTransaction.Mapper.SourceSchema.Id) {
            _results.push($scope.schemaList[index].Selected = true);
          } else {
            _results.push(void 0);
          }
        }
        return _results;
      };
      $scope.filterSchema = function(tabType) {
        var index;
        for (index in $scope.schemaList) {
          $scope.schemaList[index].showSelect = true;
          if (tabType === 'local') {
            $scope.filterTransmissionListBelongTo($scope.schemaList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
          }
          if (tabType === 'trading') {
            $scope.filterTransmissionListBelongTo($scope.schemaList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
          }
          agreement.hideHasUsedSchema($scope.usedSchemaTypes, $scope.schemaList);
        }
        return $scope.schemaList = $filter('orderBy')($scope.schemaList, 'ownerSort');
      };
      $scope.getCustomSetting = function() {
        if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
          return customSettingCache.RefreshData($scope.syncSchemaList, common.currentOrganization.Id);
        } else {
          return $scope.syncSchemaList();
        }
      };
      $scope.getSchemaList = function(tabType) {
        return schemaAPI.search({
          SchemaType: tabType
        }, function(result) {
          if (result && result.Succeeded) {
            $scope.schemaList = result.SchemaList;
            $scope.filterSchema(tabType);
            return $scope.getCustomSetting();
          } else {
            return common.ShowAPIError('Get schema data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get schema data failed', error.data);
        });
      };
      $scope.SetUserSelectedSchema = function() {
        var index, selectedSchema;
        selectedSchema = null;
        for (index in $scope.schemaList) {
          if ($scope.schemaList[index].Selected === true) {
            selectedSchema = $scope.schemaList[index];
          }
        }
        $scope.currentTransaction.Mapper.SourceSchema = selectedSchema;
        if (selectedSchema) {
          $scope.currentTransaction.Mapper.SourceSchema.Id = selectedSchema.Id;
          return $scope.currentTransaction.Mapper.SourceSchema.Name = selectedSchema.Name;
        }
      };
      $scope.singleSelectSchema = function(schema) {
        var index, _results;
        _results = [];
        for (index in $scope.schemaList) {
          if ($scope.schemaList[index].Id === schema.Id) {
            continue;
          } else {
            _results.push($scope.schemaList[index].Selected = false);
          }
        }
        return _results;
      };
      $scope.usedSchemaTypes = [];
      $scope.openSchemaDialog = function(transactionList, index, tabType) {
        $scope.tabType = tabType;
        $scope.usedSchemaTypes = agreement.loadUsedSchemaTypes(transactionList, transactionList[index]);
        $scope.currentTransaction = transactionList[index];
        $scope.schemaList = null;
        $scope.schemaModal = true;
        return $scope.promiseSchema = $scope.getSchemaList(tabType);
      };
      $scope.closeSchemaDialog = function() {
        return $scope.schemaModal = false;
      };
      $scope.SelectedSchemaOK = function() {
        $scope.SetUserSelectedSchema();
        return $scope.schemaModal = false;
      };
      $scope.syncMapperList = function() {
        var index, _results;
        if ($scope.currentTransaction.Mapper) {
          _results = [];
          for (index in $scope.mapperList) {
            if ($scope.mapperList[index].Id === $scope.currentTransaction.Mapper.Id) {
              _results.push($scope.mapperList[index].Selected = true);
            } else {
              _results.push(void 0);
            }
          }
          return _results;
        }
      };
      $scope.getMapperList = function() {
        if (!$scope.currentTransaction.Mapper.SourceSchema) {
          return messager.error('Please select souce schema.');
        } else {
          return mapperAPI.search({
            schema: true,
            sourceschemaid: $scope.currentTransaction.Mapper.SourceSchema.Id
          }, function(result) {
            var index;
            if (result && result.Succeeded) {
              $scope.mapperList = result.MapperList;
              for (index in $scope.mapperList) {
                $scope.filterTransmissionListBelongTo($scope.mapperList[index], false, null, null);
              }
              $scope.mapperList = $filter('orderBy')($scope.mapperList, 'ownerSort');
              return $scope.syncMapperList();
            } else {
              return common.ShowAPIError('Get mapper data failed', result);
            }
          }, function(error) {
            return common.ShowAPIError('Get mapper data failed', error.data);
          });
        }
      };
      $scope.SetUserSelectedMapper = function() {
        var index, selectedMapper;
        selectedMapper = null;
        for (index in $scope.mapperList) {
          if ($scope.mapperList[index].Selected === true) {
            selectedMapper = $scope.mapperList[index];
          }
        }
        $scope.currentTransaction.Mapper.Name = null;
        if (!$scope.currentTransaction.Mapper.DestinationSchema) {
          $scope.currentTransaction.Mapper.DestinationSchema = {};
        }
        $scope.currentTransaction.Mapper.DestinationSchemaID = null;
        $scope.currentTransaction.Mapper.DestinationSchema.Name = null;
        $scope.currentTransaction.Mapper.Id = null;
        if (selectedMapper) {
          $scope.currentTransaction.Mapper.Name = selectedMapper.Name;
          $scope.currentTransaction.Mapper.DestinationSchemaID = selectedMapper.DestinationSchema.Id;
          $scope.currentTransaction.Mapper.DestinationSchema.Name = selectedMapper.DestinationSchema.Name;
          $scope.currentTransaction.Mapper.DestinationSchema.TransactionType = selectedMapper.DestinationSchema.TransactionType;
          $scope.currentTransaction.Mapper.Id = selectedMapper.Id;
          return $scope.currentTransaction.MapperID = selectedMapper.Id;
        }
      };
      $scope.singleSelectMapper = function(mapper) {
        var index, _results;
        _results = [];
        for (index in $scope.mapperList) {
          if ($scope.mapperList[index].Id === mapper.Id) {
            continue;
          } else {
            _results.push($scope.mapperList[index].Selected = false);
          }
        }
        return _results;
      };
      $scope.openMapperDialog = function(transactionList, index, tabType) {
        $scope.tabType = tabType;
        $scope.currentTransaction = transactionList[index];
        $scope.mapperList = null;
        $scope.mapperModal = true;
        return $scope.promiseMapper = $scope.getMapperList();
      };
      $scope.closeMapperDialog = function() {
        return $scope.mapperModal = false;
      };
      $scope.SelectedMapperOK = function() {
        $scope.SetUserSelectedMapper();
        if ($scope.currentTransaction.X12EnvelopesOverrides) {
          if ($scope.tabType === 'local' && $scope.currentTransaction.Mapper.DestinationSchema) {
            $scope.currentTransaction.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.DestinationSchema.Namespace;
          }
          if ($scope.tabType === 'trading' && $scope.currentTransaction.Mapper.SourceSchema) {
            $scope.currentTransaction.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.SourceSchema.Namespace;
          }
        }
        return $scope.mapperModal = false;
      };
      $scope.initPolicy = function() {
        $scope.Policy = {};
        $scope.Policy.MaxRetryCount = 3;
        return $scope.Policy.RetryInterval = 300;
      };
      $scope.$watch("Policy.AutoRetryEnabled", (function() {
        if ($scope.Policy.AutoRetryEnabled === false) {
          $scope.Policy.MaxRetryCount = 3;
          return $scope.Policy.RetryInterval = 300;
        }
      }), true);
      $scope.openX12GroupDialog = function(transactionList, index, operationType) {
        $scope.OverrideX12Group_OperationType = operationType;
        $scope.currentTransaction = transactionList[index];
        $scope.initPolicy();
        if (!$scope.currentTransaction.X12EnvelopesOverrides) {
          $scope.initX12EnvelopesOverrides();
          if (operationType === 'local') {
            $scope.X12EnvelopesOverrides.SenderID = $scope.editItem.LocalToTrading.ProtocolX12.SenderID;
            $scope.X12EnvelopesOverrides.ReceiverID = $scope.editItem.LocalToTrading.ProtocolX12.ReceiverID;
            $scope.X12EnvelopesOverrides.DateFormat = $scope.editItem.LocalToTrading.ProtocolX12.GroupDateFormat;
            $scope.X12EnvelopesOverrides.TimeFormat = $scope.editItem.LocalToTrading.ProtocolX12.GroupTimeFormat;
            if ($scope.editItem.LocalToTrading.ProtocolX12.ControlVersionNumber) {
              $scope.X12EnvelopesOverrides.ControlVersionNumber = $scope.editItem.LocalToTrading.ProtocolX12.ControlVersionNumber;
            }
            if ($scope.currentTransaction.Mapper.DestinationSchema && $scope.currentTransaction.Mapper.DestinationSchema.TransactionType) {
              $scope.X12EnvelopesOverrides.FunctionalIdentifierCode = $scope.currentTransaction.Mapper.DestinationSchema.TransactionType;
            }
            if ($scope.currentTransaction.Mapper.DestinationSchema) {
              $scope.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.DestinationSchema.Namespace;
            }
          } else {
            $scope.X12EnvelopesOverrides.SenderID = $scope.editItem.TradingToLocal.ProtocolX12.SenderID;
            $scope.X12EnvelopesOverrides.ReceiverID = $scope.editItem.TradingToLocal.ProtocolX12.ReceiverID;
            if ($scope.currentTransaction.Mapper.SourceSchema) {
              $scope.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.SourceSchema.Namespace;
            }
          }
        } else {
          if (operationType === 'local') {
            if ($scope.currentTransaction.Mapper.DestinationSchema) {
              $scope.currentTransaction.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.DestinationSchema.Namespace;
            }
          } else {
            if ($scope.currentTransaction.Mapper.SourceSchema) {
              $scope.currentTransaction.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.SourceSchema.Namespace;
            }
          }
          $scope.currentTransaction.X12EnvelopesOverrides.DateFormat = $scope.currentTransaction.X12EnvelopesOverrides.DateFormat.toString();
          $scope.currentTransaction.X12EnvelopesOverrides.TimeFormat = $scope.currentTransaction.X12EnvelopesOverrides.TimeFormat.toString();
          $scope.X12EnvelopesOverrides = angular.copy($scope.currentTransaction.X12EnvelopesOverrides);
        }
        if ($scope.currentTransaction.Policy) {
          $scope.Policy = angular.copy($scope.currentTransaction.Policy);
        }
        if (operationType === 'local') {
          delete $scope.X12EnvelopesOverrides.SplitCount;
        } else {
          if ($scope.X12EnvelopesOverrides.SplitCount !== null && $scope.X12EnvelopesOverrides.SplitCount !== void 0 && $scope.X12EnvelopesOverrides.SplitCount < 1) {
            delete $scope.X12EnvelopesOverrides.SplitCount;
          }
        }
        return $scope.x12GroupModal = true;
      };
      $scope.closeX12GroupDialog = function() {
        return $scope.x12GroupModal = false;
      };
      return $scope.SelectedX12GroupOK = function() {
        if ($scope.x12GroupForm.$valid) {
          if ($scope.Policy) {
            $scope.currentTransaction.Policy = angular.copy($scope.Policy);
          }
          $scope.currentTransaction.X12EnvelopesOverrides = angular.copy($scope.X12EnvelopesOverrides);
          if ($scope.currentTransaction.EnvelopeOverrideID) {
            $scope.currentTransaction.X12EnvelopesOverrides.Id = $scope.currentTransaction.EnvelopeOverrideID;
          }
          $scope.currentTransaction.X12EnvelopesOverrides.TransactionSetType = $filter('filter')($scope.functionalIdentifierCodeList, {
            Code: $scope.currentTransaction.X12EnvelopesOverrides.FunctionalIdentifierCode
          })[0].Value;
          return $scope.x12GroupModal = false;
        }
      };
    }
  }
]);
