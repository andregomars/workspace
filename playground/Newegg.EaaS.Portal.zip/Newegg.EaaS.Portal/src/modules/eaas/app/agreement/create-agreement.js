﻿
angular.module('eaas-create-agreement', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/agreement/create", {
      templateUrl: "/modules/eaas/app/agreement/create-agreement.tpl.html",
      controller: 'EaaSCreateAgreementCtrl'
    });
  }
]).controller('EaaSCreateAgreementCtrl', [
  "$scope", "messager", "common", "agreement", "agreementAPI", "partnerAPI", "stationAPI", "transmission", "transmissionAPI", "schemaAPI", "mapperAPI", '$filter', 'customSettingCache', function($scope, messager, common, agreement, agreementAPI, partnerAPI, stationAPI, transmission, transmissionAPI, schemaAPI, mapperAPI, $filter, customSettingCache) {
    var pageName;
    $scope.transferObj = {
      isSucceed: true,
      action: 'create',
      objName: 'agreement',
      title: 'Agreement has been created successfully'
    };
    $scope.isSubmit = false;
    common.initUnSavedConfirm($scope);
    $scope.selectPartnerType = null;
    $scope.selectLocalPartner = null;
    $scope.selectLocalStation = null;
    $scope.selectTradingPartner = null;
    $scope.selectTradingStation = null;
    $scope.showLocalPartner = true;
    $scope.showTradingPartner = true;
    $scope.enableSelectLocal = true;
    $scope.enableSelectTrading = true;
    $scope.local_ISA6Value_Name = 'local_ISA6Value';
    $scope.local_ISA8Value_Name = 'local_ISA8Value';
    $scope.trading_ISA6Value_Name = 'trading_ISA6Value';
    $scope.trading_ISA8Value_Name = 'trading_ISA8Value';
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.submitMessage = 'Processing...';
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization'
    };
    pageName = common.currentRoutePath();
    $scope.initOwnerInfo = function() {
      var tempPartner, tempStation;
      tempPartner = {
        Id: common.current.link[pageName].pageParameter.Station.PartnerID,
        Name: common.current.link[pageName].pageParameter.Station.PartnerName
      };
      tempStation = angular.copy(common.current.link[pageName].pageParameter.Station);
      if (common.current.link[pageName].pageParameter.Station.PartnerType === 'Local') {
        $scope.selectLocalPartner = tempPartner;
        $scope.selectLocalStation = tempStation;
        $scope.showLocalPartner = false;
        $scope.enableSelectLocal = false;
      } else {
        $scope.selectTradingPartner = tempPartner;
        $scope.selectTradingStation = tempStation;
        $scope.showTradingPartner = false;
        $scope.enableSelectTrading = false;
      }
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Station.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Station.PartnerType + ' Station';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Station) {
      $scope.initOwnerInfo();
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Station) {
        $scope.initOwnerInfo();
      }
    }
    $scope.common = common;
    $scope.transmissionType = 'AS2';
    $scope.localISA1Changed = function() {
      if ($scope.local_selectedISA1 && $scope.local_selectedISA1.Code && $scope.local_selectedISA1.Code === '00') {
        return $scope.local_ISA2Value = null;
      }
    };
    $scope.localISA3Changed = function() {
      if ($scope.local_selectedISA3 && $scope.local_selectedISA3.Code && $scope.local_selectedISA3.Code === '00') {
        return $scope.local_ISA4Value = null;
      }
    };
    $scope.tradingISA1Changed = function() {
      if ($scope.trading_selectedISA1 && $scope.trading_selectedISA1.Code && $scope.trading_selectedISA1.Code === '00') {
        return $scope.trading_ISA2Value = null;
      }
    };
    $scope.tradingISA3Changed = function() {
      if ($scope.trading_selectedISA3 && $scope.trading_selectedISA3.Code && $scope.trading_selectedISA3.Code === '00') {
        return $scope.trading_ISA4Value = null;
      }
    };
    $scope.getSetting = function() {
      if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
        return customSettingCache.RefreshData($scope.HandleCustomeSettingDisplay, common.currentOrganization.Id);
      } else {
        return $scope.HandleCustomeSettingDisplay();
      }
    };
    $scope.HandleCustomeSettingDisplay = function() {
      var index;
      $scope.ISA1List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.AuthorizationQualifier));
      customSettingCache.CollatorSettingDisplayName($scope.ISA1List);
      $scope.ISA3List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.SecurityQualifier));
      customSettingCache.CollatorSettingDisplayName($scope.ISA3List);
      $scope.ISA5List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.IdentityQualifier));
      customSettingCache.CollatorSettingDisplayName($scope.ISA5List);
      $scope.ISA7List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.IdentityQualifier));
      customSettingCache.CollatorSettingDisplayName($scope.ISA7List);
      $scope.ISA12List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.X12Standards));
      customSettingCache.CollatorSettingDisplayName($scope.ISA12List);
      $scope.ISA15List = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.UsageIndicator));
      customSettingCache.CollatorSettingDisplayName($scope.ISA15List);
      $scope.dateFormatList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.GS4));
      $scope.timeFormatList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.GS5));
      $scope.protocolVersionList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.X12Standards));
      customSettingCache.CollatorSettingDisplayName($scope.protocolVersionList);
      $scope.responsibleAgencyCodeList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.GS7));
      customSettingCache.CollatorSettingDisplayName($scope.responsibleAgencyCodeList);
      $scope.functionalIdentifierCodeList = [];
      $scope.orignalFunctionalIdentifierCodeList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TransactionType));
      for (index in $scope.orignalFunctionalIdentifierCodeList) {
        if ($scope.orignalFunctionalIdentifierCodeList[index].Code === 'FA' || $scope.orignalFunctionalIdentifierCodeList[index].Code === 'UKN') {
          continue;
        } else {
          $scope.functionalIdentifierCodeList.push($scope.orignalFunctionalIdentifierCodeList[index]);
        }
      }
      customSettingCache.CollatorSettingDisplayName($scope.functionalIdentifierCodeList);
      $scope.trailingSeparatorPolicyList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TrailingSeparatorPolicy));
      $scope.characterSetList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.X12CharacterSet));
      if ($scope.characterSetList) {
        $scope.local_selectedCharacterSet = $scope.characterSetList[2];
        $scope.trading_selectedCharacterSet = $scope.characterSetList[2];
      }
      if ($scope.trailingSeparatorPolicyList) {
        $scope.trading_selectedTrailingSeparatorPolicy = $scope.trailingSeparatorPolicyList[1];
        $scope.local_selectedTrailingSeparatorPolicy = $scope.trailingSeparatorPolicyList[2];
      }
      $scope.local_selectedISA1 = $scope.ISA1List[0];
      $scope.local_selectedISA3 = $scope.ISA3List[0];
      $scope.local_selectedISA5 = $scope.ISA5List[0];
      $scope.local_selectedISA7 = $scope.ISA7List[0];
      $scope.defaultComboBoxByCode_ISA12();
      $scope.defaultComboBoxByCode_ISA15();
      $scope.trading_selectedISA1 = $scope.ISA1List[0];
      $scope.trading_selectedISA3 = $scope.ISA3List[0];
      $scope.trading_selectedISA5 = $scope.ISA5List[0];
      $scope.trading_selectedISA7 = $scope.ISA7List[0];
      $scope.dateFormatValue = $scope.dateFormatList[0].Code;
      $scope.timeFormatValue = $scope.timeFormatList[0].Code;
      $scope.local_responsibleAgencyCodeValue = 'X';
      return $scope.local_groupHeaderVersionValue = $scope.local_selectedISA12.Code + '0';
    };
    $scope.defaultComboBoxByCode_ISA12 = function() {
      var index;
      if (!$scope.ISA12List) {
        return;
      }
      for (index in $scope.ISA12List) {
        if ($scope.ISA12List[index].Code === '00401') {
          $scope.local_selectedISA12 = $scope.ISA12List[index];
          return;
        }
      }
    };
    $scope.defaultComboBoxByCode_ISA15 = function() {
      var index;
      if (!$scope.ISA15List) {
        return;
      }
      for (index in $scope.ISA15List) {
        if ($scope.ISA15List[index].Code === 'Test') {
          $scope.local_selectedISA15 = $scope.ISA15List[index];
          return;
        }
      }
    };
    $scope.initX12EnvelopesOverrides = function() {
      $scope.X12EnvelopesOverrides = {};
      $scope.X12EnvelopesOverrides.ProtocolVersion = angular.copy($scope.local_groupHeaderVersionValue);
      $scope.X12EnvelopesOverrides.FunctionalIdentifierCode = $scope.functionalIdentifierCodeList[0].Code;
      $scope.X12EnvelopesOverrides.DateFormat = $scope.dateFormatList[0].Code;
      $scope.X12EnvelopesOverrides.TimeFormat = $scope.timeFormatList[0].Code;
      $scope.X12EnvelopesOverrides.ResponsibleAgencyCode = $scope.local_responsibleAgencyCodeValue;
      return $scope.X12EnvelopesOverrides.TransactionSetType = '110';
    };
    $scope.promise = $scope.getSetting();
    $scope.isa11Usage = 'U';
    $scope.charTypeList = agreement.charTypeList;
    $scope.local_dataElementSeparator_Type = $scope.charTypeList[0];
    $scope.local_componentElementSeparator_Type = $scope.charTypeList[0];
    $scope.local_segmentTerminator_Type = $scope.charTypeList[0];
    $scope.local_replaceChar_Type = $scope.charTypeList[0];
    $scope.local_controlStandardsID_Type = $scope.charTypeList[0];
    $scope.local_controlStandardsID_char = '^';
    $scope.local_controlStandardsID_hex = agreement.stringToHex($scope.local_controlStandardsID_char);
    $scope.local_dataElementSeparator_char = '*';
    $scope.local_dataElementSeparator_hex = agreement.stringToHex($scope.local_dataElementSeparator_char);
    $scope.local_componentElementSeparator_char = '>';
    $scope.local_componentElementSeparator_hex = agreement.stringToHex($scope.local_componentElementSeparator_char);
    $scope.local_segmentTerminator_char = '~';
    $scope.local_segmentTerminator_hex = agreement.stringToHex($scope.local_segmentTerminator_char);
    $scope.local_segmentTerminatorSuffix = 'None';
    $scope.local_replaceSeparatorsInPayload = false;
    $scope.local_replaceChar_char = '$';
    $scope.local_replaceChar_hex = agreement.stringToHex($scope.local_replaceChar_char);
    $scope.charTypeChanged = function(type) {
      if (type === 'dataElementSeparator') {
        if ($scope.local_dataElementSeparator_Type.text === 'Hex') {
          return $scope.local_dataElementSeparator_hex = agreement.stringToHex($scope.local_dataElementSeparator_char);
        } else {
          return $scope.local_dataElementSeparator_char = agreement.hexToString($scope.local_dataElementSeparator_hex);
        }
      } else if (type === 'componentElementSeparator') {
        if ($scope.local_componentElementSeparator_Type.text === 'Hex') {
          return $scope.local_componentElementSeparator_hex = agreement.stringToHex($scope.local_componentElementSeparator_char);
        } else {
          return $scope.local_componentElementSeparator_char = agreement.hexToString($scope.local_componentElementSeparator_hex);
        }
      } else if (type === 'segmentTerminator') {
        if ($scope.local_segmentTerminator_Type.text === 'Hex') {
          return $scope.local_segmentTerminator_hex = agreement.stringToHex($scope.local_segmentTerminator_char);
        } else {
          return $scope.local_segmentTerminator_char = agreement.hexToString($scope.local_segmentTerminator_hex);
        }
      } else if (type === 'replaceChar') {
        if ($scope.local_replaceChar_Type.text === 'Hex') {
          return $scope.local_replaceChar_hex = agreement.stringToHex($scope.local_replaceChar_char);
        } else {
          return $scope.local_replaceChar_char = agreement.hexToString($scope.local_replaceChar_hex);
        }
      } else if (type === 'controlStandardsID') {
        if ($scope.local_controlStandardsID_Type.text === 'Hex') {
          return $scope.local_controlStandardsID_hex = agreement.stringToHex($scope.local_controlStandardsID_char);
        } else {
          return $scope.local_controlStandardsID_char = agreement.hexToString($scope.local_controlStandardsID_hex);
        }
      }
    };
    $scope.charTypeChanged2 = function(type) {
      if (type === 'dataElementSeparator') {
        return $scope.local_dataElementSeparator_hex = agreement.stringToHex($scope.local_dataElementSeparator_char);
      } else if (type === 'componentElementSeparator') {
        return $scope.local_componentElementSeparator_hex = agreement.stringToHex($scope.local_componentElementSeparator_char);
      } else if (type === 'segmentTerminator') {
        return $scope.local_segmentTerminator_hex = agreement.stringToHex($scope.local_segmentTerminator_char);
      } else if (type === 'replaceChar') {
        return $scope.local_replaceChar_hex = agreement.stringToHex($scope.local_replaceChar_char);
      } else if (type === 'controlStandardsID') {
        return $scope.local_controlStandardsID_hex = agreement.stringToHex($scope.local_controlStandardsID_char);
      }
    };
    $scope.trading_needFunctionalAck = false;
    $scope.trading_checkDuplicateInterchangeControlNumber = false;
    $scope.trading_checkDuplicateGroupControlNumber = false;
    $scope.trading_checkDuplicateTransactionSetControlNumber = false;
    $scope.trading_interchangeDuplicatesValidity = 30;
    $scope.findSettingCode = function(settingList, code) {
      var index, listIndex, setting;
      listIndex = -1;
      for (index in settingList) {
        if (settingList[index].Code === code) {
          setting = settingList[index];
          listIndex = index;
        }
      }
      return listIndex;
    };
    $scope.syncSetting = function() {
      var listIndex;
      if ($scope.local_ISA6Code) {
        listIndex = $scope.findSettingCode($scope.ISA5List, $scope.local_ISA6Code);
        if (listIndex !== -1) {
          $scope.local_selectedISA5 = $scope.ISA5List[listIndex];
        }
      }
      if ($scope.trading_ISA6Code) {
        listIndex = $scope.findSettingCode($scope.ISA5List, $scope.trading_ISA6Code);
        if (listIndex !== -1) {
          $scope.trading_selectedISA5 = $scope.ISA5List[listIndex];
        }
      }
      if ($scope.local_ISA8Code) {
        listIndex = $scope.findSettingCode($scope.ISA7List, $scope.local_ISA8Code);
        if (listIndex !== -1) {
          $scope.local_selectedISA7 = $scope.ISA7List[listIndex];
        }
      }
      if ($scope.trading_ISA8Code) {
        listIndex = $scope.findSettingCode($scope.ISA7List, $scope.trading_ISA8Code);
        if (listIndex !== -1) {
          return $scope.trading_selectedISA7 = $scope.ISA7List[listIndex];
        }
      }
    };
    $scope.onISA5Changed = function(direction) {
      if (direction === 'local') {
        $scope.local_ISA6Code = $scope.local_selectedISA5.Code;
        $scope.trading_ISA8Code = $scope.local_selectedISA5.Code;
      }
      if (direction === 'trading') {
        $scope.trading_ISA6Code = $scope.trading_selectedISA5.Code;
      }
      return $scope.syncSetting();
    };
    $scope.onISA7Changed = function(direction) {
      if (direction === 'local') {
        $scope.local_ISA8Code = $scope.local_selectedISA7.Code;
        $scope.trading_ISA6Code = $scope.local_selectedISA7.Code;
      }
      if (direction === 'trading') {
        $scope.trading_ISA8Code = $scope.trading_selectedISA7.Code;
      }
      return $scope.syncSetting();
    };
    $scope.isa6_Change = function(direction) {
      if (direction === 'local') {
        $scope.trading_ISA8Value = $scope.local_ISA6Value;
        $scope.trading_ISA8Code = $scope.local_ISA6Code;
      }
      if (direction === 'trading' && !$scope.local_ISA8Value) {
        $scope.local_ISA8Value = $scope.trading_ISA6Value;
        $scope.local_ISA8Code = $scope.trading_ISA6Code;
      }
      return $scope.syncSetting();
    };
    $scope.isa8_Change = function(direction) {
      if (direction === 'local') {
        $scope.trading_ISA6Value = $scope.local_ISA8Value;
        $scope.trading_ISA6Code = $scope.local_ISA8Code;
      }
      if (direction === 'trading' && !$scope.local_ISA6Value) {
        $scope.local_ISA6Value = $scope.trading_ISA8Value;
      }
      return $scope.syncSetting();
    };
    $scope.save = function() {
      var basicTransmissionCount, checkCharArray, checkTransactionListMsg, checkTransactionListNotEmpty, index, isa11Value, useControlStandardsIdAsRepetitionCharacter;
      agreement.checkErrorField($scope.agreementForm);
      if ($scope.agreementForm.$valid) {
        $scope.local_dataElementSeparator_Type = $scope.charTypeList[0];
        $scope.local_componentElementSeparator_Type = $scope.charTypeList[0];
        $scope.local_segmentTerminator_Type = $scope.charTypeList[0];
        $scope.local_replaceChar_Type = $scope.charTypeList[0];
        $scope.charTypeChanged('dataElementSeparator');
        $scope.charTypeChanged('componentElementSeparator');
        $scope.charTypeChanged('segmentTerminator');
        $scope.charTypeChanged('replaceChar');
        checkCharArray = [];
        checkCharArray.push($scope.local_dataElementSeparator_char);
        checkCharArray.push($scope.local_componentElementSeparator_char);
        checkCharArray.push($scope.local_segmentTerminator_char);
        if ($scope.local_replaceSeparatorsInPayload === true && $scope.local_replaceChar_char) {
          checkCharArray.push($scope.local_replaceChar_char);
        }
        if (agreement.checkDuplicateChar(checkCharArray) === true) {
          messager.error('Data element separator, component element separator,segment terminator and replace separators value cannot be repeated.');
          return;
        }
        if ($scope.selectLocalTransmission === null) {
          messager.error('Must choose one outbound transmission setting.');
          return;
        }
        if ($scope.selectTradingTransmission === null) {
          messager.error('Must choose one inbound transmission setting.');
          return;
        }
        if ($scope.localTransactionList.length === 0 && $scope.tradingTransactionList.length === 0) {
          messager.error('Must contain a supported business transaction.');
          return;
        }
        checkTransactionListNotEmpty = true;
        checkTransactionListMsg = 'In the [' + $scope.selectLocalStation.Name + ' -> ' + $scope.selectTradingStation.Name + ']';
        basicTransmissionCount = 0;
        if ($scope.localTransactionList.length > 0) {
          for (index in $scope.localTransactionList) {
            if (!$scope.localTransactionList[index].MapperID) {
              checkTransactionListMsg = checkTransactionListMsg + ' supported business transactions, you must specify the source schema and mapper.';
              checkTransactionListNotEmpty = false;
              break;
            }
            if (!$scope.localTransactionList[index].DestinationTransportProtocol) {
              basicTransmissionCount++;
            }
          }
        }
        if (checkTransactionListNotEmpty === false) {
          messager.error(checkTransactionListMsg);
          return;
        }
        if ($scope.localTransactionList.length > 0 && basicTransmissionCount === 0) {
          messager.error(checkTransactionListMsg + ' supported business transactions, must be a [Destination Transmission] is based on the [Outbound Transmission Setting].');
          return;
        }
        basicTransmissionCount = 0;
        checkTransactionListMsg = 'In the [' + $scope.selectTradingStation.Name + ' -> ' + $scope.selectLocalStation.Name + ']';
        if ($scope.tradingTransactionList.length > 0) {
          for (index in $scope.tradingTransactionList) {
            if (!$scope.tradingTransactionList[index].MapperID) {
              checkTransactionListMsg = checkTransactionListMsg + ' supported business transactions, you must specify the source schema and mapper.';
              checkTransactionListNotEmpty = false;
              break;
            }
            if (!$scope.tradingTransactionList[index].DestinationTransportProtocolSettingsID) {
              checkTransactionListMsg = checkTransactionListMsg + ' Supported business transactions, you must specify the destination transmission.';
              checkTransactionListNotEmpty = false;
              break;
            }
            if (!$scope.tradingTransactionList[index].SourceTransportProtocol) {
              basicTransmissionCount++;
            }
          }
        }
        if (checkTransactionListNotEmpty === false) {
          messager.error(checkTransactionListMsg);
          return;
        }
        if ($scope.tradingTransactionList.length > 0 && basicTransmissionCount === 0) {
          messager.error(checkTransactionListMsg + ' supported business transactions, must be a [Source Transmission] is based on the [Inbound Transmission Setting].');
          return;
        }
        $scope.isSubmit = true;
        agreement.createItem.Agreement = {
          Name: $scope.name,
          Description: $scope.description,
          LocalStationID: $scope.selectLocalStation.Id,
          TradingStationID: $scope.selectTradingStation.Id,
          LocalStationIdentity: $scope.selectLocalStation.Identity,
          TradingStationIdentity: $scope.selectTradingStation.Identity,
          EncodingProtocolType: "X12",
          Status: "Active"
        };
        isa11Value = 'U';
        useControlStandardsIdAsRepetitionCharacter = false;
        if ($scope.isa11Usage === 'R') {
          isa11Value = $scope.local_controlStandardsID_char;
          useControlStandardsIdAsRepetitionCharacter = true;
        }
        agreement.createItem.Agreement.LocalStation = $scope.selectLocalStation;
        agreement.createItem.Agreement.TradingStation = $scope.selectTradingStation;
        if ($scope.localTransactionList) {
          for (index in $scope.localTransactionList) {
            if (!$scope.localTransactionList[index].DestinationTransportProtocolSettingsID) {
              $scope.localTransactionList[index].DestinationTransportProtocolSettingsID = $scope.selectLocalTransmission.Id;
              $scope.localTransactionList[index].DestinationTransportProtocolType = $scope.selectLocalTransmission.ProtocolType;
            }
          }
        }
        if ($scope.tradingTransactionList) {
          for (index in $scope.tradingTransactionList) {
            if (!$scope.tradingTransactionList[index].SourceTransportProtocolSettingsID) {
              $scope.tradingTransactionList[index].SourceTransportProtocolSettingsID = $scope.selectTradingTransmission.Id;
              $scope.tradingTransactionList[index].SourceTransportProtocolType = $scope.selectTradingTransmission.ProtocolType;
            }
          }
        }
        agreement.createItem.Agreement.LocalToTrading = {
          SourceStationID: $scope.selectLocalStation.Id,
          DestinationStationID: $scope.selectTradingStation.Id,
          ProtocolX12: {
            Name: $scope.name + "_AgreementOneway1",
            OrganizationID: common.currentOrganization.Id,
            ProtocolType: "X12",
            Direction: $scope.selectLocalTransmission.Direction,
            SourceStationID: $scope.selectLocalStation.Id,
            DestinationStationID: $scope.selectTradingStation.Id,
            AuthorizationName: $scope.local_selectedISA1.Name,
            AuthorizationQualifier: $scope.local_selectedISA1.Code,
            AuthorizationValue: $scope.local_ISA2Value,
            SecurityName: $scope.local_selectedISA3.Name,
            SecurityQualifier: $scope.local_selectedISA3.Code,
            SecurityValue: $scope.local_ISA4Value,
            SenderIDName: $scope.local_selectedISA5.Name,
            SenderIDQualifier: $scope.local_selectedISA5.Code,
            SenderID: $scope.local_ISA6Value,
            ReceiverIDName: $scope.local_selectedISA7.Name,
            ReceiverIDQualifier: $scope.local_selectedISA7.Code,
            ReceiverID: $scope.local_ISA8Value,
            GroupDateFormat: $scope.dateFormatValue,
            GroupTimeFormat: $scope.timeFormatValue,
            ControlStandardsID: isa11Value.charCodeAt(0),
            UseControlStandardsIdAsRepetitionCharacter: useControlStandardsIdAsRepetitionCharacter,
            ControlVersionNumber: $scope.local_selectedISA12.Code,
            UsageIndicator: $scope.local_selectedISA15.Code,
            CharacterSet: 'UTF8',
            DataElementSeparator: $scope.local_dataElementSeparator_char.charCodeAt(0),
            ComponentSeparator: $scope.local_componentElementSeparator_char.charCodeAt(0),
            SegmentTerminator: $scope.local_segmentTerminator_char.charCodeAt(0),
            SegmentTerminatorSuffix: $scope.local_segmentTerminatorSuffix,
            ReplaceSeparatorsInPayload: $scope.local_replaceSeparatorsInPayload,
            ReplaceChar: $scope.local_replaceChar_char.charCodeAt(0),
            TrailingSeparatorPolicy: $scope.local_selectedTrailingSeparatorPolicy.Code,
            GroupResponsibleAgencyCode: $scope.local_responsibleAgencyCodeValue,
            GroupHeaderVersion: $scope.local_groupHeaderVersionValue
          },
          DestinationTransportProtocolSettingsID: $scope.selectLocalTransmission.Id,
          DestinationTransportProtocolType: $scope.selectLocalTransmission.ProtocolType,
          AgreementTransactionList: $scope.localTransactionList
        };
        if ($scope.selectLocalTransmission.ProtocolType === 'AS2') {
          agreement.createItem.Agreement.LocalToTrading.AS2FromID = $scope.selectLocalTransmission.AS2FromID;
          agreement.createItem.Agreement.LocalToTrading.AS2ToID = $scope.selectLocalTransmission.AS2ToID;
        }
        agreement.createItem.Agreement.TradingToLocal = {
          SourceStationID: $scope.selectTradingStation.Id,
          DestinationStationID: $scope.selectLocalStation.Id,
          ProtocolX12: {
            Name: $scope.name + "_AgreementOneway2",
            OrganizationID: common.currentOrganization.Id,
            ProtocolType: "X12",
            Direction: $scope.selectTradingTransmission.Direction,
            SourceStationID: $scope.selectTradingStation.Id,
            DestinationStationID: $scope.selectLocalStation.Id,
            AuthorizationName: $scope.trading_selectedISA1.Name,
            AuthorizationQualifier: $scope.trading_selectedISA1.Code,
            AuthorizationValue: $scope.trading_ISA2Value,
            SecurityName: $scope.trading_selectedISA3.Name,
            SecurityQualifier: $scope.trading_selectedISA3.Code,
            SecurityValue: $scope.trading_ISA4Value,
            SenderIDName: $scope.trading_selectedISA5.Name,
            SenderIDQualifier: $scope.trading_selectedISA5.Code,
            SenderID: $scope.trading_ISA6Value,
            ReceiverIDName: $scope.trading_selectedISA7.Name,
            ReceiverIDQualifier: $scope.trading_selectedISA7.Code,
            ReceiverID: $scope.trading_ISA8Value,
            UseControlStandardsIdAsRepetitionCharacter: false,
            NeedFunctionalAck: $scope.trading_needFunctionalAck,
            CharacterSet: $scope.trading_selectedCharacterSet.Code,
            CheckDuplicateInterchangeControlNumber: $scope.trading_checkDuplicateInterchangeControlNumber,
            InterchangeDuplicatesValidity: $scope.trading_interchangeDuplicatesValidity,
            CheckDuplicateGroupControlNumber: $scope.trading_checkDuplicateGroupControlNumber,
            CheckDuplicateTransactionSetControlNumber: $scope.trading_checkDuplicateTransactionSetControlNumber,
            TrailingSeparatorPolicy: $scope.trading_selectedTrailingSeparatorPolicy.Code
          },
          SourceTransportProtocolSettingsID: $scope.selectTradingTransmission.Id,
          SourceTransportProtocolType: $scope.selectTradingTransmission.ProtocolType,
          AgreementTransactionList: $scope.tradingTransactionList
        };
        if ($scope.selectTradingTransmission.ProtocolType === 'AS2') {
          agreement.createItem.Agreement.TradingToLocal.AS2FromID = $scope.selectTradingTransmission.AS2FromID;
          agreement.createItem.Agreement.TradingToLocal.AS2ToID = $scope.selectTradingTransmission.AS2ToID;
        }
        $scope.submitMessage = 'Processing...';
        return $scope.submitPromise = $scope.submitAgreementItem(agreement.createItem);
      }
    };
    $scope.submitAgreementItem = function(createItem) {
      var requestItem;
      requestItem = angular.copy(createItem);
      agreement.removeNotOverridesTransmissionWithAPIRequest(requestItem.Agreement);
      return agreementAPI.create(requestItem, function(result) {
        if (result.Succeeded === true) {
          $scope.transferObj.obj = result.AgreementList[0];
          common.navigate('transfer', $scope.transferObj);
        } else {
          common.ShowAPIError('Create Agreement Failed', result);
        }
        return $scope.isSubmit = false;
      }, function(error) {
        $scope.isSubmit = false;
        return common.ShowAPIError('Create Agreement Failed', error.data);
      });
    };
    $scope.currentTransaction = null;
    $scope.localTransactionList = [];
    $scope.tradingTransactionList = [];
    $scope.addTransaction = function(transactionList) {
      return transactionList.push({
        Status: "Active"
      });
    };
    $scope.removeTransaction = function(transactionList, index) {
      return transactionList.splice(index, 1);
    };
    $scope.showPartnerLoading = true;
    $scope.queryStation = function(item) {
      var stationId;
      stationId = null;
      if ($scope.selectPartnerType === 'local') {
        stationId = $scope.getCurrentUserStationId();
      }
      return stationAPI.search({
        status: 'Active',
        partnerid: item.Id,
        id: stationId
      }, function(result) {
        if (result && result.Succeeded) {
          if (result.StationList && result.StationList.length > 0) {
            item.IsShow = true;
            item.StationList = result.StationList;
            if ($scope.selectLocalStation) {
              return $scope.syncStationList(item.StationList);
            }
          }
        } else {
          return common.ShowAPIError('Get station data failed', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get station data failed', error.data);
      });
    };
    $scope.loadStationInfo = function() {
      var index, _results;
      if ($scope.partnerList !== null) {
        _results = [];
        for (index in $scope.partnerList) {
          _results.push($scope.queryStation($scope.partnerList[index]));
        }
        return _results;
      }
    };
    $scope.getCurrentUserStationId = function() {
      if (common.currentUser.Type === common.ownerType.station) {
        return common.currentUser.StationID;
      }
      return null;
    };
    $scope.getCurrentUserPartnerId = function() {
      if (common.currentUser.Type === common.ownerType.partner) {
        return common.currentUser.PartnerID;
      }
      if (common.currentUser.Type === common.ownerType.station) {
        return common.currentUser.PartnerID;
      }
      return null;
    };
    $scope.getPartnerList = function() {
      var partnerId;
      $scope.showPartnerLoading = true;
      partnerId = null;
      if ($scope.selectPartnerType === 'local') {
        partnerId = $scope.getCurrentUserPartnerId();
      }
      return partnerAPI.search({
        status: 'Active',
        type: $scope.selectPartnerType,
        id: partnerId
      }, function(result) {
        $scope.showPartnerLoading = false;
        if (result && result.Succeeded) {
          $scope.partnerList = result.PartnerList;
          return $scope.loadStationInfo();
        } else {
          return common.ShowAPIError('Get partner data failed', result);
        }
      }, function(error) {
        $scope.showPartnerLoading = false;
        return common.ShowAPIError('Get partner data failed', error.data);
      });
    };
    $scope.syncStationList = function(stationList) {
      var index, _results;
      _results = [];
      for (index in stationList) {
        if ($scope.selectPartnerType === 'local' && $scope.selectLocalStation && $scope.selectLocalStation.Id === stationList[index].Id) {
          stationList[index].Selected = true;
        }
        if ($scope.selectPartnerType === 'trading' && $scope.selectTradingStation && $scope.selectTradingStation.Id === stationList[index].Id) {
          _results.push(stationList[index].Selected = true);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.validationSelectedStation = function() {
      var index, index2, valid;
      valid = false;
      for (index in $scope.partnerList) {
        for (index2 in $scope.partnerList[index].StationList) {
          if ($scope.partnerList[index].StationList[index2].Selected === true) {
            valid = true;
          }
        }
      }
      if (valid === false) {
        messager.error('Please choose a station.');
      }
      return valid;
    };
    $scope.setUserSelectedPartner = function() {
      var index, index2;
      for (index in $scope.partnerList) {
        for (index2 in $scope.partnerList[index].StationList) {
          if ($scope.partnerList[index].StationList[index2].Selected === true) {
            if ($scope.selectPartnerType === 'local') {
              $scope.selectLocalPartner = $scope.partnerList[index];
              $scope.selectLocalStation = $scope.partnerList[index].StationList[index2];
            } else {
              $scope.selectTradingPartner = $scope.partnerList[index];
              $scope.selectTradingStation = $scope.partnerList[index].StationList[index2];
            }
          }
        }
      }
      return $scope.$apply();
    };
    $scope.singleSelectPartner = function(station) {
      var index, index2, _results;
      _results = [];
      for (index in $scope.partnerList) {
        _results.push((function() {
          var _results1;
          _results1 = [];
          for (index2 in $scope.partnerList[index].StationList) {
            if ($scope.partnerList[index].StationList[index2].Id === station.Id) {
              continue;
            } else {
              _results1.push($scope.partnerList[index].StationList[index2].Selected = false);
            }
          }
          return _results1;
        })());
      }
      return _results;
    };
    $scope.openPartnerDialog = function(partnerType) {
      $scope.partnerList = null;
      $scope.selectPartnerType = partnerType;
      $scope.partnerModal = true;
      return $scope.promisePartner = $scope.getPartnerList();
    };
    $scope.closePartnerDialog = function() {
      return $scope.partnerModal = false;
    };
    $scope.SelectedPartnerOK = function() {
      if ($scope.validationSelectedStation() === false) {
        return;
      }
      if ($scope.selectLocalStation && $scope.selectLocalStation.Name && $scope.selectTradingStation && $scope.selectTradingStation.Name) {
        $scope.partnerModal = false;
        return common.ConfirmBox("Changing station (" + $scope.selectPartnerType + ") will clear some of settings you've set, and you have set them again, do you wish to continue?", null, function() {
          $scope.clearISAValue();
          $scope.setUserSelectedPartner();
          $scope.selectLocalTransmission = {};
          $scope.localTransactionList = [];
          $scope.selectTradingTransmission = {};
          return $scope.tradingTransactionList = [];
        });
      } else {
        $scope.setUserSelectedPartner();
        return $scope.partnerModal = false;
      }
    };
    $scope.clearISAValue = function() {
      if ($scope.selectPartnerType === 'local') {
        $scope.local_ISA6Code = null;
        $scope.local_ISA6Value = null;
        $scope.trading_ISA8Code = null;
        return $scope.trading_ISA8Value = null;
      } else {
        $scope.local_ISA8Value = null;
        $scope.local_ISA8Code = null;
        $scope.trading_ISA6Code = null;
        return $scope.trading_ISA6Value = null;
      }
    };
    $scope.selectOperationType = null;
    $scope.selectLocalTransmission = null;
    $scope.selectTradingTransmission = null;
    $scope.getTransmissionList = function() {
      return transmissionAPI.search({
        encodingprotocol: false
      }, function(result) {
        if (result && result.Succeeded) {
          $scope.transmissionList = result.ProtocolList;
          $scope.filterTransmissionList();
          return $scope.syncTransmissionList();
        } else {
          return common.ShowAPIError('Get transmission data failed', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get transmission data failed', error.data);
      });
    };
    $scope.SetUserSelectedTransmission = function() {
      var index, selectedTransmission;
      selectedTransmission = null;
      for (index in $scope.transmissionList) {
        if ($scope.transmissionList[index].Selected === true) {
          selectedTransmission = $scope.transmissionList[index];
        }
      }
      if ($scope.selectOperationType === 'local') {
        $scope.selectLocalTransmission = selectedTransmission;
      }
      if ($scope.selectOperationType === 'trading') {
        $scope.selectTradingTransmission = selectedTransmission;
      }
      if ($scope.selectOperationType === 'transaction') {
        if ($scope.selectTransmissionDirection === 'source') {
          $scope.currentTransaction.SourceTransportProtocolType = null;
          $scope.currentTransaction.SourceTransportProtocolSettingsID = null;
          $scope.currentTransaction.SourceTransportProtocol = selectedTransmission;
          if (selectedTransmission) {
            $scope.currentTransaction.SourceTransportProtocolType = selectedTransmission.ProtocolType;
            return $scope.currentTransaction.SourceTransportProtocolSettingsID = selectedTransmission.Id;
          }
        } else {
          $scope.currentTransaction.DestinationTransportProtocol = selectedTransmission;
          $scope.currentTransaction.DestinationTransportProtocolType = null;
          $scope.currentTransaction.DestinationTransportProtocolSettingsID = null;
          if (selectedTransmission) {
            $scope.currentTransaction.DestinationTransportProtocolType = selectedTransmission.ProtocolType;
            return $scope.currentTransaction.DestinationTransportProtocolSettingsID = selectedTransmission.Id;
          }
        }
      }
    };
    $scope.singleSelectTransmission = function(transmission) {
      var index, _results;
      _results = [];
      for (index in $scope.transmissionList) {
        if ($scope.transmissionList[index].Id === transmission.Id) {
          continue;
        } else {
          _results.push($scope.transmissionList[index].Selected = false);
        }
      }
      return _results;
    };
    $scope.syncTransmissionList = function() {
      var index, _results;
      _results = [];
      for (index in $scope.transmissionList) {
        if ($scope.selectOperationType === 'transaction') {
          if ($scope.selectTransmissionDirection === 'source' && $scope.currentTransaction.SourceTransportProtocol) {
            if ($scope.transmissionList[index].Id === $scope.currentTransaction.SourceTransportProtocol.Id) {
              $scope.transmissionList[index].Selected = true;
            }
          }
          if ($scope.selectTransmissionDirection === 'destination' && $scope.currentTransaction.DestinationTransportProtocol) {
            if ($scope.transmissionList[index].Id === $scope.currentTransaction.DestinationTransportProtocol.Id) {
              $scope.transmissionList[index].Selected = true;
            }
          }
          if ($scope.tabType === 'local' && $scope.selectTransmissionDirection === 'destination' && !$scope.currentTransaction.DestinationTransportProtocol && $scope.selectLocalTransmission) {
            if ($scope.transmissionList[index].Id === $scope.selectLocalTransmission.Id) {
              $scope.transmissionList[index].Selected = true;
            }
          }
          if ($scope.tabType === 'trading' && $scope.selectTransmissionDirection === 'source' && !$scope.currentTransaction.SourceTransportProtocol && $scope.selectTradingTransmission) {
            if ($scope.transmissionList[index].Id === $scope.selectTradingTransmission.Id) {
              _results.push($scope.transmissionList[index].Selected = true);
            } else {
              _results.push(void 0);
            }
          } else {
            _results.push(void 0);
          }
        } else {
          if ($scope.selectOperationType === 'local' && $scope.selectLocalTransmission) {
            if ($scope.transmissionList[index].Id === $scope.selectLocalTransmission.Id) {
              $scope.transmissionList[index].Selected = true;
            }
          }
          if ($scope.selectOperationType === 'trading' && $scope.selectTradingTransmission) {
            if ($scope.transmissionList[index].Id === $scope.selectTradingTransmission.Id) {
              _results.push($scope.transmissionList[index].Selected = true);
            } else {
              _results.push(void 0);
            }
          } else {
            _results.push(void 0);
          }
        }
      }
      return _results;
    };
    $scope.filterTransmissionList = function() {
      var index, _results;
      _results = [];
      for (index in $scope.transmissionList) {
        $scope.transmissionList[index].showSelect = true;
        if ($scope.selectOperationType === 'transaction') {
          if ($scope.tabType === 'local' && $scope.selectTransmissionDirection === 'destination') {
            $scope.filterTransactionTransmissionList($scope.transmissionList[index], 'Sending', $scope.currentTransaction.SourceTransportProtocol, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
          }
          if ($scope.tabType === 'trading' && $scope.selectTransmissionDirection === 'source') {
            $scope.filterTransactionTransmissionList($scope.transmissionList[index], 'Receiving', $scope.currentTransaction.DestinationTransportProtocol, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
          }
          if ($scope.tabType === 'trading' && $scope.selectTransmissionDirection === 'destination') {
            $scope.filterTransactionTransmissionList($scope.transmissionList[index], 'Sending', $scope.currentTransaction.SourceTransportProtocol, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
          }
          $scope.filterTransactionTransmissionList2($scope.transmissionList[index], $scope.tabType, $scope.selectTransmissionDirection);
        } else {
          if ($scope.selectOperationType === 'local') {
            $scope.filterTransmissionListBelongTo($scope.transmissionList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
            if ($scope.transmissionList[index].Direction !== 'Sending') {
              $scope.transmissionList[index].showSelect = false;
            }
            $scope.filterTransactionTransmissionList2($scope.transmissionList[index], $scope.selectOperationType, 'destination');
          }
          if ($scope.selectOperationType === 'trading') {
            $scope.filterTransmissionListBelongTo($scope.transmissionList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
            if ($scope.transmissionList[index].Direction !== 'Receiving') {
              $scope.transmissionList[index].showSelect = false;
            }
            $scope.filterTransactionTransmissionList2($scope.transmissionList[index], $scope.selectOperationType, 'source');
          }
        }
        _results.push($scope.transmissionList = $filter('orderBy')($scope.transmissionList, 'ownerSort'));
      }
      return _results;
    };
    $scope.filterTransactionTransmissionList = function(transmission, direction, compareTransmission, partnerId, stationId) {
      $scope.filterTransmissionListBelongTo(transmission, true, partnerId, stationId);
      if (transmission.Direction !== direction) {
        return transmission.showSelect = false;
      }
    };
    $scope.filterTransactionTransmissionList2 = function(transmission, tabType, direction) {
      if (tabType === 'local') {
        if ($scope.selectOperationType === 'local') {
          if (direction === 'destination' && transmission.ProtocolType === 'MQ') {
            transmission.showSelect = false;
          }
        } else {
          if (direction === 'source' && transmission.ProtocolType !== 'MQ') {
            transmission.showSelect = false;
          }
          if (direction === 'destination' && (transmission.ProtocolType === 'MQ' || transmission.ProtocolType === 'AS2')) {
            transmission.showSelect = false;
          }
        }
      }
      if (tabType === 'trading') {
        if ($scope.selectOperationType === 'trading') {
          if (direction === 'source' && transmission.ProtocolType === 'MQ') {
            return transmission.showSelect = false;
          }
        } else {
          if (direction === 'source' && (transmission.ProtocolType === 'MQ' || transmission.ProtocolType === 'AS2')) {
            transmission.showSelect = false;
          }
          if (direction === 'destination' && transmission.ProtocolType !== 'MQ') {
            return transmission.showSelect = false;
          }
        }
      }
    };
    $scope.filterTransmissionListBelongTo = function(transmission, needFilter, partnerId, stationId) {
      if (transmission.OwnerType === common.ownerType.organization) {
        transmission.showSelect = true;
        if (common.currentUser.Type === common.ownerType.partner || common.currentUser.Type === common.ownerType.station) {
          transmission.ownerSort = 3;
        } else {
          transmission.ownerSort = 1;
        }
      }
      if (transmission.OwnerType === common.ownerType.partner) {
        transmission.ownerSort = 2;
        if (needFilter && partnerId !== transmission.OwnerID) {
          transmission.showSelect = false;
        }
      }
      if (transmission.OwnerType === common.ownerType.station) {
        if (common.currentUser.Type === common.ownerType.partner || common.currentUser.Type === common.ownerType.station) {
          transmission.ownerSort = 1;
        } else {
          transmission.ownerSort = 3;
        }
        if (needFilter && stationId !== transmission.OwnerID) {
          return transmission.showSelect = false;
        }
      }
    };
    $scope.openTransmissionDialog = function(operationType) {
      $scope.isBasicSelect = true;
      $scope.tabType = operationType;
      $scope.transmissionList = null;
      $scope.selectOperationType = operationType;
      $scope.transmissionModal = true;
      return $scope.promiseTransmission = $scope.getTransmissionList();
    };
    $scope.openTransmissionDialogByTransaction = function(transactionList, index, direction, tabType) {
      $scope.isBasicSelect = false;
      $scope.tabType = tabType;
      $scope.transmissionList = null;
      $scope.selectOperationType = 'transaction';
      $scope.selectTransmissionDirection = direction;
      $scope.currentTransaction = transactionList[index];
      $scope.transmissionModal = true;
      return $scope.promiseTransmission = $scope.getTransmissionList();
    };
    $scope.closeTransmissionDialog = function() {
      return $scope.transmissionModal = false;
    };
    $scope.isBasicSelect = true;
    $scope.SelectedTransmissionOK = function() {
      if (($scope.isBasicSelect = true)) {
        if ($scope.tabType === 'local' && $scope.selectLocalTransmission) {
          $scope.oldBasicTransmissionID = angular.copy($scope.selectLocalTransmission.Id);
        }
        if ($scope.tabType === 'trading' && $scope.selectTradingTransmission) {
          $scope.oldBasicTransmissionID = angular.copy($scope.selectTradingTransmission.Id);
        }
      }
      $scope.SetUserSelectedTransmission();
      $scope.transmissionModal = false;
      if ($scope.selectOperationType !== 'transaction' && $scope.tabType === 'local' && $scope.selectLocalTransmission && $scope.selectLocalTransmission.ProtocolType && $scope.selectLocalTransmission.ProtocolType === 'AS2') {
        transmission.getData($scope.selectLocalTransmission, $scope.tabType);
      }
      if ($scope.selectOperationType !== 'transaction' && $scope.tabType === 'trading' && $scope.selectTradingTransmission && $scope.selectTradingTransmission.ProtocolType && $scope.selectTradingTransmission.ProtocolType === 'AS2') {
        transmission.getData($scope.selectTradingTransmission, $scope.tabType);
      }
      if ($scope.isBasicSelect) {
        if ($scope.tabType === 'local') {
          return agreement.clearNotOverridesTransmission($scope.tabType, $scope.oldBasicTransmissionID, $scope.localTransactionList);
        } else {
          return agreement.clearNotOverridesTransmission($scope.tabType, $scope.oldBasicTransmissionID, $scope.TradingTransactionList);
        }
      }
    };
    $scope.syncSchemaList = function() {
      var index, _results;
      _results = [];
      for (index in $scope.schemaList) {
        $scope.schemaList[index].ViewTransactionType = customSettingCache.GetSettingName(customSettingCache.CategoryName.TransactionType, $scope.schemaList[index].TransactionType);
        if ($scope.currentTransaction.Schema && $scope.currentTransaction.Schema && $scope.schemaList[index].Id === $scope.currentTransaction.Schema.Id) {
          _results.push($scope.schemaList[index].Selected = true);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.filterSchema = function(tabType) {
      var index;
      for (index in $scope.schemaList) {
        $scope.schemaList[index].showSelect = true;
        if (tabType === 'local') {
          $scope.filterTransmissionListBelongTo($scope.schemaList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
        }
        if (tabType === 'trading') {
          $scope.filterTransmissionListBelongTo($scope.schemaList[index], true, $scope.selectLocalPartner.Id, $scope.selectLocalStation.Id);
        }
        if (!$scope.schemaList[index].SchemaType) {
          $scope.schemaList[index].showSelect = false;
        }
        agreement.hideHasUsedSchema($scope.usedSchemaTypes, $scope.schemaList);
      }
      $scope.syncSchemaList();
      return $scope.schemaList = $filter('orderBy')($scope.schemaList, 'ownerSort');
    };
    $scope.getSchemaList = function(tabType) {
      return schemaAPI.search({
        SchemaType: tabType
      }, function(result) {
        if (result && result.Succeeded) {
          $scope.schemaList = result.SchemaList;
          $scope.filterSchema(tabType);
          return $scope.getCustomSetting();
        } else {
          return common.ShowAPIError('Get schema data failed', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get schema data failed', error.data);
      });
    };
    $scope.getCustomSetting = function() {
      if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
        return customSettingCache.RefreshData($scope.syncSchemaList, common.currentOrganization.Id);
      } else {
        return $scope.syncSchemaList();
      }
    };
    $scope.SetUserSelectedSchema = function() {
      var index, selectedSchema;
      selectedSchema = null;
      for (index in $scope.schemaList) {
        if ($scope.schemaList[index].Selected === true) {
          selectedSchema = $scope.schemaList[index];
        }
      }
      $scope.currentTransaction.Schema = null;
      $scope.currentTransaction.SourceSchemaID = null;
      if (selectedSchema) {
        $scope.currentTransaction.Schema = selectedSchema;
        return $scope.currentTransaction.SourceSchemaID = selectedSchema.Id;
      }
    };
    $scope.singleSelectSchema = function(schema) {
      var index, _results;
      _results = [];
      for (index in $scope.schemaList) {
        if ($scope.schemaList[index].Id === schema.Id) {
          continue;
        } else {
          _results.push($scope.schemaList[index].Selected = false);
        }
      }
      return _results;
    };
    $scope.usedSchemaTypes = [];
    $scope.openSchemaDialog = function(transactionList, index, tabType) {
      $scope.tabType = tabType;
      $scope.usedSchemaTypes = agreement.loadUsedSchemaTypes(transactionList, transactionList[index]);
      $scope.currentTransaction = transactionList[index];
      $scope.schemaList = null;
      $scope.schemaModal = true;
      return $scope.promiseSchema = $scope.getSchemaList(tabType);
    };
    $scope.closeSchemaDialog = function() {
      return $scope.schemaModal = false;
    };
    $scope.SelectedSchemaOK = function() {
      $scope.SetUserSelectedSchema();
      return $scope.schemaModal = false;
    };
    $scope.syncMapperList = function() {
      var index, _results;
      if ($scope.currentTransaction.Mapper) {
        _results = [];
        for (index in $scope.mapperList) {
          if ($scope.mapperList[index].Id === $scope.currentTransaction.Mapper.Id) {
            _results.push($scope.mapperList[index].Selected = true);
          } else {
            _results.push(void 0);
          }
        }
        return _results;
      }
    };
    $scope.getMapperList = function() {
      if (!$scope.currentTransaction.SourceSchemaID) {
        return messager.error('Please select souce schema.');
      } else {
        return mapperAPI.search({
          schema: true,
          sourceschemaid: $scope.currentTransaction.SourceSchemaID
        }, function(result) {
          var index;
          if (result && result.Succeeded) {
            debugger;
            $scope.mapperList = result.MapperList;
            for (index in $scope.mapperList) {
              $scope.filterTransmissionListBelongTo($scope.mapperList[index], false, null, null);
            }
            $scope.mapperList = $filter('orderBy')($scope.mapperList, 'ownerSort');
            return $scope.syncMapperList();
          } else {
            return common.ShowAPIError('Get mapper data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get mapper data failed', error.data);
        });
      }
    };
    $scope.SetUserSelectedMapper = function() {
      var index, selectedMapper;
      selectedMapper = null;
      for (index in $scope.mapperList) {
        if ($scope.mapperList[index].Selected === true) {
          selectedMapper = $scope.mapperList[index];
        }
      }
      $scope.currentTransaction.Mapper = null;
      $scope.currentTransaction.MapperID = null;
      if (selectedMapper) {
        $scope.currentTransaction.Mapper = selectedMapper;
        $scope.currentTransaction.MapperID = selectedMapper.Id;
        return $scope.currentTransaction.Mapper.DestinationSchema.TransactionType = selectedMapper.DestinationSchema.TransactionType;
      }
    };
    $scope.singleSelectMapper = function(mapper) {
      var index, _results;
      _results = [];
      for (index in $scope.mapperList) {
        if ($scope.mapperList[index].Id === mapper.Id) {
          continue;
        } else {
          _results.push($scope.mapperList[index].Selected = false);
        }
      }
      return _results;
    };
    $scope.openMapperDialog = function(transactionList, index, tabType) {
      $scope.tabType = tabType;
      $scope.currentTransaction = transactionList[index];
      $scope.mapperList = null;
      $scope.mapperModal = true;
      return $scope.promiseMapper = $scope.getMapperList();
    };
    $scope.closeMapperDialog = function() {
      return $scope.mapperModal = false;
    };
    $scope.SelectedMapperOK = function() {
      $scope.SetUserSelectedMapper();
      if ($scope.currentTransaction.X12EnvelopesOverrides) {
        if ($scope.tabType === 'local') {
          if ($scope.currentTransaction.Mapper.DestinationSchema) {
            $scope.currentTransaction.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.DestinationSchema.Namespace;
          }
        }
        if ($scope.tabType === 'trading') {
          if ($scope.currentTransaction.Mapper.SourceSchema) {
            $scope.currentTransaction.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.SourceSchema.Namespace;
          }
        }
      }
      return $scope.mapperModal = false;
    };
    $scope.initPolicy = function() {
      $scope.Policy = {};
      $scope.Policy.MaxRetryCount = 3;
      $scope.Policy.RetryInterval = 300;
      return $scope.Policy.AutoRetryEnabled = false;
    };
    $scope.openX12GroupDialog = function(transactionList, index, operationType) {
      $scope.OverrideX12Group_OperationType = operationType;
      $scope.currentTransaction = transactionList[index];
      $scope.initPolicy();
      $scope.$watch("Policy.AutoRetryEnabled", (function() {
        if ($scope.Policy.AutoRetryEnabled === false) {
          $scope.Policy.MaxRetryCount = 3;
          return $scope.Policy.RetryInterval = 300;
        }
      }), true);
      if (!$scope.currentTransaction.X12EnvelopesOverrides) {
        $scope.initX12EnvelopesOverrides();
        if (operationType === 'local') {
          $scope.X12EnvelopesOverrides.SenderID = $scope.local_ISA6Value;
          $scope.X12EnvelopesOverrides.ReceiverID = $scope.local_ISA8Value;
          $scope.X12EnvelopesOverrides.DateFormat = $scope.dateFormatValue;
          $scope.X12EnvelopesOverrides.TimeFormat = $scope.timeFormatValue;
          if ($scope.local_selectedISA12) {
            $scope.X12EnvelopesOverrides.ControlVersionNumber = $scope.local_selectedISA12.Code;
          }
          if ($scope.currentTransaction.Mapper.DestinationSchema && $scope.currentTransaction.Mapper.DestinationSchema.TransactionType) {
            $scope.X12EnvelopesOverrides.FunctionalIdentifierCode = $scope.currentTransaction.Mapper.DestinationSchema.TransactionType;
          }
          if ($scope.currentTransaction.Mapper.DestinationSchema) {
            $scope.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.DestinationSchema.Namespace;
          }
        } else {
          $scope.X12EnvelopesOverrides.SenderID = $scope.trading_ISA6Value;
          $scope.X12EnvelopesOverrides.ReceiverID = $scope.trading_ISA8Value;
          if ($scope.currentTransaction.Mapper.SourceSchema) {
            $scope.X12EnvelopesOverrides.TragetNamespace = $scope.currentTransaction.Mapper.SourceSchema.Namespace;
          }
        }
      } else {
        $scope.X12EnvelopesOverrides = angular.copy($scope.currentTransaction.X12EnvelopesOverrides);
      }
      if ($scope.currentTransaction.Policy) {
        $scope.Policy = angular.copy($scope.currentTransaction.Policy);
      }
      return $scope.x12GroupModal = true;
    };
    $scope.closeX12GroupDialog = function() {
      return $scope.x12GroupModal = false;
    };
    return $scope.SelectedX12GroupOK = function() {
      if ($scope.x12GroupForm.$valid) {
        if ($scope.Policy) {
          $scope.currentTransaction.Policy = angular.copy($scope.Policy);
        }
        $scope.currentTransaction.X12EnvelopesOverrides = angular.copy($scope.X12EnvelopesOverrides);
        $scope.currentTransaction.X12EnvelopesOverrides.TransactionSetType = $filter('filter')($scope.functionalIdentifierCodeList, {
          Code: $scope.currentTransaction.X12EnvelopesOverrides.FunctionalIdentifierCode
        })[0].Value;
        return $scope.x12GroupModal = false;
      }
    };
  }
]);
