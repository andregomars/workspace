﻿(function() {

  angular.module('eaas-agreement', ['ngRoute', 'pascalprecht.translate']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/agreement", {
        templateUrl: "/modules/eaas/app/agreement/agreement.tpl.html",
        controller: 'EaaSAgreementCtrl'
      });
    }
  ]).controller('EaaSAgreementCtrl', [
    "$scope", "messager", "common", "agreement", "agreementAPI", "stationAPI", function($scope, messager, common, agreement, agreementAPI, stationAPI) {
      var pageName;
      $scope.common = common;
      $scope.query = angular.copy(agreement.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Name',
            value: 'name'
          }, {
            text: 'Description',
            value: 'description'
          }
        ];
        $scope.query.queryField = 'name';
        $scope.query.status = null;
        common.InitQueryFields($scope.query);
      }
      $scope.query.pageSize = common.getPageSize(420, 147);
      $scope.owner = {
        Id: common.currentOrganization.Id,
        Name: common.currentOrganization.Name,
        Type: 'Organization'
      };
      pageName = common.currentRoutePath();
      $scope.initOwnerInfo = function() {
        if (common.current.link[pageName].pageParameter.Station.PartnerType === 'Local') {
          $scope.query.localStationID = common.current.link[pageName].pageParameter.Station.Id;
        } else {
          $scope.query.tradingStationID = common.current.link[pageName].pageParameter.Station.Id;
        }
        $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
        $scope.owner.Name = common.current.link[pageName].pageParameter.Station.Name;
        return $scope.owner.Type = common.current.link[pageName].pageParameter.Station.PartnerType + ' Station';
      };
      $scope.initPageParameter = function() {
        if (common.current.link[pageName].pageParameter.Status) {
          $scope.query.status = common.current.link[pageName].pageParameter.Status;
        }
        if (common.current.link[pageName].pageParameter.Station) {
          return $scope.initOwnerInfo();
        }
      };
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        $scope.initPageParameter();
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        $scope.query = agreement.query;
        if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
          $scope.initPageParameter();
        }
      } else {
        common.current.link[pageName] = null;
        $scope.query.localStationID = null;
        $scope.query.tradingStationID = null;
        agreement.reset();
      }
      $scope.add = function() {
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station) {
          return common.navigate('agreement/create', {
            Station: common.current.link[pageName].pageParameter.Station
          });
        } else {
          return common.navigate('agreement/create');
        }
      };
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.search = function() {
        var requestItem, response;
        $scope.message = 'Loading...';
        agreement.query = $scope.query;
        requestItem = angular.copy($scope.query);
        agreement.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return response = agreementAPI.search(requestItem, function() {
          if (response && response.Succeeded) {
            $scope.query.totalItems = response.TotalRecordCount;
            $scope.data = response.AgreementList;
            agreement.data = response.AgreementList;
            return $scope.loadStationInfo();
          } else {
            return common.ShowAPIError('Get agreement data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get agreement data failed.', error.data);
        });
      };
      $scope.queryStation = function(agm) {
        var localResponse, tradingResponse;
        localResponse = stationAPI.search({
          id: agm.LocalStationID
        }, function() {
          if (localResponse && localResponse.Succeeded && localResponse.StationList !== null) {
            return agm.LocalStation = localResponse.StationList[0];
          }
        });
        return tradingResponse = stationAPI.search({
          id: agm.TradingStationID
        }, function() {
          if (tradingResponse && tradingResponse.Succeeded && tradingResponse.StationList !== null) {
            return agm.TradingStation = tradingResponse.StationList[0];
          }
        });
      };
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      $scope.loadStationInfo = function() {
        var index, _results;
        if ($scope.data !== null) {
          _results = [];
          for (index in $scope.data) {
            _results.push($scope.queryStation($scope.data[index]));
          }
          return _results;
        }
      };
      $scope.filter = function(type) {
        $scope.filterType = type;
        if (type === 'all') {
          $scope.query.status = null;
        } else {
          $scope.query.status = type;
        }
        return $scope.advancedSearch();
      };
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.filterType = 'all';
      if ($scope.query.status) {
        $scope.filterType = $scope.query.status;
      }
      $scope.promise = $scope.search();
      $scope.remove = function(entity) {
        return common.ConfirmBox("Do you want to remove agreement \"" + entity.Name + "\" ?", "If you remove an agreement, the EaaS system will stop processing the incoming and outgoing EDI interchanges related to this agreement immediately.", function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.removeAgreement(entity);
        });
      };
      $scope.removeAgreement = function(entity) {
        var response;
        return response = agreementAPI.remove({
          id: entity.Id
        }, function() {
          if (response && response.Succeeded) {
            messager.success('Agreement \"' + entity.Name + '\" has been removed successfully.');
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError('Agreement \"' + entity.Name + '\" has been removed failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Agreement \"' + entity.Name + '\" has been removed failed.', error.data);
        });
      };
      $scope.updateStatus = function(entity) {
        var opStatus, requestEntity, toolTip;
        requestEntity = {};
        if (entity.Status === "Active") {
          requestEntity.action = "disable";
        } else {
          requestEntity.action = "enable";
        }
        requestEntity.id = entity.Id;
        opStatus = (entity.Status === "Active" ? "deactivate" : "active");
        toolTip = (entity.Status === "Active" ? "If the agreement is deactivated, the EaaS system will stop processing the incoming and outgoing EDI interchanges related to this agreement immediately." : "If the agreement is activated, EaaS system will start to process the incoming and outgoing EDI interchanges between the station of the local and trading partner associated with this agreement.");
        return common.ConfirmBox("Do you want to " + opStatus + " the agreement \"" + entity.Name + "\"?", toolTip, function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.changeAgreementStatus(requestEntity, entity, opStatus);
        });
      };
      $scope.changeAgreementStatus = function(requestEntity, entity, opStatus) {
        var response;
        return response = agreementAPI.updateStatus(requestEntity, function() {
          var toolStatus;
          toolStatus = (opStatus === "active" ? "activated" : "deactivated");
          if (response && response.Succeeded) {
            messager.success("Agreement \"" + entity.Name + "\" has been " + toolStatus + " successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError("Agreement \"" + entity.Name + "\" has been " + toolStatus + " failed.", response);
          }
        }, function(error) {
          return common.ShowAPIError("Agreement \"" + entity.Name + "\" has been " + toolStatus + " failed.", error.data);
        });
      };
      return $scope.edit = function(item) {
        agreement.editItem = item;
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station) {
          return common.navigate('agreement/edit', {
            Station: common.current.link[pageName].pageParameter.Station
          });
        } else {
          return common.navigate('agreement/edit');
        }
      };
    }
  ]);

}).call(this);
