(function() {
  angular.module('system-guide-form-elements-data-range-picker', []);

  angular.module('eaas-system', ['eaas-home', 'eaas-partner', 'eaas-create-partner', 'eaas-edit-partner', 'eaas-schema', 'eaas-create-schema', 'eaas-edit-schema', 'eaas-mapper', 'eaas-create-mapper', 'eaas-edit-mapper', 'eaas-certificate', 'eaas-upload-certificate', 'eaas-transmission', 'eaas-create-transmission', 'eaas-edit-transmission', 'eaas-agreement', 'eaas-create-agreement', 'eaas-edit-agreement', 'eaas-account', 'eaas-create-account', 'eaas-edit-account', 'eaas-station', 'eaas-create-station', 'eaas-edit-station', 'eaas-organization', 'eaas-view-organ', 'eaas-feature', 'edi-eaas-actionLog', 'eaas-statistics', 'eaas-message', 'eaas-message-v2', 'eaas-view-message', 'eaas-view-message-v2', 'ngAnimate', 'cgBusy', 'eaas-view-schema', 'eaas-view-mapper', 'eaas-view-certificate', 'eaas-view-account', 'eaas-view-partner', 'eaas-view-station', 'eaas-view-transmission', 'eaas-view-agreement', 'eaas-transfer', 'eaas-create-organization', 'eaas-edit-organization', 'eaas-view-versionhistory']);

}).call(this);
