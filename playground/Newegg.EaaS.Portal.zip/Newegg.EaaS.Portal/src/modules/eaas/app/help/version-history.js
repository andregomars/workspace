(function() {

  angular.module('eaas-view-versionhistory', ['ngRoute', 'ngSanitize']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/version-history", {
        templateUrl: "/modules/eaas/app/help/version-history.tpl.html",
        controller: 'EaaSViewVersionHistoryCtrl'
      });
    }
  ]).controller('EaaSViewVersionHistoryCtrl', [
    "$scope", "$http", "$window", "$filter", "common", 'versionHistoryAPI', '$q', '$sce', function($scope, $http, $window, $filter, common, versionHistoryAPI, $q, $sce) {
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.deliberatelyTrustDangerousSnippet = function(snippet) {
        return $sce.trustAsHtml(snippet);
      };
      $scope.searchVersionHistory = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        versionHistoryAPI.search({}, function(result) {
          if (result && result.Succeeded) {
            $scope.versionHistoryList = result.VersionHistoryList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get version history data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get version history data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      return $scope.searchVersionHistory();
    }
  ]);

}).call(this);
