﻿
angular.module('eaas-create-mapper', ['ngRoute', 'eaas-api-schema', 'eaas-api-mapper', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/mapper/create", {
      templateUrl: "/modules/eaas/app/mapper/create-mapper.tpl.html",
      controller: 'EaaSCreateMapperCtrl'
    });
  }
]).controller('EaaSCreateMapperCtrl', [
  "$scope", "progress", 'common', 'schemaAPI', 'mapper', 'mapperAPI', 'messager', '$fileUploader', 'partnerAPI', 'stationAPI', 'customSettingCache', function($scope, progress, common, schemaAPI, mapper, mapperAPI, messager, $fileUploader, partnerAPI, stationAPI, customSettingCache) {
    var pageName, uploader;
    $scope.transferObj = {
      isSucceed: true,
      action: 'create',
      objName: 'mapper',
      title: 'Mapper has been created successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.newMapper = {
      Mapper: {},
      RequestInfo: {}
    };
    $scope.mapperFile = {};
    $scope.uploadValid = false;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization',
      SearchType: 'Organization'
    };
    pageName = common.currentRoutePath();
    $scope.initStationOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link.station.Name;
      $scope.owner.Type = common.current.link.station.PartnerType + ' Station';
      return $scope.owner.SearchType = 'Station';
    };
    $scope.initPartnerOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
      $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
      return $scope.owner.SearchType = 'Partner';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        $scope.initStationOwnerInfo();
      } else {
        if (common.current.link[pageName].pageParameter.Partner) {
          $scope.initPartnerOwnerInfo();
        }
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      }
    }
    $scope.enableChooseStation = true;
    $scope.enableChoosePartner = true;
    $scope.belongId = null;
    $scope.belongType = null;
    $scope.loadBelongTo = false;
    $scope.setOwnerByUerRole = true;
    $scope.fromPageNavigate = function() {
      if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner && common.current.link[pageName].pageParameter.Station) {
        $scope.belongType = 'Station';
        $scope.belongId = common.current.link[pageName].pageParameter.Station.Id;
        $scope.autoSetOwnerInfo = false;
        $scope.setOwnerByUerRole = false;
        $scope.loadBelongTo = true;
        $scope.enableChoosePartner = false;
        return $scope.enableChooseStation = false;
      } else {
        if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          $scope.belongType = 'Partner';
          $scope.belongId = common.current.link[pageName].pageParameter.Partner.Id;
          $scope.autoSetOwnerInfo = false;
          $scope.setOwnerByUerRole = false;
          $scope.loadBelongTo = true;
          return $scope.enableChoosePartner = false;
        } else {
          $scope.autoSetOwnerInfo = true;
          return $scope.loadBelongTo = true;
        }
      }
    };
    $scope.promise = $scope.fromPageNavigate();
    $scope.getUserSelectedSchema = function() {
      var index;
      for (index in $scope.schemaList) {
        if ($scope.schemaList[index].selected === true) {
          return $scope.schemaList[index];
        }
      }
    };
    $scope.getSelectedSchemaById = function(id) {
      var index;
      for (index in $scope.schemaList) {
        if ($scope.schemaList[index].Id === id) {
          return $scope.schemaList[index];
        }
      }
    };
    $scope.initSchemaData = function() {
      var index;
      for (index in $scope.schemaList) {
        $scope.schemaList[index].selected = false;
        $scope.schemaList[index].show = true;
        $scope.schemaList[index].ViewTransactionType = customSettingCache.GetSettingName(customSettingCache.CategoryName.TransactionType, $scope.schemaList[index].TransactionType);
        if ($scope.schemaList[index].OwnerName && $scope.schemaList[index].OwnerName === 'NotExist') {
          $scope.schemaList[index].show = false;
        }
      }
      return $scope.syncSchema();
    };
    $scope.singleSelect = function(schema) {
      var index, _results;
      _results = [];
      for (index in $scope.schemaList) {
        if ($scope.schemaList[index].Id === schema.Id) {
          continue;
        } else {
          _results.push($scope.schemaList[index].selected = false);
        }
      }
      return _results;
    };
    $scope.filterSchemaData = function(schemaType, transactionType, schema) {
      var index, _results;
      _results = [];
      for (index in $scope.schemaList) {
        $scope.schemaList[index].show = false;
        if ($scope.schemaList[index].Id === schema.Id) {
          $scope.schemaList[index].show = false;
        }
        if ($scope.schemaList[index].SchemaType !== schemaType && $scope.schemaList[index].TransactionType === transactionType) {
          $scope.schemaList[index].show = true;
        }
        if ($scope.schemaList[index].OwnerName && $scope.schemaList[index].OwnerName === 'NotExist') {
          _results.push($scope.schemaList[index].show = false);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.syncSchema = function() {
      var schema;
      schema = null;
      if ($scope.operationSchemaType === 'Source') {
        if ($scope.newMapper.Mapper && $scope.newMapper.Mapper.SourceSchema) {
          schema = $scope.getSelectedSchemaById($scope.newMapper.Mapper.SourceSchema.Id);
          schema.selected = true;
        }
        if ($scope.newMapper.Mapper && $scope.newMapper.Mapper.DestinationSchema) {
          $scope.filterSchemaData($scope.newMapper.Mapper.DestinationSchema.SchemaType, $scope.newMapper.Mapper.DestinationSchema.TransactionType, $scope.newMapper.Mapper.DestinationSchema);
        }
      }
      if ($scope.operationSchemaType !== 'Source') {
        if ($scope.newMapper.Mapper && $scope.newMapper.Mapper.DestinationSchema) {
          schema = $scope.getSelectedSchemaById($scope.newMapper.Mapper.DestinationSchema.Id);
          schema.selected = true;
        }
        if ($scope.newMapper.Mapper && $scope.newMapper.Mapper.SourceSchema) {
          return $scope.filterSchemaData($scope.newMapper.Mapper.SourceSchema.SchemaType, $scope.newMapper.Mapper.SourceSchema.TransactionType, $scope.newMapper.Mapper.SourceSchema);
        }
      }
    };
    common.resourceObtainer.SetUser(common.currentUser);
    $scope.onResourceLoadComplete = function(result) {
      $scope.schemaList = common.sortResourceList(result, $scope.owner.SearchType);
      return $scope.promiseSchema = $scope.getCustomSetting();
    };
    $scope.getSchemaData = function() {
      if ($scope.schemaList && $scope.schemaList.length > 0) {
        $scope.initSchemaData();
        return $scope.syncSchema();
      } else {
        return schemaAPI.search({}, function(response) {
          if (response && response.Succeeded) {
            if ($scope.owner.SearchType !== 'Organization') {
              $scope.filterType = $scope.owner.SearchType;
              $scope.filterId = $scope.owner.Id;
            } else {
              if (common.currentUser.Type === common.userRole.stationUser) {
                $scope.filterType = common.userRole.stationUser;
                $scope.filterId = common.currentUser.StationID;
              } else if (common.currentUser.Type === common.userRole.partnerUser) {
                $scope.filterType = common.userRole.partnerUser;
                $scope.filterId = common.currentUser.PartnerID;
              } else {
                $scope.filterType = null;
                $scope.filterId = null;
              }
            }
            $scope.schemaList = common.sortResourceList(response.SchemaList, $scope.owner.SearchType);
            if ($scope.filterType === common.userRole.stationUser) {
              return $scope.promiseSchema = common.GetStationInfo($scope.filterId, null, $scope.onLoadStationComplete);
            } else if ($scope.filterType === common.userRole.partnerUser) {
              return $scope.promiseSchema = common.GetPartnerInfo($scope.filterId, $scope.onLoadPartnerComplete);
            } else {
              return $scope.promiseSchema = $scope.getCustomSetting();
            }
          } else {
            return common.ShowAPIError('Get schema data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get schema data failed', error.data);
        });
      }
    };
    $scope.onLoadPartnerComplete = function(partnerList) {
      if (partnerList.length > 0) {
        $scope.filterPartnerId = partnerList[0].Id;
        return $scope.promiseSchema = common.GetStationInfo(null, $scope.filterPartnerId, $scope.onLoadStationComplete);
      } else {
        return $scope.promiseSchema = $scope.getCustomSetting();
      }
    };
    $scope.onLoadStationComplete = function(stationList) {
      if (stationList.length > 0) {
        $scope.filterStationList = stationList;
        $scope.filterPartnerId = stationList[0].PartnerID;
        $scope.filterSchemaList();
        return $scope.promiseSchema = $scope.getCustomSetting();
      } else {
        return $scope.promiseSchema = $scope.getCustomSetting();
      }
    };
    $scope.filterSchemaList = function() {
      var filterList, index, index2, schema;
      filterList = [];
      for (index in $scope.schemaList) {
        schema = $scope.schemaList[index];
        if (schema.OwnerType === 'Organization') {
          filterList.push(schema);
        } else if (schema.OwnerType === 'Partner') {
          if ($scope.filterType && schema.OwnerID === $scope.filterPartnerId) {
            filterList.push(schema);
          }
        } else if (schema.OwnerType === 'Station') {
          if ($scope.filterType) {
            for (index2 in $scope.filterStationList) {
              if ($scope.filterStationList[index2].Id === schema.OwnerID) {
                filterList.push(schema);
              }
            }
          }
        }
      }
      return $scope.schemaList = common.sortResourceList(filterList, $scope.filterType);
    };
    $scope.getCustomSetting = function() {
      if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
        return customSettingCache.RefreshData($scope.initSchemaData, common.currentOrganization.Id);
      } else {
        return $scope.initSchemaData();
      }
    };
    $scope.openSchemaDialog = function(schemaType) {
      $scope.operationSchemaType = schemaType;
      $scope.addSchemaModal = true;
      return $scope.promiseSchema = $scope.getSchemaData();
    };
    $scope.closeSchemaDialog = function() {
      var selectedSchema;
      selectedSchema = $scope.getUserSelectedSchema();
      if ($scope.operationSchemaType === 'Source') {
        $scope.newMapper.Mapper.SourceSchema = selectedSchema;
      } else {
        $scope.newMapper.Mapper.DestinationSchema = selectedSchema;
      }
      return $scope.addSchemaModal = false;
    };
    $scope.SelectedSchema = function() {
      return $scope.addSchemaModal = false;
    };
    $scope.saveEdit = function() {
      $scope.$broadcast("valid-editSchemaForm");
      if ($scope.editSchemaForm.$valid) {
        return messager.success("Edit schema successfully.");
      }
    };
    $scope.save = function() {
      var requestDataModel;
      if ($scope.mapperForm.$valid && $scope.uploadValid) {
        requestDataModel = {};
        $scope.newMapper.Mapper.OrganizationID = common.currentOrganization.Id;
        $scope.newMapper.Mapper.OwnerType = $scope.belongType;
        $scope.newMapper.Mapper.OwnerID = $scope.belongId;
        $scope.newMapper.Mapper.SourceSchemaID = $scope.newMapper.Mapper.SourceSchema.Id;
        $scope.newMapper.Mapper.DestinationSchemaID = $scope.newMapper.Mapper.DestinationSchema.Id;
        $scope.newMapper.Mapper.FileList = [];
        $scope.newMapper.Mapper.FileList.push($scope.mapperFile);
        $scope.mapperFile.OwnerType = common.ownerType.mapper;
        $scope.mapperFile.OwnerID = 0;
        requestDataModel = angular.copy($scope.newMapper);
        mapper.removeItemWithAPIRequest(requestDataModel);
        return mapperAPI.create(requestDataModel, function(result) {
          $scope.isSubmit = false;
          if (result.Succeeded === true) {
            $scope.transferObj.obj = result.MapperList[0];
            return common.navigate('transfer', $scope.transferObj);
          } else {
            return common.ShowAPIError('Create Mapper Failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Create Mapper Failed', error.data);
        });
      } else {
        $scope.isSubmit = false;
        return messager.error("Please select schema to mapped.");
      }
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=mapper.xslt&filetype=mapper&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = false;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) === 'xsl' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'xslt') {
            valid = true;
          }
          if (valid === false) {
            messager.error("Please choose a valid XSL file to upload, the file extension should be xsl or xslt.");
          }
          $scope.mapperFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        $scope.mapperFile.Url = msg.File.Url;
        $scope.mapperFile.OriginalName = msg.File.OriginalName;
        $scope.mapperFile.Size = msg.File.Size;
        $scope.mapperFile.SubType = 'Main';
        $scope.mapperFile.Hash = msg.File.Hash;
        $scope.message = 'Processing...';
        $scope.minDuration = 0;
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        messager.error("Upload file failed.");
        return $scope.isSubmit = false;
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.mapperFile = {};
      messager.error("Upload file failed.");
      return $scope.isSubmit = false;
    });
    return $scope.submit = function() {
      if ($scope.uploadValid === false) {
        messager.error("The mapper file is invalid, please choose a valid XSL file to upload, the file extension should be xsl or xslt.");
        return;
      }
      if (!uploader.queue || uploader.queue.length < 1) {
        messager.error("Please choose mapper file to upload.");
        return;
      }
      if (!$scope.newMapper.Mapper.SourceSchema || !$scope.newMapper.Mapper.SourceSchema.Id) {
        messager.error('Please select SourceSchema.');
        $scope.isSubmit = false;
        return;
      }
      if (!$scope.newMapper.Mapper.DestinationSchema || !$scope.newMapper.Mapper.DestinationSchema.Id) {
        messager.error('Please select DestinationSchema.');
        $scope.isSubmit = false;
        return;
      }
      if ($scope.newMapper.Mapper.SourceSchema.Id === $scope.newMapper.Mapper.DestinationSchema.Id) {
        messager.error('SourceSchema and DestinationSchema must be different .');
        $scope.isSubmit = false;
        return;
      }
      if ($scope.newMapper.Mapper.SourceSchema.SchemaType === $scope.newMapper.Mapper.DestinationSchema.SchemaType) {
        messager.error('The SchemaType of SourceSchema and DestinationSchema must be different .');
        $scope.isSubmit = false;
        return;
      }
      if ($scope.newMapper.Mapper.SourceSchema.TransactionType !== $scope.newMapper.Mapper.DestinationSchema.TransactionType) {
        messager.error('The TransactionType of SourceSchema and DestinationSchema must be same .');
        $scope.isSubmit = false;
        return;
      }
      if ($scope.mapperForm.$valid) {
        $scope.isSubmit = true;
        uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.mapperFile.OriginalName + "&filetype=mapper&format=json";
        return uploader.uploadAll();
      }
    };
  }
]).controller('UploadCtrl', [
  "$scope", function($scope) {
    return $scope.url = "www.test.com";
  }
]);
