﻿(function() {

  angular.module('eaas-view-mapper', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/mapper/view", {
        templateUrl: "/modules/eaas/app/mapper/view-mapper.tpl.html",
        controller: 'EaaSViewMapperCtrl'
      });
    }
  ]).controller('EaaSViewMapperCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "mapper", "mapperAPI", '$fileUploader', 'partnerAPI', 'stationAPI', function($scope, $http, $window, $filter, messager, common, mapper, mapperAPI, $fileUploader, partnerAPI, stationAPI) {
      var pageName;
      $scope.common = common;
      $scope.editMapper = {};
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'mapper';
      $scope.viewError = false;
      $scope.belongId = null;
      $scope.belongType = null;
      $scope.getMapperInfo = function() {
        return mapperAPI.search({
          schema: true,
          file: true,
          id: $scope.mapperId
        }, function(response) {
          if (response && response.Succeeded) {
            if (response.MapperList && response.MapperList.length > 0) {
              $scope.editMapper.Mapper = response.MapperList[0];
              $scope.currentItem = $scope.editMapper.Mapper;
              mapper.viewItem = angular.copy($scope.editMapper.Mapper);
              if ($scope.editMapper.Mapper.FileList && $scope.editMapper.Mapper.FileList.length > 0) {
                $scope.mapperFile = angular.copy($scope.editMapper.Mapper.FileList[0]);
              }
              $scope.belongId = $scope.currentItem.OwnerID;
              $scope.belongType = $scope.currentItem.OwnerType;
              $scope.loadBelongTo = true;
              return $scope.initViewObject();
            } else {
              mapper.viewItem = void 0;
              return $scope.viewError = true;
            }
          } else {
            return common.ShowAPIError('Get mapper data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get mapper data failed', error.data);
        });
      };
      $scope.initViewObject = function() {
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.currentItem.InUser;
        $scope.generalView.InDate = $scope.currentItem.InDate;
        $scope.generalView.EditUser = $scope.currentItem.EditUser;
        $scope.generalView.EditDate = $scope.currentItem.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Name', $scope.currentItem.Name));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Source Schema', $scope.currentItem.SourceSchema.Name, true, ['navigateView', 'naviUrl', 'naviObj'], [
          true, 'schema/view', {
            Id: $scope.currentItem.SourceSchema.Id
          }
        ]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Destination Schema', $scope.currentItem.DestinationSchema.Name, true, ['navigateView', 'naviUrl', 'naviObj'], [
          true, 'schema/view', {
            Id: $scope.currentItem.DestinationSchema.Id
          }
        ]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Mapper File', $scope.mapperFile.OriginalName, true, ['downloadView', 'url'], [true, $scope.mapperFile.Url]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Description', $scope.currentItem.Description));
        return $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
      };
      pageName = common.currentRoutePath();
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
        $scope.mapperId = common.current.link[pageName].pageParameter.Id;
        $scope.authItem = angular.copy(common.current.link[pageName].pageParameter);
        $scope.promise = $scope.getMapperInfo();
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        $scope.editMapper.Mapper = mapper.viewItem;
        if ($scope.editMapper.Mapper) {
          $scope.authItem = angular.copy(mapper.viewItem);
          $scope.currentItem = mapper.viewItem;
          if ($scope.editMapper.Mapper.FileList && $scope.editMapper.Mapper.FileList.length > 0) {
            $scope.mapperFile = angular.copy($scope.editMapper.Mapper.FileList[0]);
          }
          $scope.mapperId = $scope.editMapper.Mapper.Id;
          $scope.promise = $scope.getMapperInfo();
        } else {
          $scope.viewError = true;
        }
      } else {
        common.navigate('mapper');
      }
      return $scope.edit = function() {
        return common.navigate('mapper/edit', {
          Id: $scope.mapperId
        });
      };
    }
  ]);

}).call(this);
