﻿(function() {

  angular.module('eaas-mapper', ['ngRoute', 'eaas-api-mapper']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/mapper", {
        templateUrl: "/modules/eaas/app/mapper/mapper.tpl.html",
        controller: 'EaaSMapperCtrl'
      });
    }
  ]).controller('EaaSMapperCtrl', [
    "$scope", "$location", "$http", "$window", "progress", "messager", "mapper", 'common', 'mapperAPI', 'schemaAPI', function($scope, $location, $http, $window, progress, messager, mapper, common, mapperAPI, schemaAPI) {
      var pageName;
      $scope.common = common;
      $scope.query = angular.copy(mapper.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Name',
            value: 'name'
          }, {
            text: 'Description',
            value: 'description'
          }
        ];
        $scope.query.queryField = 'name';
        common.InitQueryFields($scope.query);
      }
      $scope.query.pageSize = common.getPageSize(410, 172);
      $scope.showLoading = true;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      $scope.owner = {
        Id: common.currentOrganization.Id,
        Name: common.currentOrganization.Name,
        Type: 'Organization'
      };
      pageName = common.currentRoutePath();
      $scope.initPartnerOwnerInfo = function() {
        $scope.query.ownerID = common.current.link[pageName].pageParameter.Partner.Id;
        $scope.query.ownerType = 'Partner';
        $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
        $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
        return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
      };
      $scope.initStationOwnerInfo = function() {
        $scope.query.ownerID = common.current.link[pageName].pageParameter.Station.Id;
        $scope.query.ownerType = 'Station';
        $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
        $scope.owner.Name = common.current.link[pageName].pageParameter.Station.Name;
        return $scope.owner.Type = common.current.link[pageName].pageParameter.Station.PartnerType + ' Station';
      };
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
          if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
            $scope.initStationOwnerInfo();
          } else {
            if (common.current.link[pageName].pageParameter.Partner) {
              $scope.initPartnerOwnerInfo();
            }
          }
        }
      } else {
        common.current.link[pageName] = null;
        $scope.query.ownerID = null;
        $scope.query.ownerType = null;
      }
      $scope.search = function() {
        var requestItem, response;
        $scope.message = 'Loading...';
        requestItem = angular.copy($scope.query);
        mapper.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return response = mapperAPI.search(requestItem, function() {
          if (response && response.Succeeded) {
            $scope.query.totalItems = response.TotalRecordCount;
            $scope.mapperList = response.MapperList;
            mapper.data = response.MapperList;
            $scope.loadSchemaInfo();
            common.loadOwnerInfo($scope.mapperList);
            return $scope.getAllFileInfo();
          } else {
            return common.ShowAPIError('Get mapper data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get mapper data failed.', error.data);
        });
      };
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.getAllFileInfo = function() {
        var index, _results;
        _results = [];
        for (index in $scope.mapperList) {
          _results.push($scope.getFileInfo($scope.mapperList[index]));
        }
        return _results;
      };
      $scope.getFileInfo = function(item) {
        return common.fileResourceObtainer.getFileList('Mapper', item);
      };
      $scope.querySchema = function(item) {
        var destinationResponse, sourceResponse;
        sourceResponse = schemaAPI.search({
          id: item.SourceSchemaID
        }, function() {
          if (sourceResponse && sourceResponse.Succeeded && sourceResponse.SchemaList !== null) {
            return item.SourceSchema = sourceResponse.SchemaList[0];
          }
        });
        return destinationResponse = schemaAPI.search({
          id: item.DestinationSchemaID
        }, function() {
          if (destinationResponse && destinationResponse.Succeeded && destinationResponse.SchemaList !== null) {
            return item.DestinationSchema = destinationResponse.SchemaList[0];
          }
        });
      };
      $scope.promise = $scope.search();
      $scope.loadSchemaInfo = function() {
        var index, _results;
        if ($scope.mapperList !== null) {
          _results = [];
          for (index in $scope.mapperList) {
            _results.push($scope.querySchema($scope.mapperList[index]));
          }
          return _results;
        }
      };
      $scope.remove = function(entity) {
        return common.ConfirmBox("Are you sure you want to remove mapper \"" + entity.Name + "\" ? If the mapper was used in any agreement, it cannot be removed.", null, function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.removeMapper(entity);
        });
      };
      $scope.removeMapper = function(entity) {
        var response;
        return response = mapperAPI.remove({
          id: entity.Id,
          ownerid: entity.OwnerID,
          ownertype: entity.OwnerType
        }, function() {
          if (response && response.Succeeded) {
            messager.success("The mapper has been removed successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError('Remove mapper  failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Remove mapper  failed.', error.data);
        });
      };
      $scope.location = function(url) {
        return common.navigate(url);
      };
      $scope.nagvigateAdd = function() {
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          return common.navigate('mapper/create', {
            Station: common.current.link[pageName].pageParameter.Station,
            Partner: common.current.link[pageName].pageParameter.Partner
          });
        } else {
          if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
            return common.navigate('mapper/create', {
              Partner: common.current.link[pageName].pageParameter.Partner
            });
          } else {
            return common.navigate('mapper/create');
          }
        }
      };
      return $scope.navigateEdit = function(item) {
        mapper.editItem = item;
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          return common.navigate('mapper/edit', {
            Station: common.current.link[pageName].pageParameter.Station,
            Partner: common.current.link[pageName].pageParameter.Partner,
            Id: item.Id
          });
        } else {
          if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
            return common.navigate('mapper/edit', {
              Partner: common.current.link[pageName].pageParameter.Partner,
              Id: item.Id
            });
          } else {
            return common.navigate('mapper/edit', {
              Id: item.Id
            });
          }
        }
      };
    }
  ]).controller('UploadCtrl', [
    "$scope", function($scope) {
      return $scope.url = "www.test.com";
    }
  ]);

}).call(this);
