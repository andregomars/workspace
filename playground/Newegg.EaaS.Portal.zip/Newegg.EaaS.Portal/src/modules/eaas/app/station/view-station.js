(function() {
  var pageName;

  angular.module('eaas-view-station', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/station/view", {
        templateUrl: "/modules/eaas/app/station/view-station.tpl.html",
        controller: 'EaaSViewStationCtrl'
      });
    }
  ]).controller('EaaSViewStationCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "station", "mapperAPI", 'partnerAPI', 'stationAPI', 'accountAPI', 'organizationAPI', 'customsettingAPI', 'customSettingCache', function($scope, $http, $window, $filter, messager, common, station, mapperAPI, partnerAPI, stationAPI, accountAPI, organizationAPI, customsettingAPI, customSettingCache) {
      $scope.dic = {};
      $scope.station = {};
      $scope.identityList = [];
      $scope.schemaList = [];
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'station';
      $scope.viewError = false;
      $scope.owner = {};
      $scope.getResourcePartner = function() {
        return partnerAPI.search({
          organizationid: $scope.owner.ownerOrgan.Id
        }, function(result) {
          var index;
          if (result && result.Succeeded) {
            $scope.ownerPartnerList = result.PartnerList;
            if ($scope.currentItem.OwnerType === common.ownerType.partner) {
              for (index in $scope.ownerPartnerList) {
                if ($scope.ownerPartnerList[index].Id === $scope.currentItem.PartnerID) {
                  $scope.owner.ownerPartner = $scope.ownerPartnerList[index];
                }
              }
              $scope.owner.Type = common.ownerType.partner;
              $scope.owner.Name = $scope.owner.ownerPartner.Name;
              return $scope.initBelongView();
            }
          } else {
            return common.ShowAPIError('Get partner data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get partner data failed', error.data);
        });
      };
      $scope.getResourceOrganization = function() {
        var response;
        return response = organizationAPI.search({
          id: $scope.currentItem.OrganizationID
        }, function() {
          if (response && response.Succeeded) {
            $scope.owner.ownerOrgan = response.OrganizationList[0];
            if ($scope.currentItem.OwnerType !== common.ownerType.organization) {
              return $scope.promise = $scope.getResourcePartner();
            }
          } else {
            return common.ShowAPIError('Get organization data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get organization data failed', error.data);
        });
      };
      $scope.setResouceOwner = function() {
        $scope.currentItem.OwnerType = common.ownerType.partner;
        return $scope.promise = $scope.getResourceOrganization();
      };
      $scope.initBelongView = function() {
        $scope.belongView = common.buildViewObject('Belongs To');
        $scope.belongView.viewAttList.push(common.buildViewAttr('Organization', $scope.owner.ownerOrgan.Name));
        $scope.belongView.viewAttList.push(common.buildViewAttr('Local Partner', $scope.owner.ownerPartner.Name));
        return $scope.belongView.viewAttList = common.clearAttrListNullValue($scope.belongView.viewAttList);
      };
      $scope.initViewObject = function() {
        var receiveNotificationEnabled;
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.station.InUser;
        $scope.generalView.InDate = $scope.station.InDate;
        $scope.generalView.EditUser = $scope.station.EditUser;
        $scope.generalView.EditDate = $scope.station.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Status', $scope.station.Status, true, ['statusView'], [true]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Name', $scope.station.Name));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Description', $scope.station.Description));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Station Identity', $scope.station.Identity));
        $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
        if ($scope.station.Contact) {
          $scope.contactView = common.buildViewObject('Contact Information');
          $scope.contactView.viewAttList.push(common.buildViewAttr('Name', $scope.station.Contact.Name));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Company', $scope.station.Contact.Company));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Job Title', $scope.station.Contact.JobTitle));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Email', $scope.station.Contact.Email, true, ['mailView'], [true]));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Business Phone', $scope.station.Contact.BusinessPhone));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Mobile Phone', $scope.station.Contact.MobilePhone));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Fax', $scope.station.Contact.Fax));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Address', $scope.station.Contact.Address));
          $scope.contactView.viewAttList = common.clearAttrListNullValue($scope.contactView.viewAttList);
        }
        debugger;
        if ($scope.station.NotificationSetting) {
          $scope.notificationView = common.buildViewObject('Notification Settings');
          receiveNotificationEnabled = 'No';
          if ($scope.station.NotificationSetting.ReceiveNotificationEnabled === true) {
            receiveNotificationEnabled = 'Yes';
          }
          $scope.notificationView.viewAttList.push(common.buildViewAttr('Notification Enabled', receiveNotificationEnabled));
          $scope.notificationView.viewAttList.push(common.buildViewAttr('Email Address', $scope.station.NotificationSetting.EmailAddress));
          $scope.notificationView.viewAttList.push(common.buildViewAttr('Notification Mode', $scope.station.NotificationSetting.NotificationMode));
          if ($scope.station.NotificationSetting.NotificationMode === 'InBatch') {
            $scope.notificationView.viewAttList.push(common.buildViewAttr('Batch Size', $scope.station.NotificationSetting.BatchSize));
            $scope.notificationView.viewAttList.push(common.buildViewAttr('Batch Interval', $scope.station.NotificationSetting.BatchInterval));
          }
          return $scope.notificationView.viewAttList = common.clearAttrListNullValue($scope.notificationView.viewAttList);
        }
      };
      $scope.getItemInfo = function() {
        return stationAPI.search({
          contact: true,
          schema: true,
          customsettingvalue: true,
          id: $scope.stationId
        }, function(result) {
          if (result && result.Succeeded) {
            if (result.StationList && result.StationList.length > 0) {
              $scope.station = result.StationList[0];
              $scope.currentItem = angular.copy(result.StationList[0]);
              if ($scope.station.ContactList && $scope.station.ContactList.length > 0) {
                $scope.station.Contact = $scope.station.ContactList[0];
              }
              if ($scope.station.CustomSettingValueList && $scope.station.CustomSettingValueList.length > 0) {
                $scope.identityList = $scope.station.CustomSettingValueList;
              }
              if ($scope.station.SchemaList && $scope.station.SchemaList.length > 0) {
                $scope.schemaList = $scope.station.SchemaList;
              }
              station.viewItem = angular.copy($scope.station);
              return $scope.promise = $scope.getCustomSetting();
            } else {
              station.viewItem = void 0;
              return $scope.viewError = true;
            }
          } else {
            return common.ShowAPIError('Get station data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get station data failed', error.data);
        });
      };
      $scope.getSettingDisplayName = function(settingId) {
        var index;
        for (index in $scope.dic.CustomSettingList) {
          if ($scope.dic.CustomSettingList[index].Id === settingId) {
            return $scope.dic.CustomSettingList[index].DisplayName;
          }
        }
        return null;
      };
      $scope.getTransactionTypeDisplayName = function(code) {
        var index;
        for (index in $scope.dic.TransactionTypeSettingList) {
          if ($scope.dic.TransactionTypeSettingList[index].Code === code) {
            return $scope.dic.TransactionTypeSettingList[index].DisplayName;
          }
        }
        return null;
      };
      $scope.getCustomSetting = function() {
        if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
          return customSettingCache.RefreshData($scope.HandleCustomeSettingDisplay, common.currentOrganization.Id);
        } else {
          return $scope.HandleCustomeSettingDisplay();
        }
      };
      return $scope.HandleCustomeSettingDisplay = function() {
        var index;
        $scope.dic.CustomSettingList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.IdentityQualifier));
        for (index in $scope.dic.CustomSettingList) {
          $scope.dic.CustomSettingList[index].DisplayName = $scope.dic.CustomSettingList[index].Code + ' - ' + $scope.dic.CustomSettingList[index].Name;
        }
        for (index in $scope.identityList) {
          $scope.identityList[index].DisplayName = $scope.getSettingDisplayName($scope.identityList[index].SettingID);
        }
        $scope.dic.TransactionTypeSettingList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TransactionType));
        for (index in $scope.dic.TransactionTypeSettingList) {
          $scope.dic.TransactionTypeSettingList[index].DisplayName = $scope.dic.TransactionTypeSettingList[index].Code + ' - ' + $scope.dic.TransactionTypeSettingList[index].Name;
        }
        for (index in $scope.schemaList) {
          $scope.schemaList[index].TransactionTypeDisplayName = $scope.getTransactionTypeDisplayName($scope.schemaList[index].TransactionType);
        }
        $scope.initViewObject();
        return $scope.promise = $scope.setResouceOwner();
      };
    }, pageName = common.currentRoutePath(), common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id ? ($scope.stationId = common.current.link[pageName].pageParameter.Id, $scope.promise = $scope.getItemInfo(), $scope.authItem = {
      Id: $scope.stationId,
      InUser: common.current.link[pageName].pageParameter.InUser
    }) : common.current.isBackPage === true ? (common.current.isBackPage = false, $scope.station = angular.copy(station.viewItem), $scope.station ? ($scope.authItem = angular.copy(station.viewItem), $scope.currentItem = angular.copy(station.viewItem), $scope.station.ContactList && $scope.station.ContactList.length > 0 ? $scope.station.Contact = $scope.station.ContactList[0] : void 0, $scope.station.CustomSettingValueList && $scope.station.CustomSettingValueList.length > 0 ? $scope.identityList = $scope.station.CustomSettingValueList : void 0, $scope.station.SchemaList && $scope.station.SchemaList.length > 0 ? $scope.schemaList = $scope.station.SchemaList : void 0, $scope.promise = $scope.getCustomSetting()) : $scope.viewError = true) : common.navigate('station'), $scope.edit = function() {
      station.editItem = $scope.station;
      return common.navigate('station/edit');
    }
  ]);

}).call(this);
