﻿(function() {

  angular.module('eaas-station', ['ngRoute', 'pascalprecht.translate']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/station", {
        templateUrl: "/modules/eaas/app/station/station.tpl.html",
        controller: 'EaaSStationCtrl'
      });
    }
  ]).controller('EaaSStationCtrl', [
    "$scope", "messager", 'common', 'station', 'stationAPI', 'agreementAPI', 'transmissionAPI', 'schemaAPI', 'mapperAPI', function($scope, messager, common, station, stationAPI, agreementAPI, transmissionAPI, schemaAPI, mapperAPI) {
      var pageName;
      $scope.common = common;
      pageName = common.currentRoutePath();
      $scope.query = angular.copy(station.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Name',
            value: 'name'
          }, {
            text: 'Identity',
            value: 'identity'
          }, {
            text: 'Description',
            value: 'description'
          }
        ];
        $scope.query.queryField = 'name';
        $scope.query.status = null;
        common.InitQueryFields($scope.query);
      }
      $scope.pageSize = common.getPageSize(420, 120);
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Partner) {
        $scope.currentPartner = common.current.link[pageName].pageParameter.Partner;
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Partner) {
          $scope.currentPartner = common.current.link[pageName].pageParameter.Partner;
        }
      } else {
        common.navigate('partner');
      }
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.query.partnerid = $scope.currentPartner.Id;
      $scope.showLoading = true;
      $scope.queryAgreement = function(item) {
        var queryModel;
        queryModel = {};
        if ($scope.currentPartner.Type === 'Local') {
          queryModel.LocalStationID = item.Id;
        } else {
          queryModel.TradingStationID = item.Id;
        }
        return common.resourceStatisticsObtainer.getAgreementStatistics('AgreementCount', queryModel, item);
      };
      $scope.queryTransmission = function(item) {
        var queryModel;
        queryModel = {
          ownerID: item.Id,
          ownerType: 'Station',
          encodingprotocol: false
        };
        return common.resourceStatisticsObtainer.getTransmissionStatistics('TransmissionCount', queryModel, item);
      };
      $scope.querySchema = function(item) {
        var queryModel;
        queryModel = {
          ownerID: item.Id,
          ownerType: 'Station'
        };
        return common.resourceStatisticsObtainer.getSchemaStatistics('SchemaCount', queryModel, item);
      };
      $scope.queryMapper = function(item) {
        var queryModel;
        queryModel = {
          ownerID: item.Id,
          ownerType: 'Station'
        };
        return common.resourceStatisticsObtainer.getMapperStatistics('MapperCount', queryModel, item);
      };
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      $scope.search = function() {
        var requestItem;
        $scope.message = 'Loading...';
        requestItem = angular.copy($scope.query);
        station.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return stationAPI.search(requestItem, function(result) {
          if (result && result.Succeeded) {
            $scope.query.totalItems = result.TotalRecordCount;
            $scope.stationList = result.StationList;
            return $scope.loadCountInfo();
          } else {
            return common.ShowAPIError('Get station data failed.', result);
          }
        }, function(error) {
          $scope.showLoading = false;
          return common.ShowAPIError('Get station data failed.', error.data);
        });
      };
      $scope.loadCountInfo = function() {
        var index, _results;
        if ($scope.stationList !== null) {
          _results = [];
          for (index in $scope.stationList) {
            $scope.queryAgreement($scope.stationList[index]);
            if ($scope.currentPartner.Type === 'Local') {
              $scope.queryTransmission($scope.stationList[index]);
              $scope.querySchema($scope.stationList[index]);
              _results.push($scope.queryMapper($scope.stationList[index]));
            } else {
              _results.push(void 0);
            }
          }
          return _results;
        }
      };
      $scope.filter = function(type) {
        $scope.filterType = type;
        if (type === 'all') {
          $scope.query.status = null;
        } else {
          $scope.query.status = type;
        }
        return $scope.advancedSearch();
      };
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.filterType = "all";
      if ($scope.query && $scope.query.status) {
        $scope.filterType = $scope.query.status;
      }
      $scope.promise = $scope.search();
      $scope.searchActive = function(business) {
        if (business.Status === 'Active') {
          return true;
        }
        return false;
      };
      $scope.add = function(url) {
        return common.navigate(url, {
          Partner: $scope.currentPartner
        });
      };
      $scope.navigate = function(url, item) {
        common.current.link.status = 'station';
        if (item !== null) {
          item.PartnerType = $scope.currentPartner.Type;
          item.PartnerName = $scope.currentPartner.Name;
          common.current.link.station = item;
          common.current.link.station.PartnerType = $scope.currentPartner.Type;
          common.current.link.station.PartnerName = $scope.currentPartner.Name;
        }
        return common.navigate(url, {
          Station: item,
          Partner: $scope.currentPartner
        });
      };
      $scope.changeStatus = function(station) {
        var confirmMsg, confirmWarnMsg, opStatus;
        opStatus = (station.Status === "Active" ? "deactivate" : "active");
        if (opStatus === 'active') {
          confirmMsg = "Are you sure you want to deactivate the station \"" + station.Name + "\" ?";
          confirmWarnMsg = "If you deactivate a station which is exchanging business data with stations of other partners, no more data will be processed for this station.";
        } else {
          confirmMsg = "Are you sure you want to activate the station \"" + station.Name + "\" ?";
          confirmWarnMsg = "If you activate a station which has agreement with station of other partner correctly configured and activated, it will start to process the incoming and outgoing data.";
        }
        return common.ConfirmBox(confirmMsg, confirmWarnMsg, function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.changeStationStatus(station);
        });
      };
      $scope.changeStationStatus = function(station) {
        var opStatus, orignalStatus, requestEntity;
        orignalStatus = station.Status;
        opStatus = '';
        requestEntity = {};
        requestEntity.id = station.Id;
        if (station.Status === "Active") {
          requestEntity.action = "disable";
          opStatus = 'deactivated';
        } else {
          requestEntity.action = "enable";
          opStatus = 'activated';
        }
        return stationAPI.updateStatus(requestEntity, function(result) {
          if (result.Succeeded) {
            messager.success("Station \"" + station.Name + "\" has been " + opStatus + " successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError("Failed to " + requestEntity.action + " station " + station.Name + ".", result);
          }
        }, function(error) {
          return common.ShowAPIError("Failed to " + requestEntity.action + " station " + station.Name + ".", error.data);
        });
      };
      $scope.remove = function(currentStation) {
        return common.ConfirmBox("Do you want to remove the station \"" + currentStation.Name + "\"?", "If there is any agreement associated with this station, it cannot be removed.", function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.removeStation(currentStation);
        });
      };
      $scope.removeStation = function(currentStation) {
        var response;
        return response = stationAPI.remove({
          id: currentStation.Id,
          partnerid: $scope.currentPartner.Id
        }, function() {
          if (response && response.Succeeded) {
            messager.success("Remove station successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError("Remove station failed.", response);
          }
        }, function(error) {
          return common.ShowAPIError("Remove station failed.", error.data);
        });
      };
      return $scope.edit = function(url, currentStation) {
        station.editItem = currentStation;
        return common.navigate(url);
      };
    }
  ]);

}).call(this);
