(function() {

  angular.module('eaas-create-station', ['ngRoute', 'pascalprecht.translate']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/station/create", {
        templateUrl: "/modules/eaas/app/station/create-station.tpl.html",
        controller: 'createStationCtrl'
      });
    }
  ]).controller('createStationCtrl', [
    "$scope", "$location", "messager", 'common', 'customsettingAPI', 'customsettingvalueAPI', 'schemaAPI', 'stationAPI', 'station', 'partnerAPI', '$filter', 'customSettingCache', function($scope, $location, messager, common, customsettingAPI, customsettingvalueAPI, schemaAPI, stationAPI, station, partnerAPI, $filter, customSettingCache) {
      var pageName;
      pageName = common.currentRoutePath();
      $scope.transferObj = {
        isSucceed: true,
        action: 'create',
        objName: 'station',
        title: 'Station has been created successfully'
      };
      common.initUnSavedConfirm($scope);
      $scope.common = common;
      $scope.station = {
        NotificationSetting: {}
      };
      $scope.station.NotificationSetting.NotificationMode = 'Immediate';
      $scope.station.NotificationSetting.BatchSize = 50;
      $scope.station.NotificationSetting.BatchInterval = 2;
      if (common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Partner) {
        station.partner = angular.copy(common.current.link[pageName].pageParameter.Partner);
        $scope.currentPartner = angular.copy(station.partner);
      } else {
        common.navigate('partner');
        return;
      }
      $scope.dic = {};
      $scope.identityList = [];
      $scope.schemaList = [];
      $scope.userPartner = null;
      $scope.isSubmit = false;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.getUserBelongToPartnerInfo = function() {
        if (common.currentUser.UserRole !== common.userRole.superUser && common.currentUser.UserRole !== common.userRole.organizationUser) {
          return partnerAPI.search({
            id: station.partner.Id.Id
          }, function(result) {
            if (result && result.Succeeded && result.PartnerList && result.PartnerList.length > 0) {
              $scope.userPartner = result.PartnerList[0];
              return $scope.promise = $scope.queryStation($scope.userPartner);
            } else {
              return common.ShowAPIError('Get partner data failed', result);
            }
          }, function(error) {
            $scope.showLoading = false;
            return common.ShowAPIError('Get partner data failed', error.data);
          });
        }
      };
      $scope.queryStation = function(item) {
        var response;
        return response = stationAPI.search({
          partnerid: item.Id
        }, function() {
          if (response && response.Succeeded && response.StationList !== null) {
            return $scope.userPartner.StationList = response.StationList;
          }
        });
      };
      $scope.getIdentityDic = function() {
        return customsettingAPI.search({
          category: 'IdentityQualifier',
          organizationid: common.currentOrganization.Id
        }, function(result) {
          var index;
          if (result && result.Succeeded) {
            $scope.dic.CustomSettingList = result.CustomSettingList;
            for (index in $scope.dic.CustomSettingList) {
              $scope.dic.CustomSettingList[index].DisplayName = $scope.dic.CustomSettingList[index].Code + ' - ' + $scope.dic.CustomSettingList[index].Name;
            }
            return $scope.promise = $scope.getUserBelongToPartnerInfo();
          } else {
            return common.ShowAPIError('Get identity data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get identity data failed', error.data);
        });
      };
      $scope.getCustomSetting = function() {
        if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
          return customSettingCache.RefreshData($scope.HandleCustomeSettingDisplay, common.currentOrganization.Id);
        } else {
          return $scope.HandleCustomeSettingDisplay();
        }
      };
      $scope.HandleCustomeSettingDisplay = function() {
        var index;
        $scope.dic.CustomSettingList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.IdentityQualifier));
        for (index in $scope.dic.CustomSettingList) {
          $scope.dic.CustomSettingList[index].DisplayName = $scope.dic.CustomSettingList[index].Code + ' - ' + $scope.dic.CustomSettingList[index].Name;
        }
        return $scope.promise = $scope.getUserBelongToPartnerInfo();
      };
      $scope.promise = $scope.getCustomSetting();
      $scope.getSchemaData = function() {
        var response;
        if ($scope.dic.schemaList && $scope.dic.schemaList.length > 0) {
          $scope.initSchemaData();
          return $scope.syncSchema();
        } else {
          return response = schemaAPI.search({
            file: false
          }, function() {
            if (response && response.Succeeded) {
              $scope.dic.schemaList = response.SchemaList;
              $scope.initSchemaData();
              return $scope.syncSchema();
            }
          });
        }
      };
      $scope.initSchemaData = function() {
        var index;
        for (index in $scope.dic.schemaList) {
          $scope.dic.schemaList[index].selected = false;
          $scope.dic.schemaList[index].show = true;
          if ($scope.dic.schemaList[index].SchemaType !== station.partner.Type) {
            $scope.dic.schemaList[index].show = false;
            continue;
          }
          if ($scope.filterSchmeaBelongTo($scope.dic.schemaList[index]) === false) {
            $scope.dic.schemaList[index].show = false;
          }
        }
        return $scope.dic.schemaList = $filter('orderBy')($scope.dic.schemaList, 'sortType');
      };
      $scope.filterSchmeaBelongTo = function(schema) {
        if (schema.OwnerType === common.ownerType.organization) {
          schema.sortType = 3;
          return true;
        }
        if (schema.OwnerType === common.ownerType.partner) {
          schema.sortType = 2;
          if (common.currentUser.PartnerID && schema.OwnerID !== common.currentUser.PartnerID) {
            return false;
          }
        }
        if (schema.OwnerType === common.ownerType.station) {
          schema.sortType = 1;
          if ($scope.userPartner !== null && $scope.userBelongPartnerExistStation(schema.OwnerID) === false) {
            return false;
          }
          if (common.currentUser.StationID && schema.OwnerID !== common.currentUser.StationID) {
            return false;
          }
        }
        return true;
      };
      $scope.userBelongPartnerExistStation = function(stationId) {
        var index;
        for (index in $scope.userPartner.StationList) {
          if ($scope.userPartner.StationList[index].Id === stationId) {
            return true;
          }
        }
        return false;
      };
      $scope.syncSchema = function() {
        var dicIndex, index, _results;
        _results = [];
        for (index in $scope.schemaList) {
          _results.push((function() {
            var _results1;
            _results1 = [];
            for (dicIndex in $scope.dic.schemaList) {
              if ($scope.schemaList[index].Id === $scope.dic.schemaList[dicIndex].Id) {
                _results1.push($scope.dic.schemaList[dicIndex].selected = true);
              } else {
                _results1.push(void 0);
              }
            }
            return _results1;
          })());
        }
        return _results;
      };
      $scope.addIdentity = function(identityList) {
        var identity;
        identity = {
          SettingID: null,
          Value: null
        };
        return identityList.push(identity);
      };
      $scope.removeIdentity = function(identityList, index) {
        return identityList.splice(index, 1);
      };
      $scope.removeSchema = function(schemaList, index) {
        return schemaList.splice(index, 1);
      };
      $scope.openSchemaDialog = function(schemaType) {
        $scope.operationSchemaType = schemaType;
        $scope.addSchemaModal = true;
        return $scope.promiseSchema = $scope.getSchemaData();
      };
      $scope.closeSchemaDialog = function() {
        return $scope.addSchemaModal = false;
      };
      $scope.SelectedSchema = function() {
        $scope.schemaList = [];
        $scope.getUserSelectedSchema();
        return $scope.addSchemaModal = false;
      };
      $scope.getUserSelectedSchema = function() {
        var index, _results;
        _results = [];
        for (index in $scope.dic.schemaList) {
          if ($scope.dic.schemaList[index].selected === true) {
            _results.push($scope.schemaList.push($scope.dic.schemaList[index]));
          } else {
            _results.push(void 0);
          }
        }
        return _results;
      };
      $scope.validateCustomSetting = function() {
        var index, validIndex;
        for (index in $scope.identityList) {
          for (validIndex in $scope.identityList) {
            if (index === validIndex) {
              continue;
            }
            if ($scope.identityList[index].SettingID === $scope.identityList[validIndex].SettingID && $scope.identityList[index].Value === $scope.identityList[validIndex].Value) {
              return false;
            }
          }
        }
        return true;
      };
      $scope.save = function() {
        if ($scope.stationForm.$valid) {
          if ($scope.validateCustomSetting() === false) {
            messager.error('The same type of identity must have different value in additional identity list.');
            return;
          }
          $scope.message = 'Processing...';
          return $scope.promise = $scope.submitStation();
        }
      };
      return $scope.submitStation = function() {
        var requestDataModel;
        $scope.isSubmit = true;
        $scope.station.ContactList = [];
        $scope.station.Status = 'Active';
        if (station.partner !== null) {
          $scope.station.PartnerID = station.partner.Id;
        }
        $scope.station.CustomSettingValueList = $scope.identityList;
        if ($scope.station.Contact) {
          $scope.station.ContactList.push($scope.station.Contact);
        } else {
          $scope.station.ContactList = null;
        }
        requestDataModel = {};
        requestDataModel.Station = angular.copy($scope.station);
        if (requestDataModel.Station.Contact) {
          delete requestDataModel.Station.Contact;
        }
        if ($scope.currentPartner.Type === 'Trading') {
          delete requestDataModel.Station.NotificationSetting;
        }
        return stationAPI.create(requestDataModel, function(result) {
          if (result.Succeeded === true) {
            $scope.transferObj.obj = result.StationList[0];
            common.navigate('transfer', $scope.transferObj);
          } else {
            common.ShowAPIError('Create station failed.', result);
          }
          return $scope.isSubmit = false;
        }, function(error) {
          $scope.isSubmit = false;
          return common.ShowAPIError('Create station failed.', error.data);
        });
      };
    }
  ]);

}).call(this);
