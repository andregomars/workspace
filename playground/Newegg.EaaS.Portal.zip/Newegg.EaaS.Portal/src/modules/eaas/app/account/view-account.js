﻿(function() {

  angular.module('eaas-view-account', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/account/view", {
        templateUrl: "/modules/eaas/app/account/view-account.tpl.html",
        controller: 'EaaSViewAccountCtrl'
      });
    }
  ]).controller('EaaSViewAccountCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "account", "mapperAPI", '$fileUploader', 'partnerAPI', 'stationAPI', 'accountAPI', 'organizationAPI', function($scope, $http, $window, $filter, messager, common, account, mapperAPI, $fileUploader, partnerAPI, stationAPI, accountAPI, organizationAPI) {
      var pageName;
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'account';
      $scope.viewError = false;
      $scope.ownerId = null;
      $scope.ownerType = null;
      $scope.getItemInfo = function() {
        return accountAPI.search({
          id: $scope.accountId,
          contact: true
        }, function(result) {
          if (result && result.Succeeded) {
            if (result.AccountList && result.AccountList.length > 0) {
              $scope.user = result.AccountList[0];
              $scope.currentItem = result.AccountList[0];
              account.viewItem = angular.copy(result.AccountList[0]);
              if ($scope.user.ContactList && $scope.user.ContactList.length > 0) {
                $scope.user.Contact = $scope.user.ContactList[0];
              }
              $scope.setUserOwnerInfo();
              $scope.loadBelongTo = true;
              return $scope.initViewObject();
            } else {
              $scope.viewError = true;
              return partner.viewItem = void 0;
            }
          } else {
            return common.ShowAPIError('Get account data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get account data failed', error.data);
        });
      };
      $scope.initViewObject = function() {
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.user.InUser;
        $scope.generalView.InDate = $scope.user.InDate;
        $scope.generalView.EditUser = $scope.user.EditUser;
        $scope.generalView.EditDate = $scope.user.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Status', $scope.user.Status, true, ['statusView'], [true]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Login Name', $scope.user.LoginName));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Description', $scope.user.Description));
        $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
        if ($scope.user.Contact) {
          $scope.contactView = common.buildViewObject('Contact Information');
          $scope.contactView.viewAttList.push(common.buildViewAttr('Name', $scope.user.Contact.Name));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Company', $scope.user.Contact.Company));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Job Title', $scope.user.Contact.JobTitle));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Email', $scope.user.Contact.Email, true, ['mailView'], [true]));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Business Phone', $scope.user.Contact.BusinessPhone));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Mobile Phone', $scope.user.Contact.MobilePhone));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Fax', $scope.user.Contact.Fax));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Address', $scope.user.Contact.Address));
          return $scope.contactView.viewAttList = common.clearAttrListNullValue($scope.contactView.viewAttList);
        }
      };
      $scope.setUserOwnerInfo = function() {
        if ($scope.user.Type === common.userRole.superUser) {
          $scope.ownerId = null;
          return $scope.ownerType = null;
        } else {
          $scope.ownerType = $scope.user.Type;
          if ($scope.user.Type === common.userRole.organizationUser) {
            $scope.ownerId = $scope.user.OrganizationID;
          }
          if ($scope.user.Type === common.userRole.partnerUser) {
            $scope.ownerId = $scope.user.PartnerID;
          }
          if ($scope.user.Type === common.userRole.stationUser) {
            return $scope.ownerId = $scope.user.StationID;
          }
        }
      };
      pageName = common.currentRoutePath();
      if (common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
        $scope.accountId = common.current.link[pageName].pageParameter.Id;
        $scope.promise = $scope.getItemInfo();
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        $scope.user = angular.copy(account.viewItem);
        if ($scope.user) {
          $scope.currentItem = angular.copy(account.viewItem);
          if ($scope.user.ContactList && $scope.user.ContactList.length > 0) {
            $scope.user.Contact = $scope.user.ContactList[0];
          }
          $scope.setUserOwnerInfo();
          $scope.loadBelongTo = true;
          $scope.initViewObject();
        } else {
          $scope.viewError = true;
        }
      } else {
        common.navigate('account');
      }
      return $scope.edit = function() {
        account.editItem = $scope.user;
        return common.navigate('account/edit');
      };
    }
  ]);

}).call(this);
