﻿(function() {

  angular.module('eaas-account', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/account", {
        templateUrl: "/modules/eaas/app/account/account.tpl.html",
        controller: 'accountManagementController'
      });
    }
  ]).controller('accountManagementController', [
    "$scope", 'common', '$filter', 'accountAPI', 'messager', 'account', "organizationAPI", "partnerAPI", "stationAPI", function($scope, common, $filter, accountAPI, messager, account, organizationAPI, partnerAPI, stationAPI) {
      $scope.title = 'The account currently in #OwnerInfo# listed at below, you can add new account nor update its information by the action button on each block. ';
      $scope.common = common;
      $scope.query = angular.copy(account.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Login Name',
            value: 'loginName'
          }, {
            text: 'Description',
            value: 'description'
          }
        ];
        $scope.query.queryField = 'loginName';
        $scope.query.type = null;
        $scope.query.status = null;
        common.InitQueryFields($scope.query);
      } else {
        common.current.isBackPage = false;
      }
      $scope.query.pageSize = common.getPageSize(385, 122);
      $scope.showLoading = true;
      $scope.loadOwnerInfo = function() {
        var index;
        if ($scope.accountList !== null) {
          for (index in $scope.accountList) {
            if ($scope.accountList[index].Type === 'Supervisor') {
              $scope.accountList[index].OwnerName = 'Administrator';
            } else {
              $scope.accountList[index].OwnerType = $scope.accountList[index].Type;
            }
            if ($scope.accountList[index].Type === 'Organization') {
              $scope.accountList[index].OwnerID = $scope.accountList[index].OrganizationID;
            }
            if ($scope.accountList[index].Type === 'Partner') {
              $scope.accountList[index].OwnerID = $scope.accountList[index].PartnerID;
            }
            if ($scope.accountList[index].Type === 'Station') {
              $scope.accountList[index].OwnerID = $scope.accountList[index].StationID;
            }
          }
          return common.loadOwnerInfo($scope.accountList);
        }
      };
      $scope.navigateOwnerDetail = function(item) {
        if (item.Type === 'Organization') {
          common.navigate('organization/detail');
        }
        if (item.Type === 'Partner') {
          common.navigate('partner/view', {
            Id: item.PartnerID
          });
        }
        if (item.Type === 'Station') {
          return common.navigate('station/view', {
            Id: item.StationID
          });
        }
      };
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      $scope.search = function() {
        var requestItem;
        $scope.message = 'Loading...';
        requestItem = angular.copy($scope.query);
        account.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return accountAPI.search(requestItem, function(result) {
          if (result && result.Succeeded) {
            $scope.query.totalItems = result.TotalRecordCount;
            $scope.accountList = result.AccountList;
            return $scope.loadOwnerInfo();
          } else {
            return common.ShowAPIError('Get account data failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get account data failed.', error.data);
        });
      };
      $scope.filterType = "all";
      if (!$scope.query.type && $scope.query.status === 'Deactive') {
        $scope.filterType = 'Deactive';
      } else if ($scope.query.type) {
        $scope.filterType = $scope.query.type;
      }
      $scope.query.contact = false;
      $scope.promise = $scope.search();
      $scope.filter = function(type) {
        $scope.filterType = type;
        if (type === 'all') {
          $scope.query.type = null;
          $scope.query.status = null;
        } else if (type === 'Deactive') {
          $scope.query.type = null;
          $scope.query.status = 'Deactive';
        } else {
          $scope.query.status = 'Active';
          $scope.query.type = type;
        }
        $scope.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.remove = function(account) {
        if (account.Id === common.currentUser.Id) {
          messager.error('It is not allowed to remove the account of yourself.');
          return;
        }
        return common.ConfirmBox("Are you sure you want to permanently remove the account \"" + account.LoginName + "\"?", "If an account was removed, it will unable to login to the EaaS System.", function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.removeAccount(account);
        });
      };
      $scope.removeAccount = function(account) {
        return accountAPI.remove({
          id: account.Id
        }, function(response) {
          if (response && response.Succeeded) {
            messager.success("The account has been removed successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError('Remove account  failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Remove account  failed.', error.data);
        });
      };
      $scope.changeStatus = function(account) {
        var opMsg, opStatus;
        if (account.Id === common.currentUser.Id) {
          messager.error('It is not allowed to deactivate the account of yourself.');
          return;
        }
        opStatus = (account.Status === "Active" ? "deactivate" : "active");
        opMsg = (account.Status === "Active" ? "If an account was deactivated, the EaaS System will not allow he/she to login until the account get activated again." : "");
        return common.ConfirmBox("Are you sure you want to " + opStatus + " the account \"" + account.LoginName + "\"? ", opMsg, function() {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.changeAccount(account);
        });
      };
      $scope.changeAccount = function(account) {
        var opStatus, requestEntity;
        opStatus = '';
        requestEntity = {};
        requestEntity.id = account.Id;
        if (account.Status === "Active") {
          requestEntity.action = "disable";
          opStatus = 'deactived';
        } else {
          requestEntity.action = "enable";
          opStatus = 'activated';
        }
        return accountAPI.updateStatus(requestEntity, function(result) {
          if (result.Succeeded) {
            messager.success("The account \"" + account.LoginName + "\" has been " + opStatus + " successfully.");
            return $scope.promise = $scope.search();
          } else {
            return common.ShowAPIError("Change the status of \"" + account.LoginName + "\" failed.", response);
          }
        }, function(error) {
          return common.ShowAPIError("Change the status of \"" + account.LoginName + "\" failed.", error.data);
        });
      };
      $scope.navigate = function(url) {
        return common.navigate(url);
      };
      return $scope.edit = function(url, currentAccount) {
        account.editItem = currentAccount;
        return common.navigate(url);
      };
    }
  ]);

}).call(this);
