﻿
angular.module('eaas-edit-account', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/account/edit", {
      templateUrl: "/modules/eaas/app/account/edit-account.tpl.html",
      controller: 'eaasCreateAccountCtrl'
    });
  }
]).controller('eaasCreateAccountCtrl', [
  "$scope", "$location", "$http", '$routeParams', "progress", "messager", 'common', 'account', 'accountAPI', 'organizationAPI', 'partnerAPI', 'stationAPI', function($scope, $location, $http, $routeParams, progress, messager, common, account, accountAPI, organizationAPI, partnerAPI, stationAPI) {
    if (account.editItem.Password === void 0) {
      common.navigate('account');
    }
    $scope.transferObj = {
      isSucceed: true,
      action: 'edit',
      objName: 'account',
      title: 'Account has been updated successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.user = account.editItem;
    $scope.user.ConfirmPwd = $scope.user.Password;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.ownerId = null;
    $scope.ownerType = null;
    $scope.autoSetOwnerInfo = false;
    $scope.ownerChanged = function() {
      $scope.aa = $scope.ownerType;
      return $scope.bb = $scope.ownerId;
    };
    $scope.initData = function() {
      return accountAPI.search({
        id: $scope.user.Id,
        contact: true
      }, function(result) {
        $scope.showLoading = false;
        if (result && result.Succeeded && result.AccountList && result.AccountList.length > 0) {
          $scope.user = result.AccountList[0];
          if ($scope.user.ContactList && $scope.user.ContactList.length > 0) {
            $scope.user.Contact = $scope.user.ContactList[0];
          }
          $scope.user.ConfirmPwd = $scope.user.Password;
          $scope.orignalPwd = $scope.user.Password;
          $scope.setUserOwnerInfo();
          return $scope.loadBelongTo = true;
        } else {
          return common.ShowAPIError('Get account failed', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get account failed', error.Data);
      });
    };
    $scope.setUserOwnerInfo = function() {
      $scope.ownerOrganId = $scope.user.OrganizationID;
      $scope.ownerPartnerId = $scope.user.PartnerID;
      $scope.ownerStationdId = $scope.user.StationID;
      if ($scope.user.Type === common.userRole.superUser) {
        $scope.ownerId = null;
        return $scope.ownerType = null;
      } else {
        $scope.ownerType = $scope.user.Type;
        if ($scope.user.Type === common.userRole.organizationUser) {
          $scope.ownerId = $scope.user.OrganizationID;
        }
        if ($scope.user.Type === common.userRole.partnerUser) {
          $scope.ownerId = $scope.user.PartnerID;
        }
        if ($scope.user.Type === common.userRole.stationUser) {
          return $scope.ownerId = $scope.user.StationID;
        }
      }
    };
    $scope.promise = $scope.initData();
    $scope.save = function() {
      if ($scope.accountForm.$valid) {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.submitAccount();
      }
    };
    return $scope.submitAccount = function() {
      var requestDataModel;
      $scope.isSubmit = true;
      $scope.user.OrganizationID = $scope.ownerOrganId;
      $scope.user.PartnerID = $scope.ownerPartnerId;
      $scope.user.StationID = $scope.ownerStationdId;
      $scope.user.ContactList = [];
      if ($scope.user.Contact) {
        $scope.user.ContactList.push($scope.user.Contact);
      }
      requestDataModel = {};
      requestDataModel.Account = angular.copy($scope.user);
      if (requestDataModel.Account.Contact) {
        delete requestDataModel.Account.Contact;
      }
      return accountAPI.edit(requestDataModel, function(result) {
        $scope.isSubmit = false;
        if (result.Succeeded === true) {
          $scope.transferObj.obj = result.AccountList[0];
          return common.navigate('transfer', $scope.transferObj);
        } else {
          return common.ShowAPIError('Edit account failed', result);
        }
      }, function(error) {
        $scope.isSubmit = false;
        return common.ShowAPIError('Edit account failed', error.data);
      });
    };
  }
]);
