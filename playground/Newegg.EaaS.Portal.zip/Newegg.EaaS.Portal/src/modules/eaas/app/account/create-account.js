﻿
angular.module('eaas-create-account', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/account/create", {
      templateUrl: "/modules/eaas/app/account/create-account.tpl.html",
      controller: 'createAccountCtrl'
    });
  }
]).controller('createAccountCtrl', [
  "$scope", "$location", "$http", '$routeParams', "progress", "messager", 'common', 'accountAPI', 'organizationAPI', 'partnerAPI', 'stationAPI', '$rootScope', '$q', function($scope, $location, $http, $routeParams, progress, messager, common, accountAPI, organizationAPI, partnerAPI, stationAPI, $rootScope, $q) {
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.ownerId = null;
    $scope.ownerType = null;
    $scope.belongToDescription = 'When you creating a user account, you can control the management scope of the user account by specifying the belonging Partner or Station. If a user account belongs to a local partner, it’s a partner user, it can only manage the resources which belong to the local partner. If a user account belongs to a station of a local partner, it’s a station user, it can only manage the resources which belong to the station of the local partner. If you don’t specify the belonging partner and station, then the user account is an organization user, and it could manage all resources belong to this organization.';
    $scope.ownerChanged = function() {
      $scope.aa = $scope.ownerType;
      return $scope.bb = $scope.ownerId;
    };
    $scope.loadBelongTo = true;
    $scope.transferObj = {
      isSucceed: true,
      action: 'create',
      objName: 'account',
      title: 'Account has been created successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.user = {};
    $scope.isSubmit = false;
    $scope.showSuperUser = function() {
      if (common.currentUser.Type === common.userRole.superUser && common.currentOrganization === null) {
        return true;
      }
      return false;
    };
    $scope.save = function() {
      if ($scope.accountForm.$valid) {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.submitAccount();
      }
    };
    return $scope.submitAccount = function() {
      var requestDataModel;
      $scope.isSubmit = true;
      $scope.user.Status = 'Active';
      $scope.user.OrganizationID = $scope.ownerOrganId;
      $scope.user.PartnerID = $scope.ownerPartnerId;
      $scope.user.StationID = $scope.ownerStationdId;
      if ($scope.user.Contact) {
        $scope.user.ContactList = [];
        $scope.user.ContactList.push($scope.user.Contact);
      }
      requestDataModel = {};
      requestDataModel.Account = angular.copy($scope.user);
      if (requestDataModel.Account.Contact) {
        delete requestDataModel.Account.Contact;
      }
      return accountAPI.create(requestDataModel, function(result) {
        $scope.isSubmit = false;
        if (result.Succeeded === true) {
          $scope.transferObj.obj = result.AccountList[0];
          return common.navigate('transfer', $scope.transferObj);
        } else {
          return common.ShowAPIError('Create Account Failed', result);
        }
      }, function(error) {
        $scope.isSubmit = false;
        return common.ShowAPIError('Create Account Failed', error.data);
      });
    };
    /*
      $scope.getOrganizationInfo=()->
                deferred=$q.defer();
                organizationAPI.search {}
                    ,(result)->            
                        $scope.loadOrgan=false;
                        if(result&&result.Succeeded)                    
                            deferred.resolve(result.OrganizationList)
    
                return deferred.promise;
    
      $scope.getPartnerInfo=(organList)->             
                console.log(organList) 
                deferred=$q.defer();     
                partnerAPI.search {contact:false,certificate:false,station:false}
                    ,(result)->        
                        deferred.reject('Partner error.')                      
                       # if(result&&result.Succeeded)            
                       #     deferred.resolve(result.PartnerList)
    
                return deferred.promise;
    
      $scope.getStationInfo=(partnerList)->          
                console.log(partnerList) 
                deferred=$q.defer();     
                stationAPI.search {contact:false,schema:false,customsettingvalue:false}
                    ,(result)->                      
                       # if(result)                 
                        deferred.resolve(result.StationList)   
                       # else if(result.StationList.length<100)
                        #deferred.reject('Count less than 100.')   
                return deferred.promise;             
    
      $scope.onBelongToInfoLoadComplete=(result)->
            alert(result)
    
      $scope.onBelongToInfoLoad2Complete=(result)->
            alert('success,,'+result)
    
      $q.all([$scope.getOrganizationInfo(),$scope.getPartnerInfo(),$scope.getStationInfo()])
        .then (results)->
                                console.log(results)
                    ,(result)->
                                console.log(result)
    
      $scope.promise=$scope.getOrganizationInfo()
          .then (result)->
                            $scope.getPartnerInfo(result)
                       ,(result)->
                            $scope.getPartnerInfo(result)
          .then($scope.getStationInfo)
          .then (result)->
                            $scope.onBelongToInfoLoad2Complete(result)
                       ,(result)->
                            $scope.onBelongToInfoLoadComplete(result)
    */

  }
]);
