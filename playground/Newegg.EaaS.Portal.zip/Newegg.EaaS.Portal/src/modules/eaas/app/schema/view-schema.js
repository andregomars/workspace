﻿(function() {

  angular.module('eaas-view-schema', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/schema/view", {
        templateUrl: "/modules/eaas/app/schema/view-schema.tpl.html",
        controller: 'EaaSViewSchemaCtrl'
      });
    }
  ]).controller('EaaSViewSchemaCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "schema", "schemaAPI", '$fileUploader', 'partnerAPI', 'stationAPI', 'customSettingCache', function($scope, $http, $window, $filter, messager, common, schema, schemaAPI, $fileUploader, partnerAPI, stationAPI, customSettingCache) {
      var pageName;
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'mapper';
      $scope.viewError = false;
      $scope.belongId = null;
      $scope.belongType = null;
      $scope.getCustomSetting = function() {
        if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
          return customSettingCache.RefreshData($scope.setViewSetting, common.currentOrganization.Id);
        } else {
          return $scope.setViewSetting();
        }
      };
      $scope.setViewSetting = function() {
        $scope.schema.ViewIndustry = customSettingCache.GetSettingName(customSettingCache.CategoryName.Industry, $scope.schema.Industry);
        $scope.schema.ViewTransactionType = customSettingCache.GetSettingName(customSettingCache.CategoryName.TransactionType, $scope.schema.TransactionType);
        $scope.belongId = $scope.currentItem.OwnerID;
        $scope.belongType = $scope.currentItem.OwnerType;
        $scope.loadBelongTo = true;
        return $scope.initViewObject();
      };
      $scope.showLoading = false;
      $scope.initData = function() {
        return schemaAPI.search({
          file: true,
          retrypolicy: true,
          id: $scope.schemaId
        }, function(response) {
          if (response && response.Succeeded) {
            if (response.SchemaList && response.SchemaList.length > 0) {
              $scope.currentItem = response.SchemaList[0];
              $scope.schema = angular.copy(response.SchemaList[0]);
              schema.viewItem = angular.copy(response.SchemaList[0]);
              if ($scope.schema.FileList && $scope.schema.FileList.length > 0) {
                $scope.schemaFile = angular.copy($scope.schema.FileList[0]);
              }
              return $scope.promise = $scope.getCustomSetting();
            } else {
              schema.viewItem = void 0;
              return $scope.viewError = true;
            }
          } else {
            return common.ShowAPIError('Get schema data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get schema data failed', error.data);
        });
      };
      $scope.initViewObject = function() {
        var retryEnabled;
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.currentItem.InUser;
        $scope.generalView.InDate = $scope.currentItem.InDate;
        $scope.generalView.EditUser = $scope.currentItem.EditUser;
        $scope.generalView.EditDate = $scope.currentItem.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Industry', $scope.schema.ViewIndustry));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Transaction Type', $scope.schema.ViewTransactionType));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Schema File', $scope.schemaFile.OriginalName, true, ['downloadView', 'url'], [true, $scope.schemaFile.Url]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Schema Name', $scope.schema.Name));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Document Root', $scope.schema.DocumentRoot));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Name Space', $scope.schema.Namespace));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Description', $scope.schema.Description));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Schema Type', $scope.schema.SchemaType));
        $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
        if ($scope.schema.Policy) {
          $scope.retryView = common.buildViewObject('Auto Retry Setting');
          retryEnabled = 'No';
          if ($scope.schema.Policy.AutoRetryEnabled === true) {
            retryEnabled = 'Yes';
          }
          $scope.retryView.viewAttList.push(common.buildViewAttr('Automatic Retry Enabled', retryEnabled));
          $scope.retryView.viewAttList.push(common.buildViewAttr('Max Retry Count', $scope.schema.Policy.MaxRetryCount));
          $scope.retryView.viewAttList.push(common.buildViewAttr('Retry Interval (Seconds)', $scope.schema.Policy.RetryInterval));
          return $scope.retryView.viewAttList = common.clearAttrListNullValue($scope.retryView.viewAttList);
        }
      };
      pageName = common.currentRoutePath();
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
        $scope.schemaId = common.current.link[pageName].pageParameter.Id;
        $scope.authItem = angular.copy(common.current.link[pageName].pageParameter);
        $scope.promise = $scope.initData();
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        $scope.schema = angular.copy(schema.viewItem);
        if ($scope.schema) {
          $scope.authItem = angular.copy(schema.viewItem);
          $scope.currentItem = angular.copy(schema.viewItem);
          if ($scope.schema.FileList && $scope.schema.FileList.length > 0) {
            $scope.schemaFile = angular.copy($scope.schema.FileList[0]);
          }
          $scope.schemaId = $scope.currentItem.Id;
          $scope.promise = $scope.initData();
        } else {
          $scope.viewError = true;
        }
      } else {
        common.navigate('schema');
      }
      return $scope.editSchema = function() {
        schema.editItem.Schema = angular.copy($scope.schema);
        return common.navigate('schema/edit');
      };
    }
  ]);

}).call(this);
