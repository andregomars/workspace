﻿
angular.module('eaas-edit-schema', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/schema/edit", {
      templateUrl: "/modules/eaas/app/schema/edit-schema.tpl.html",
      controller: 'EaaSEditSchemaCtrl'
    });
  }
]).controller('EaaSEditSchemaCtrl', [
  "$scope", "$http", "$window", "$filter", "messager", "common", "schema", "schemaAPI", '$fileUploader', 'partnerAPI', 'stationAPI', 'customSettingCache', function($scope, $http, $window, $filter, messager, common, schema, schemaAPI, $fileUploader, partnerAPI, stationAPI, customSettingCache) {
    var pageName, uploader;
    if (!schema.editItem.Schema || !schema.editItem.Schema.Id) {
      common.navigate('schema');
    }
    common.initUnSavedConfirm($scope);
    $scope.transferObj = {
      isSucceed: true,
      action: 'edit',
      objName: 'schema',
      title: 'Schema has been updated successfully'
    };
    $scope.common = common;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization'
    };
    pageName = common.currentRoutePath();
    $scope.initStationOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link.station.Name;
      return $scope.owner.Type = common.current.link.station.PartnerType + ' Station';
    };
    $scope.initPartnerOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        $scope.initStationOwnerInfo();
      } else {
        if (common.current.link[pageName].pageParameter.Partner) {
          $scope.initPartnerOwnerInfo();
        }
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      }
    }
    $scope.enableChooseStation = true;
    $scope.enableChoosePartner = true;
    $scope.belongId = null;
    $scope.belongType = null;
    $scope.loadBelongTo = false;
    $scope.fromPageNavigate = function() {
      if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner && common.current.link[pageName].pageParameter.Station) {
        $scope.belongType = 'Station';
        $scope.belongId = common.current.link[pageName].pageParameter.Station.Id;
        $scope.enableChoosePartner = false;
        $scope.enableChooseStation = false;
      } else {
        if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          $scope.belongType = 'Partner';
          $scope.belongId = common.current.link[pageName].pageParameter.Partner.Id;
          $scope.enableChoosePartner = false;
        } else {
          $scope.belongType = $scope.schema.OwnerType;
          $scope.belongId = $scope.schema.OwnerID;
        }
      }
      $scope.autoSetOwnerInfo = false;
      return $scope.loadBelongTo = true;
    };
    $scope.initPolicy = function() {
      $scope.schema.Policy = {};
      $scope.schema.Policy.MaxRetryCount = 3;
      return $scope.schema.Policy.RetryInterval = 300;
    };
    $scope.initData = function() {
      var response;
      return response = schemaAPI.search({
        file: true,
        retrypolicy: true,
        id: schema.editItem.Schema.Id
      }, function() {
        if (response && response.Succeeded && response.SchemaList && response.SchemaList.length > 0) {
          $scope.currentItem = response.SchemaList[0];
          $scope.schema = angular.copy(response.SchemaList[0]);
          if ($scope.schema.FileList && $scope.schema.FileList.length > 0) {
            $scope.schemaFile = angular.copy($scope.schema.FileList[0]);
          }
          if ($scope.schema && !$scope.schema.Policy) {
            $scope.initPolicy();
          }
          $scope.$watch("schema.Policy.AutoRetryEnabled", (function() {
            if ($scope.schema.Policy.AutoRetryEnabled === false) {
              $scope.schema.Policy.MaxRetryCount = 3;
              return $scope.schema.Policy.RetryInterval = 300;
            }
          }), true);
          return $scope.promise = $scope.getCustomSetting();
        } else {
          return common.ShowAPIError('Get schema data failed.', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get schema data failed.', error.data);
      });
    };
    $scope.promise = $scope.initData();
    $scope.getCustomSetting = function() {
      if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
        return customSettingCache.RefreshData($scope.HandleCustomeSettingDisplay, common.currentOrganization.Id);
      } else {
        return $scope.HandleCustomeSettingDisplay();
      }
    };
    $scope.HandleCustomeSettingDisplay = function() {
      $scope.industryList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.Industry));
      $scope.transactionTypeDicList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TransactionType));
      $scope.nameSpaceList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TargetNamespace));
      $scope.IndustryChanged(false);
      return $scope.fromPageNavigate();
    };
    $scope.schemaFile = {};
    $scope.changeUploadFile = false;
    $scope.changeUpload = function(change) {
      $scope.changeUploadFile = change;
      if (change === false) {
        return $scope.schemaFile = angular.copy(schema.editItem.Schema.FileList[0]);
      }
    };
    $scope.IndustryChanged = function(isSync) {
      $scope.transactionTypeList = [];
      $scope.transactionTypeList = $filter('filter')($scope.transactionTypeDicList, {
        industryCodeType: $scope.schema.Industry
      });
      if (isSync) {
        if ($scope.transactionTypeList.length < 1) {
          return $scope.schema.TransactionType = null;
        } else {
          return $scope.schema.TransactionType = $scope.transactionTypeList[0].Code;
        }
      }
    };
    $scope.save = function() {
      var requestDataModel;
      if ($scope.schemaForm.$valid) {
        $scope.schema.OrganizationID = common.currentOrganization.Id;
        $scope.schema.OwnerType = $scope.belongType;
        $scope.schema.OwnerID = $scope.belongId;
        $scope.schema.FileList = [];
        $scope.schema.FileList.push($scope.schemaFile);
        requestDataModel = {};
        requestDataModel.Schema = $scope.schema;
        return schemaAPI.edit(requestDataModel, function(result) {
          $scope.isSubmit = false;
          if (result.Succeeded === true) {
            $scope.transferObj.obj = result.SchemaList[0];
            return common.navigate('transfer', $scope.transferObj);
          } else {
            return common.ShowAPIError('Edit schema failed', result);
          }
        }, function(error) {
          common.ShowAPIError('Edit schema failed', error.data);
          return $scope.isSubmit = false;
        });
      } else {
        return $scope.isSubmit = false;
      }
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=mapper.xslt&filetype=mapper&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = true;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) !== 'xsd') {
            valid = false;
          }
          if (valid === false) {
            messager.error("A schema file must have an extension \".xsd\", please select a valid schema file.");
          }
          $scope.schemaFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        $scope.schemaFile.Url = msg.File.Url;
        $scope.schemaFile.OriginalName = msg.File.OriginalName;
        $scope.schemaFile.Size = msg.File.Size;
        $scope.schemaFile.SubType = 'Main';
        $scope.schemaFile.Hash = msg.File.Hash;
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        messager.error("Upload file failed.");
        return $scope.isSubmit = false;
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.schemaFile = {};
      $scope.isSubmit = false;
      if (msg && msg.data) {
        return common.ShowAPIError('Upload file failed.', msg.data);
      } else {
        return common.ShowAPIError('Upload file failed.', msg);
      }
    });
    uploader.bind('clearAll', function(event, item) {
      debugger;
    });
    return $scope.submit = function() {
      if ($scope.changeUploadFile && $scope.uploadValid === false) {
        messager.error("Please choose correct file to upload.");
        return;
      }
      if ($scope.changeUploadFile && (!uploader.queue || uploader.queue.length < 1)) {
        messager.error("Please choose schema file to upload.");
        return;
      }
      if (!$scope.schema.TransactionType) {
        messager.error("Please choose a transaction type.");
        return;
      }
      $scope.isSubmit = true;
      if ($scope.schemaForm.$valid && $scope.changeUploadFile) {
        uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.schemaFile.OriginalName + "&filetype=schema&format=json";
        return uploader.uploadAll();
      } else {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      }
    };
  }
]);
