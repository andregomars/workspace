﻿
angular.module('eaas-schema', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/schema", {
      templateUrl: "/modules/eaas/app/schema/schema.tpl.html",
      controller: 'EaaSSchemaCtrl'
    });
  }
]).controller('EaaSSchemaCtrl', [
  "$scope", "messager", "$window", "common", "schema", "schemaAPI", 'customSettingCache', function($scope, messager, $window, common, schema, schemaAPI, customSettingCache) {
    var pageName;
    $scope.query = angular.copy(schema.query);
    $scope.isBackPage = common.current.isBackPage;
    if (common.current.isBackPage === false) {
      $scope.query.queryFieldList = [
        {
          text: 'Name',
          value: 'name'
        }, {
          text: 'Industry',
          value: 'industry'
        }, {
          text: 'Transaction Type',
          value: 'transactionType'
        }, {
          text: 'Document Root',
          value: 'documentRoot'
        }, {
          text: 'Namespace',
          value: 'namespace'
        }
      ];
      $scope.query.queryField = 'name';
      $scope.query.schemaType = null;
      common.InitQueryFields($scope.query);
    }
    $scope.query.pageSize = common.getPageSize(410, 145);
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization'
    };
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.common = common;
    pageName = common.currentRoutePath();
    $scope.initPartnerOwnerInfo = function() {
      $scope.query.ownerID = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.query.ownerType = 'Partner';
      $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
    };
    $scope.initStationOwnerInfo = function() {
      $scope.query.ownerID = common.current.link[pageName].pageParameter.Station.Id;
      $scope.query.ownerType = 'Station';
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Station.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Station.PartnerType + ' Station';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        $scope.initStationOwnerInfo();
      } else {
        if (common.current.link[pageName].pageParameter.Partner) {
          $scope.initPartnerOwnerInfo();
        }
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      }
    } else {
      $scope.query.ownerID = null;
      $scope.query.ownerType = null;
      common.current.link[pageName] = null;
      schema.reset();
    }
    $scope.add = function() {
      if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        return common.navigate('schema/create', {
          Station: common.current.link[pageName].pageParameter.Station,
          Partner: common.current.link[pageName].pageParameter.Partner
        });
      } else {
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          return common.navigate('schema/create', {
            Partner: common.current.link[pageName].pageParameter.Partner
          });
        } else {
          return common.navigate('schema/create');
        }
      }
    };
    $scope.showLoading = true;
    $scope.search = function() {
      var requestItem, response;
      $scope.message = 'Loading...';
      requestItem = angular.copy($scope.query);
      schema.query = angular.copy($scope.query);
      common.clearQueryParameter(requestItem);
      return response = schemaAPI.search(requestItem, function() {
        if (response && response.Succeeded) {
          $scope.query.totalItems = response.TotalRecordCount;
          $scope.data = response.SchemaList;
          schema.data = response.SchemaList;
          $scope.getCustomSetting();
          common.loadOwnerInfo($scope.data);
          return $scope.getAllFileInfo();
        } else {
          return common.ShowAPIError('Get schema data failed.', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get schema data failed.', error.data);
      });
    };
    $scope.getCustomSetting = function() {
      if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
        return customSettingCache.RefreshData($scope.setViewSetting, common.currentOrganization.Id);
      } else {
        return $scope.setViewSetting();
      }
    };
    $scope.setViewSetting = function() {
      var index, _results;
      _results = [];
      for (index in $scope.data) {
        $scope.data[index].ViewIndustry = customSettingCache.GetSettingName(customSettingCache.CategoryName.Industry, $scope.data[index].Industry);
        _results.push($scope.data[index].ViewTransactionType = customSettingCache.GetSettingName(customSettingCache.CategoryName.TransactionType, $scope.data[index].TransactionType));
      }
      return _results;
    };
    $scope.getAllFileInfo = function() {
      var index, _results;
      _results = [];
      for (index in $scope.data) {
        _results.push($scope.getFileInfo($scope.data[index]));
      }
      return _results;
    };
    $scope.getFileInfo = function(item) {
      return common.fileResourceObtainer.getFileList('Schema', item);
    };
    $scope.pageChanged = function(page) {
      $scope.query.currentPage = page;
      $scope.query.startpageindex = page - 1;
      $scope.query.endpageindex = page - 1;
      return $scope.promise = $scope.search();
    };
    $scope.showPagination = function() {
      return $scope.query.totalItems > $scope.query.pageSize;
    };
    $scope.promise = $scope.search();
    $scope.filter = function(type) {
      $scope.query.schemaType = type;
      $scope.query.currentPage = 1;
      return $scope.pageChanged(1);
    };
    $scope.advancedSearch = function() {
      $scope.query.currentPage = 1;
      return $scope.pageChanged(1);
    };
    $scope.remove = function(entity) {
      return common.ConfirmBox("Are you sure you want to permanently remove the schema \"" + entity.Name + "\" ?", null, function() {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.removeSchema(entity);
      });
    };
    $scope.removeSchema = function(entity) {
      var response;
      return response = schemaAPI.remove({
        id: entity.Id
      }, function() {
        if (response && response.Succeeded) {
          messager.success("Remove schema successfully.");
          return $scope.promise = $scope.search();
        } else {
          return common.ShowAPIError('Remove schema  failed.', response);
        }
      }, function(error) {
        return common.ShowAPIError('Remove schema  failed.', error.data);
      });
    };
    return $scope.edit = function(editItem) {
      schema.editItem.Schema = editItem;
      if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        return common.navigate('schema/edit', {
          Station: common.current.link[pageName].pageParameter.Station,
          Partner: common.current.link[pageName].pageParameter.Partner
        });
      } else {
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          return common.navigate('schema/edit', {
            Partner: common.current.link[pageName].pageParameter.Partner
          });
        } else {
          return common.navigate('schema/edit');
        }
      }
    };
  }
]);
