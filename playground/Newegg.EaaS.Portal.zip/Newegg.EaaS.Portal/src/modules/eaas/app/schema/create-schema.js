﻿
angular.module('eaas-create-schema', ['ngRoute']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/schema/create", {
      templateUrl: "/modules/eaas/app/schema/create-schema.tpl.html",
      controller: 'EaaSCreateSchemaCtrl'
    });
  }
]).controller('EaaSCreateSchemaCtrl', [
  "$scope", "$fileUploader", "$filter", "messager", "common", "schema", "schemaAPI", 'partnerAPI', 'stationAPI', 'customSettingCache', function($scope, $fileUploader, $filter, messager, common, schema, schemaAPI, partnerAPI, stationAPI, customSettingCache) {
    var pageName, uploader;
    $scope.transferObj = {
      isSucceed: true,
      action: 'create',
      objName: 'schema',
      title: 'Schema has been created successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.schemaFile = {};
    $scope.uploadValid = false;
    $scope.schema = {};
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.schema.SchemaType = "Local";
    $scope.common = common;
    $scope.IndustryChanged = function() {
      $scope.transactionTypeList = [];
      $scope.transactionTypeList = $filter('filter')($scope.transactionTypeDicList, {
        industryCodeType: $scope.schema.Industry
      });
      if ($scope.transactionTypeList && $scope.transactionTypeList.length < 1) {
        return $scope.schema.TransactionType = null;
      } else {
        if ($scope.transactionTypeList && $scope.transactionTypeList.length > 0) {
          return $scope.schema.TransactionType = $scope.transactionTypeList[0].Code;
        }
      }
    };
    $scope.owner = {
      Id: common.currentOrganization.Id,
      Name: common.currentOrganization.Name,
      Type: 'Organization'
    };
    pageName = common.currentRoutePath();
    $scope.initStationOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Station.Id;
      $scope.owner.Name = common.current.link.station.Name;
      return $scope.owner.Type = common.current.link.station.PartnerType + ' Station';
    };
    $scope.initPartnerOwnerInfo = function() {
      $scope.owner.Id = common.current.link[pageName].pageParameter.Partner.Id;
      $scope.owner.Name = common.current.link[pageName].pageParameter.Partner.Name;
      return $scope.owner.Type = common.current.link[pageName].pageParameter.Partner.Type + ' Partner';
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
        $scope.initStationOwnerInfo();
      } else {
        if (common.current.link[pageName].pageParameter.Partner) {
          $scope.initPartnerOwnerInfo();
        }
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Station && common.current.link[pageName].pageParameter.Partner) {
          $scope.initStationOwnerInfo();
        } else {
          if (common.current.link[pageName].pageParameter.Partner) {
            $scope.initPartnerOwnerInfo();
          }
        }
      }
    }
    $scope.enableChooseStation = true;
    $scope.enableChoosePartner = true;
    $scope.belongId = null;
    $scope.belongType = null;
    $scope.loadBelongTo = false;
    $scope.setOwnerByUerRole = true;
    $scope.fromPageNavigate = function() {
      if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner && common.current.link[pageName].pageParameter.Station) {
        $scope.belongType = 'Station';
        $scope.belongId = common.current.link[pageName].pageParameter.Station.Id;
        $scope.autoSetOwnerInfo = false;
        $scope.setOwnerByUerRole = false;
        $scope.loadBelongTo = true;
        $scope.enableChoosePartner = false;
        return $scope.enableChooseStation = false;
      } else {
        if (common.current && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter.Partner) {
          $scope.belongType = 'Partner';
          $scope.belongId = common.current.link[pageName].pageParameter.Partner.Id;
          $scope.autoSetOwnerInfo = false;
          $scope.setOwnerByUerRole = false;
          $scope.loadBelongTo = true;
          return $scope.enableChoosePartner = false;
        } else {
          $scope.autoSetOwnerInfo = true;
          return $scope.loadBelongTo = true;
        }
      }
    };
    $scope.initPolicy = function() {
      $scope.schema.Policy = {};
      $scope.schema.Policy.MaxRetryCount = 3;
      return $scope.schema.Policy.RetryInterval = 300;
    };
    $scope.initPolicy();
    $scope.$watch("schema.Policy.AutoRetryEnabled", (function() {
      if ($scope.schema.Policy.AutoRetryEnabled === false) {
        $scope.schema.Policy.MaxRetryCount = 3;
        return $scope.schema.Policy.RetryInterval = 300;
      }
    }), true);
    $scope.getCustomSetting = function() {
      if (customSettingCache.HasCache(common.currentOrganization.Id) === false) {
        return customSettingCache.RefreshData($scope.HandleCustomeSettingDisplay, common.currentOrganization.Id);
      } else {
        return $scope.HandleCustomeSettingDisplay();
      }
    };
    $scope.HandleCustomeSettingDisplay = function() {
      $scope.industryList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.Industry));
      $scope.transactionTypeDicList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TransactionType));
      $scope.nameSpaceList = angular.copy(customSettingCache.GetSettingCache(customSettingCache.CategoryName.TargetNamespace));
      if ($scope.industryList && $scope.industryList.length > 0) {
        $scope.schema.Industry = $scope.industryList[0].Code;
      }
      if ($scope.nameSpaceList && $scope.nameSpaceList.length > 0) {
        $scope.schema.Namespace = $scope.nameSpaceList[0].Value;
      }
      $scope.IndustryChanged();
      return $scope.fromPageNavigate();
    };
    $scope.promise = $scope.getCustomSetting();
    $scope.save = function() {
      var requestDataModel;
      if ($scope.schemaForm.$valid) {
        $scope.schema.OrganizationID = common.currentOrganization.Id;
        $scope.schema.OwnerType = $scope.belongType;
        $scope.schema.OwnerID = $scope.belongId;
        if ($scope.schema.SchemaType === 'Local') {
          $scope.schema.Namespace = null;
        }
        $scope.schema.FileList = [];
        $scope.schema.FileList.push($scope.schemaFile);
        $scope.schemaFile.OwnerType = common.ownerType.schema;
        $scope.schemaFile.OwnerID = 0;
        requestDataModel = {};
        requestDataModel.Schema = $scope.schema;
        return schemaAPI.create(requestDataModel, function(result) {
          $scope.isSubmit = false;
          if (result.Succeeded === true) {
            $scope.transferObj.obj = result.SchemaList[0];
            return common.navigate('transfer', $scope.transferObj);
          } else {
            return common.ShowAPIError('Create schema failed', result);
          }
        }, function(error) {
          $scope.isSubmit = false;
          return common.ShowAPIError('Create partner failed', error.data);
        });
      }
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=schema.xsd&filetype=schema&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = true;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) !== 'xsd') {
            valid = false;
          }
          if (valid === false) {
            messager.error("A schema file must have an extension \".xsd\", please select a valid schema file.");
          }
          $scope.schemaFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        $scope.schemaFile.Url = msg.File.Url;
        $scope.schemaFile.OriginalName = msg.File.OriginalName;
        $scope.schemaFile.Size = msg.File.Size;
        $scope.schemaFile.SubType = 'Main';
        $scope.schemaFile.Hash = msg.File.Hash;
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        messager.error("Upload file failed.");
        return $scope.isSubmit = false;
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.schemaFile = {};
      $scope.isSubmit = false;
      if (msg && msg.data) {
        return common.ShowAPIError('Upload file failed.', msg.data);
      } else {
        return common.ShowAPIError('Upload file failed.', msg);
      }
    });
    return $scope.submit = function() {
      if ($scope.uploadValid === false) {
        messager.error("Please choose correct file to upload.");
        return;
      }
      if (!uploader.queue || uploader.queue.length < 1) {
        messager.error("Please choose schema file to upload.");
        return;
      }
      if (!$scope.schema.TransactionType) {
        messager.error("Please choose a transaction type.");
        return;
      }
      if ($scope.schemaForm.$valid) {
        $scope.isSubmit = true;
        uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.schemaFile.OriginalName + "&filetype=schema&format=json";
        return uploader.uploadAll();
      }
    };
  }
]);
