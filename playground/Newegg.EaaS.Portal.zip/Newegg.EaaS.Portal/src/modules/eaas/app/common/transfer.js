﻿(function() {

  angular.module('eaas-transfer', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/transfer", {
        templateUrl: "/modules/eaas/app/common/transfer.tpl.html",
        controller: 'EaaSTransferCtrl'
      });
    }
  ]).controller('EaaSTransferCtrl', [
    "$scope", "$interval", "$location", "messager", "common", '$rootScope', function($scope, $interval, $location, messager, common, $rootScope) {
      common.current.isBackPage = false;
      if (!common.current.link[common.currentRoutePath()]) {
        $location.path('/');
      }
      $scope.current = common.current.link[common.currentRoutePath()].pageParameter;
      $scope.secondsLabel = 'seconds';
      if (!$scope.current) {
        $location.path('/');
      }
      if (common.currentUser && common.currentUser.UserRole === 'Partner' && $scope.current.objName === 'station' && $scope.current.action === 'create') {
        common.loadStationIDListByCurrentUser(common.currentUser);
      }
      $scope.common = common;
      $scope.seconds = 15;
      $scope.autoJump = function() {
        if ($scope.seconds < 3) {
          $scope.secondsLabel = 'second';
          $scope.$apply();
        }
        if ($scope.seconds === 0) {
          $scope.$on('$destroy', $interval.cancel($rootScope.timer));
          if ($scope.current.objName === 'station') {
            return common.navigate($scope.current.objName, {
              Partner: common.current.link['/station'].pageParameter.Partner
            });
          } else {
            return common.navigate($scope.current.objName, {});
          }
        } else {
          return $scope.seconds--;
        }
      };
      $rootScope.timer = $interval($scope.autoJump, 1000);
      $scope.showHomeLink = function() {
        if (common.currentUser.Type === common.userRole.superUser && !common.currentOrganization) {
          return false;
        }
        return true;
      };
      $scope.showListLink = function() {
        if ($scope.current.objName === 'organization' && common.currentOrganization) {
          return false;
        }
        return true;
      };
      return $scope.link = function(type) {
        $scope.$on('$destroy', $interval.cancel($rootScope.timer));
        if (type === 'new') {
          common.current.isBackPage = true;
          return $location.path($scope.current.objName + '/' + $scope.current.action, {});
        } else if (type === 'list') {
          if ($scope.current.objName === 'organization') {
            return common.navigate($scope.current.objName);
          } else {
            common.current.isBackPage = true;
            return $location.path($scope.current.objName, {});
          }
        } else if (type === 'station-partner') {
          return common.navigate('station', {
            Partner: $scope.current.obj
          });
        } else if (type === 'home') {
          common.current.isBackPage = true;
          return $location.path('', {});
        } else if (type === 'detail') {
          if ($scope.current.objName === 'organization') {
            return common.navigate($scope.current.objName + '/detail', {
              OrganId: $scope.current.obj.Id
            });
          } else {
            return common.navigate($scope.current.objName + '/view', {
              Id: $scope.current.obj.Id,
              InUser: $scope.current.obj.InUser,
              Type: $scope.current.obj.Type,
              LocalStationID: $scope.current.obj.LocalStationID
            });
          }
        }
      };
    }
  ]);

}).call(this);
