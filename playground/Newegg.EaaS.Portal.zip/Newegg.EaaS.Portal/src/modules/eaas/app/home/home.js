(function() {

  angular.module('eaas-home', ['ngRoute', 'pascalprecht.translate']).config([
    "$translateProvider", function($translateProvider) {
      return $translateProvider.translations('en-us', resources.eaas.home.en).translations('zh-ch', resources.eaas.home.zh);
    }
  ]).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/", {
        templateUrl: "/modules/eaas/app/home/home.tpl.html",
        controller: 'EaaSHomeCtrl'
      });
    }
  ]).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/index", {
        templateUrl: "/modules/eaas/app/home/home.tpl.html",
        controller: 'EaaSHomeCtrl'
      });
    }
  ]).controller('EaaSHomeCtrl', [
    "$scope", "$location", "$http", "progress", "messager", "common", "partner", "partnerAPI", "agreement", "agreementAPI", "actionLogAPI", '$q', function($scope, $location, $http, progress, messager, common, partner, partnerAPI, agreement, agreementAPI, actionLogAPI, $q) {
      $scope.common = common;
      $scope.query = {};
      $scope.query.pagesize = 10;
      $scope.query.startpageindex = 0;
      $scope.query.endpageindex = 0;
      $scope.query.sortfield = 'EditDate,InDate';
      $scope.query.sorttype = 'desc';
      if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
      }
      $scope.searchRecentAddPartner = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.type = null;
        $scope.query.pagesize = 10;
        $scope.query.sortfield = 'InDate';
        $scope.query.sorttype = 'desc';
        partnerAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.partnerCount = result.TotalRecordCount;
            $scope.addPartnerList = result.PartnerList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get partner data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get partner data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchRecentEditPartner = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.type = null;
        $scope.query.pagesize = 10;
        $scope.query.sortfield = 'EditDate';
        $scope.query.sorttype = 'desc';
        partnerAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.partnerCount = result.TotalRecordCount;
            $scope.editPartnerList = result.PartnerList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get partner data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get partner data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchLocalPartner = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.type = 'Local';
        $scope.query.pagesize = 1;
        $scope.query.sortfield = null;
        partnerAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.localPartnerCount = result.TotalRecordCount + ' Local partners';
            $scope.localPartnerList = result.PartnerList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get partner data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get partner data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchTradingPartner = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.type = 'Trading';
        $scope.query.sortfield = null;
        $scope.query.pagesize = 1;
        partnerAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.tradingPartnerCount = result.TotalRecordCount + ' Trading partners';
            $scope.tradingPartnerList = result.PartnerList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get partner data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get partner data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchRecentEditAgreement = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.pagesize = 10;
        $scope.query.sortfield = 'EditDate';
        $scope.query.sorttype = 'desc';
        agreementAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.agreementCount = result.TotalRecordCount + ' Agreements';
            $scope.editAgreementList = result.AgreementList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get agreement data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get agreement data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchRecentAddAgreement = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.pagesize = 10;
        $scope.query.sortfield = 'InDate';
        $scope.query.sorttype = 'desc';
        agreementAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.agreementCount = result.TotalRecordCount + ' Agreements';
            $scope.addAgreementList = result.AgreementList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get agreement data failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get agreement data failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchActionLog = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.type = null;
        $scope.query.pagesize = 10;
        $scope.query.sortfield = 'InDate';
        $scope.query.sorttype = 'desc';
        actionLogAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.actionCount = result.TotalRecordCount;
            $scope.actionList = result.ActionLogList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get activity log failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get activity log failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      $scope.searchFailedActionLog = function() {
        var deferred;
        deferred = $q.defer();
        $scope.showLoading = true;
        $scope.query.type = null;
        $scope.query.pagesize = 10;
        $scope.query.sortfield = 'InDate';
        $scope.query.sorttype = 'desc';
        $scope.query.status = 'failed';
        actionLogAPI.search($scope.query, function(result) {
          if (result && result.Succeeded) {
            $scope.failedActionCount = result.TotalRecordCount;
            $scope.failedActionList = result.ActionLogList;
            return deferred.resolve(null);
          } else {
            return deferred.reject({
              msg: 'Get activity log failed.',
              errorMsg: result
            });
          }
        }, function(error) {
          $scope.showLoading = false;
          return deferred.reject({
            msg: 'Get activity log failed.',
            errorMsg: error.data
          });
        });
        return deferred.promise;
      };
      return $q.all([$scope.searchLocalPartner(), $scope.searchTradingPartner(), $scope.searchRecentAddPartner(), $scope.searchRecentAddAgreement(), $scope.searchRecentEditPartner(), $scope.searchRecentEditAgreement(), $scope.searchActionLog(), $scope.searchFailedActionLog()]).then(function(results) {
        return null;
      }, function(error) {
        debugger;        if (error.errorMsg && error.errorMsg.data) {
          return common.ShowAPIError(error.msg, error.errorMsg.data);
        } else {
          return common.ShowAPIError(error.msg, error.errorMsg);
        }
      });
    }
  ]);

}).call(this);
