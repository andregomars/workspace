﻿
angular.module('eaas-partner', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/partner", {
      templateUrl: "/modules/eaas/app/partner/partner.tpl.html",
      controller: 'EaaSPartnerCtrl'
    });
  }
]).controller('EaaSPartnerCtrl', [
  "$scope", "$location", "$filter", "messager", "common", "partner", 'partnerAPI', 'station', 'stationAPI', function($scope, $location, $filter, messager, common, partner, partnerAPI, station, stationAPI) {
    var pageName;
    $scope.common = common;
    $scope.query = angular.copy(partner.query);
    $scope.isBackPage = common.current.isBackPage;
    if (common.current.isBackPage === false) {
      $scope.query.queryFieldList = [
        {
          text: 'Name',
          value: 'name'
        }, {
          text: 'Description',
          value: 'description'
        }
      ];
      $scope.query.queryField = 'name';
      $scope.query.type = null;
      common.InitQueryFields($scope.query);
    }
    $scope.query.pageSize = common.getPageSize(410, 120);
    $scope.query.hasActivePartner = true;
    $scope.query.hasDeactivePartner = true;
    $scope.template = 'template1.html';
    pageName = common.currentRoutePath();
    $scope.initPageParameter = function() {
      if (common.current.link[pageName].pageParameter.Name) {
        $scope.query.name = common.current.link[pageName].pageParameter.Name;
      }
      if (common.current.link[pageName].pageParameter.Type) {
        $scope.query.type = common.current.link[pageName].pageParameter.Type;
      }
      if (common.current.link[pageName].pageParameter.Status) {
        return $scope.query.status = common.current.link[pageName].pageParameter.Status;
      }
    };
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      $scope.initPageParameter();
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        $scope.initPageParameter();
      }
    }
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.pageChanged = function(page) {
      $scope.query.currentPage = page;
      $scope.query.startpageindex = page - 1;
      $scope.query.endpageindex = page - 1;
      return $scope.promise = $scope.search();
    };
    $scope.showPagination = function() {
      return $scope.query.totalItems > $scope.query.pageSize;
    };
    $scope.search = function() {
      var requestItem;
      $scope.message = 'Loading...';
      if (($scope.query.hasActivePartner === true && $scope.query.hasDeactivePartner === true) || ($scope.query.hasActivePartner === false && $scope.query.hasDeactivePartner === false)) {
        delete $scope.query.status;
      } else {
        if ($scope.query.hasActivePartner === true) {
          $scope.query.status = 'Active';
        } else {
          $scope.query.status = 'Deactive';
        }
      }
      requestItem = angular.copy($scope.query);
      partner.query = angular.copy($scope.query);
      common.clearQueryParameter(requestItem);
      return partnerAPI.search(requestItem, function(result) {
        var index, _results;
        if (result && result.Succeeded) {
          $scope.query.totalItems = result.TotalRecordCount;
          $scope.partnerList = result.PartnerList;
          _results = [];
          for (index in $scope.partnerList) {
            $scope.loadCountInfo($scope.partnerList[index]);
            _results.push($scope.queryStation($scope.partnerList[index]));
          }
          return _results;
        } else {
          return common.ShowAPIError('Get partner data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get partner data failed.', error.data);
      });
    };
    $scope.queryStation = function(item) {
      var response;
      return response = stationAPI.search({
        partnerid: item.Id
      }, function() {
        if (response && response.Succeeded && response.StationList !== null) {
          return item.StationCount = response.StationList.length;
        }
      });
    };
    $scope.loadCountInfo = function(item) {
      var queryModel, transmissionQueryModel;
      if (item.Type !== 'Local') {
        return;
      }
      queryModel = {
        ownerID: item.Id,
        ownerType: 'Partner'
      };
      transmissionQueryModel = {
        ownerID: item.Id,
        ownerType: 'Partner',
        encodingprotocol: false
      };
      common.resourceStatisticsObtainer.getSchemaStatistics('SchemaCount', queryModel, item);
      common.resourceStatisticsObtainer.getMapperStatistics('MapperCount', queryModel, item);
      return common.resourceStatisticsObtainer.getTransmissionStatistics('TransmissionCount', transmissionQueryModel, item);
    };
    $scope.loadStationCount = function() {
      var index, _results;
      if ($scope.partnerList !== null) {
        _results = [];
        for (index in $scope.partnerList) {
          _results.push($scope.queryStation($scope.partnerList[index]));
        }
        return _results;
      }
    };
    $scope.filter = function(type) {
      $scope.filterType = type;
      if (type === 'all') {
        $scope.query.type = null;
        if (common.current.link[pageName] && common.current.link[pageName].pageParameter) {
          common.current.link[pageName].pageParameter.Type = null;
        }
      } else {
        $scope.query.type = type;
      }
      return $scope.advancedSearch();
    };
    $scope.advancedSearch = function() {
      $scope.query.currentPage = 1;
      return $scope.pageChanged(1);
    };
    $scope.filterType = "all";
    if ($scope.query.type) {
      $scope.filterType = $scope.query.type;
    }
    $scope.promise = $scope.search();
    $scope.searchActive = function(partner) {
      if (partner.Status === 'Active') {
        return true;
      }
      return false;
    };
    $scope.changeStatus = function(partner) {
      var additionalMsg, msgForActivate, msgForDeactive, op;
      op = (partner.Status === "Active" ? "deactivate" : "activate");
      msgForDeactive = "If you deactivate a partner which is exchanging business data with other partners, no more data will be processed for this partner.";
      msgForActivate = "If you activate a partner which has agreement with other partner correctly configured and activated, it will start to process the incoming and outgoing data.";
      additionalMsg = (partner.Status === "Active" ? msgForDeactive : msgForActivate);
      return common.ConfirmBox("Do you want to " + op + " the partner \"" + partner.Name + "\"?", additionalMsg, function() {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.changePartnerStatus(partner);
      });
    };
    $scope.changePartnerStatus = function(partner) {
      var opStatus, orignalStatus, requestEntity;
      orignalStatus = partner.Status;
      opStatus = '';
      requestEntity = {};
      requestEntity.id = partner.Id;
      if (partner.Status === "Active") {
        requestEntity.action = "disable";
        opStatus = 'deactivated';
      } else {
        requestEntity.action = "enable";
        opStatus = 'activated';
      }
      return partnerAPI.updateStatus(requestEntity, function(result) {
        if (result.Succeeded) {
          messager.success("Partner \"" + partner.Name + "\" has been " + opStatus + " successfully.");
          return $scope.promise = $scope.search();
        } else {
          return common.ShowAPIError("Change the status of \"" + partner.Name + "\" failed.", result);
        }
      }, function(error) {
        return common.ShowAPIError("Change the status of \"" + partner.Name + "\" failed.", error.data);
      });
    };
    $scope.navigate = function(url) {
      return common.navigate(url);
    };
    $scope.navigateResource = function(url, item) {
      return common.navigate(url, {
        Partner: item
      });
    };
    $scope.navigatePartnerConfig = function(url, currentPartner) {
      common.current.link.status = 'partner';
      common.current.link.partner = currentPartner;
      return common.navigate(url);
    };
    $scope.edit = function(url, currentPartner) {
      partner.editItem = currentPartner;
      return common.navigate(url);
    };
    $scope.remove = function(entity) {
      return common.ConfirmBox("Do you want to remove the partner \"" + entity.Name + "\"?", "If the partner contains stations or has agreement with other partners, it cannot be removed.", function() {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.removePartner(entity);
      });
    };
    return $scope.removePartner = function(entity) {
      return partnerAPI.remove({
        id: entity.Id
      }, function(response) {
        if (response && response.Succeeded) {
          messager.success("Remove partner successfully.");
          return $scope.promise = $scope.search();
        } else {
          return common.ShowAPIError("Remove partner failed.", response);
        }
      }, function(error) {
        return common.ShowAPIError("Remove partner failed.", error.data);
      });
    };
  }
]);
