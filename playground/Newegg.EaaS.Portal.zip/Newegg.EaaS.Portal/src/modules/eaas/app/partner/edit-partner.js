﻿
angular.module('eaas-edit-partner', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/partner/edit", {
      templateUrl: "/modules/eaas/app/partner/edit-partner.tpl.html",
      controller: 'EaaSEditPartnerCtrl'
    });
  }
]).controller('EaaSEditPartnerCtrl', [
  "$scope", "$location", "messager", 'common', "partner", 'partnerAPI', 'certificateAPI', '$fileUploader', function($scope, $location, messager, common, partner, partnerAPI, certificateAPI, $fileUploader) {
    var uploader;
    if (!partner.editItem || !partner.editItem.Id) {
      common.navigate('partner');
    }
    $scope.transferObj = {
      isSucceed: true,
      action: 'edit',
      objName: 'partner',
      title: 'Partner has been updated successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.query = angular.copy(partner.query);
    $scope.query.contact = true;
    $scope.query.certificate = true;
    $scope.query.station = true;
    $scope.query.id = partner.editItem.Id;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.initData = function() {
      return partnerAPI.search({
        id: partner.editItem.Id,
        contact: true,
        certificate: true
      }, function(result) {
        if (result && result.Succeeded && result.PartnerList && result.PartnerList.length > 0) {
          partner.editItem = result.PartnerList[0];
          $scope.partner = angular.copy(partner.editItem);
          if ($scope.partner.Certificate) {
            $scope.partner.localCertificate = angular.copy($scope.partner.Certificate);
            $scope.partner.localCertificate.showValid = true;
            $scope.orignalCertificate = angular.copy($scope.partner.Certificate);
          } else {
            $scope.partner.localCertificate = {};
            $scope.partner.localCertificate.showValid = false;
            $scope.partner.localCertificate.Id = -1;
            $scope.orignalCertificate = angular.copy($scope.partner.localCertificate);
            $scope.partner.Certificate = {};
            $scope.partner.Certificate.Id = -1;
          }
          if ($scope.partner.ContactList && $scope.partner.ContactList.length > 0) {
            return $scope.partner.Contact = $scope.partner.ContactList[0];
          }
        } else {
          return common.ShowAPIError('Get partner data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get partner data failed.', error.data);
      });
    };
    $scope.promise = $scope.initData();
    $scope.selectCertificate = null;
    $scope.uploadCertificate = null;
    $scope.mapperFile = {};
    $scope.uploadFile = false;
    $scope.changeUpload = function(change) {
      $scope.uploadFile = change;
      if (change) {
        if ($scope.uploadCertificate && $scope.uploadCertificate.showValid && uploader.queue && uploader.queue.length > 0) {
          $scope.partner.localCertificate = angular.copy($scope.uploadCertificate);
        } else {
          $scope.partner.localCertificate = {
            showValid: false
          };
        }
      }
      if (change === false) {
        if ($scope.selectCertificate !== null) {
          return $scope.partner.localCertificate = angular.copy($scope.selectCertificate);
        } else {
          $scope.partner.localCertificate = angular.copy($scope.partner.Certificate);
          $scope.partner.localCertificate.showValid = true;
          if ($scope.partner.localCertificate.Id === -1) {
            return $scope.partner.localCertificate.showValid = false;
          }
        }
      }
    };
    $scope.save = function() {
      var requestDataModel, temp_purpose;
      if ($scope.partnerForm.$valid) {
        if ($scope.partner.localCertificate && $scope.partner.localCertificate.showValid && $scope.partner.localCertificate.Id !== -1) {
          if ($scope.uploadFile) {
            if ($scope.password) {
              $scope.partner.localCertificate.Password = $scope.password;
            }
            $scope.partner.localCertificate.FileList = [];
            $scope.partner.localCertificate.FileList.push($scope.mapperFile);
          }
          $scope.partner.Certificate = $scope.partner.localCertificate;
          if ($scope.partner.localCertificate.Id) {
            $scope.partner.CertificateID = $scope.partner.localCertificate.Id;
          }
        } else {
          if ($scope.uploadFile && uploader.queue && uploader.queue.length < 1 && $scope.orignalCertificate && $scope.orignalCertificate.Id !== -1) {
            $scope.partner.Certificate = null;
            $scope.partner.CertificateID = $scope.orignalCertificate.Id;
          } else {
            $scope.partner.CertificateID = null;
            $scope.partner.Certificate = null;
          }
        }
        if ($scope.partner.localCertificate && $scope.partner.localCertificate.Id && $scope.partner.CertificateID === $scope.partner.localCertificate.Id) {
          $scope.partner.Certificate = null;
        }
        if ($scope.partner.Certificate && $scope.partner.Certificate.Id === -1) {
          $scope.partner.Certificate = null;
          $scope.partner.CertificateID = null;
        }
        $scope.partner.ContactList = [];
        if ($scope.partner.Contact) {
          $scope.partner.ContactList.push($scope.partner.Contact);
        }
        requestDataModel = {};
        requestDataModel.Partner = angular.copy($scope.partner);
        if (requestDataModel.Partner.Contact) {
          delete requestDataModel.Partner.Contact;
        }
        if (requestDataModel.Partner.localCertificate) {
          delete requestDataModel.Partner.localCertificate;
        }
        if (requestDataModel.Partner.Certificate && !requestDataModel.Partner.Certificate.Id) {
          temp_purpose = 'Signature';
          if ($scope.partner.Type === 'Trading') {
            temp_purpose = 'Encryption';
          }
          requestDataModel.Partner.Certificate.Purpose = temp_purpose;
          delete requestDataModel.Partner.CertificateID;
        }
        if (requestDataModel.Partner.LocalCertificate) {
          delete requestDataModel.Partner.LocalCertificate;
        }
        return partnerAPI.edit(requestDataModel, function(result) {
          $scope.isSubmit = false;
          if (result.Succeeded) {
            $scope.transferObj.obj = result.PartnerList[0];
            return common.navigate('transfer', $scope.transferObj);
          } else {
            if (uploader.queue && uploader.queue.length > 0) {
              uploader.queue[0].isUploaded = false;
            }
            $scope.partner.Certificate = angular.copy($scope.orignalCertificate);
            return common.ShowAPIError('Edit Partner Failed', result);
          }
        }, function(error) {
          if (uploader.queue && uploader.queue.length > 0) {
            uploader.queue[0].isUploaded = false;
          }
          $scope.partner.Certificate = angular.copy($scope.orignalCertificate);
          common.ShowAPIError('Edit Partner Failed', error.data);
          return $scope.isSubmit = false;
        });
      }
    };
    if (common.currentUser.Type === common.userRole.stationUser) {
      $scope.filterType = common.userRole.stationUser;
      $scope.filterId = common.currentUser.StationID;
    } else if (common.currentUser.Type === common.userRole.partnerUser) {
      $scope.filterType = common.userRole.partnerUser;
      $scope.filterId = common.currentUser.PartnerID;
    } else {
      $scope.filterType = null;
      $scope.filterId = null;
    }
    $scope.getCertificateData = function() {
      var response;
      $scope.CertificateList = null;
      $scope.showCertificateLoading = true;
      $scope.purpose = 'Signature';
      if ($scope.partner.Type === 'Trading') {
        $scope.purpose = 'Encryption';
      }
      return response = certificateAPI.search({
        purpose: $scope.purpose
      }, function() {
        $scope.showCertificateLoading = false;
        if (response && response.Succeeded) {
          $scope.CertificateList = response.CertificateList;
          if ($scope.filterType === common.userRole.stationUser) {
            return $scope.promiseCertificate = common.GetStationInfo($scope.filterId, null, $scope.onLoadStationComplete);
          } else if ($scope.filterType === common.userRole.partnerUser) {
            return $scope.promiseCertificate = common.GetPartnerInfo($scope.filterId, $scope.onLoadPartnerComplete);
          } else {
            $scope.CertificateList = common.sortResourceList($scope.CertificateList, common.userRole.organizationUser);
            $scope.initCertificateData();
            return $scope.syncCertificateData();
          }
        } else {
          return common.ShowAPIError('Get certificate data failed', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get certificate data failed', error.data);
      });
    };
    $scope.onLoadPartnerComplete = function(partnerList) {
      if (partnerList.length > 0) {
        $scope.filterPartnerId = partnerList[0].Id;
        return $scope.promiseCertificate = common.GetStationInfo(null, $scope.filterPartnerId, $scope.onLoadStationComplete);
      } else {
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      }
    };
    $scope.onLoadStationComplete = function(stationList) {
      if (stationList.length > 0) {
        $scope.filterStationList = stationList;
        $scope.filterPartnerId = stationList[0].PartnerID;
        $scope.filterCertificateListByRole();
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      } else {
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      }
    };
    $scope.filterCertificateListByRole = function() {
      var certificate, filterList, index, index2;
      filterList = [];
      for (index in $scope.CertificateList) {
        certificate = $scope.CertificateList[index];
        if (certificate.OwnerType === 'Organization') {
          filterList.push(certificate);
        } else if (certificate.OwnerType === 'Partner') {
          if ($scope.filterType && certificate.OwnerID === $scope.filterPartnerId) {
            filterList.push(certificate);
          }
        } else if (certificate.OwnerType === 'Station') {
          if ($scope.filterType) {
            for (index2 in $scope.filterStationList) {
              if ($scope.filterStationList[index2].Id === certificate.OwnerID) {
                filterList.push(certificate);
              }
            }
          }
        }
      }
      return $scope.CertificateList = common.sortResourceList(filterList, $scope.filterType);
    };
    $scope.filterUsedCertificate = function(certificate) {
      if (certificate.OwnerType === 'Partner' && certificate.OwnerID === $scope.partner.Id) {
        return certificate.show = true;
      }
    };
    $scope.initCertificateData = function() {
      var index, _results;
      $scope.filterCertificateList = $scope.CertificateList;
      _results = [];
      for (index in $scope.CertificateList) {
        $scope.CertificateList[index].selected = false;
        $scope.CertificateList[index].show = true;
        if (common.validateCertificate($scope.CertificateList[index]) === false) {
          $scope.CertificateList[index].show = false;
          continue;
        }
        if ($scope.CertificateList[index].IsUsed === true) {
          $scope.CertificateList[index].show = false;
        }
        _results.push($scope.filterUsedCertificate($scope.CertificateList[index]));
      }
      return _results;
    };
    $scope.singleSelect = function(certificate) {
      var index, _results;
      _results = [];
      for (index in $scope.CertificateList) {
        if ($scope.CertificateList[index].Id === certificate.Id) {
          continue;
        } else {
          _results.push($scope.CertificateList[index].selected = false);
        }
      }
      return _results;
    };
    $scope.syncCertificateData = function() {
      var certificate;
      if ($scope.partner.localCertificate) {
        certificate = $scope.getSelectedCertificateById($scope.partner.localCertificate.Id);
        if (certificate) {
          certificate.show = true;
          return certificate.selected = true;
        }
      }
    };
    $scope.getSelectedCertificateById = function(id) {
      var index;
      for (index in $scope.CertificateList) {
        if ($scope.CertificateList[index].Id === id) {
          return $scope.CertificateList[index];
        }
      }
    };
    $scope.chooseCertificate = function() {
      var certificate;
      certificate = $scope.getUserSelectedCertificate();
      if ((!certificate.Id || certificate.Id === $scope.partner.Certificate.Id) && certificate.Id !== -1) {
        certificate = $scope.partner.Certificate;
        certificate.showValid = true;
        $scope.partner.localCertificate = certificate;
        $scope.selectCertificate = angular.copy(certificate);
        return $scope.addCertificateModal = false;
      } else if (certificate.Id === -1) {
        $scope.partner.localCertificate = certificate;
        $scope.selectCertificate = angular.copy(certificate);
        return $scope.addCertificateModal = false;
      } else {
        return certificateAPI.search({
          file: true,
          id: certificate.Id
        }, function(response) {
          var fullCertificate;
          if (response && response.Succeeded) {
            if (response.CertificateList && response.CertificateList.length > 0) {
              fullCertificate = response.CertificateList[0];
              fullCertificate.showValid = certificate.showValid;
              $scope.partner.localCertificate = fullCertificate;
              $scope.selectCertificate = angular.copy(fullCertificate);
              return $scope.addCertificateModal = false;
            }
          } else {
            return common.ShowAPIError('Get certificate data failed', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get certificate data failed', error.data);
        });
      }
    };
    $scope.closeCertificateDialog = function() {
      return $scope.addCertificateModal = false;
    };
    $scope.openCertificateDialog = function() {
      $scope.addCertificateModal = true;
      return $scope.promiseCertificate = $scope.getCertificateData();
    };
    $scope.getUserSelectedCertificate = function() {
      var certificate, index;
      certificate = {
        showValid: false,
        Id: -1
      };
      for (index in $scope.CertificateList) {
        if ($scope.CertificateList[index].selected === true) {
          $scope.CertificateList[index].showValid = true;
          certificate = $scope.CertificateList[index];
        }
      }
      return certificate;
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=certificate.cer&filetype=certificate&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = true;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) !== 'cer' && item.name.slice(item.name.lastIndexOf('.') + 1) !== 'pfx' && item.name.slice(item.name.lastIndexOf('.') + 1) !== 'p12') {
            valid = false;
            messager.error("File extension name must be cer or pfx or p12.");
          }
          if (valid === true && (item.name.slice(item.name.lastIndexOf('.') + 1) === 'pfx' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'p12')) {
            messager.info("For PFX or P12 certificate, usually this kind of certificate is containning private key which is protected by a password, to create a certificate based on these files, the password must be provided.");
          }
          $scope.mapperFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        if (common.validateCertificate(msg.Certificate) === false) {
          uploader.queue[0].isUploaded = false;
          messager.error("The certificate file is expired.");
          $scope.isSubmit = false;
          return;
        }
        if (msg.Certificate.Status !== 'Valid') {
          messager.info("The certificate file will be expired in 30 days.");
        }
        $scope.mapperFile.Url = msg.File.Url;
        $scope.mapperFile.OriginalName = msg.File.OriginalName;
        $scope.mapperFile.Size = msg.File.Size;
        $scope.mapperFile.SubType = 'Main';
        $scope.mapperFile.Hash = msg.File.Hash;
        $scope.uploadCertificate = {};
        $scope.uploadCertificate.Subject = msg.Certificate.Subject;
        $scope.uploadCertificate.ThumbPrint = msg.Certificate.ThumbPrint;
        $scope.uploadCertificate.ValidFrom = msg.Certificate.ValidFrom;
        $scope.uploadCertificate.ValidTo = msg.Certificate.ValidTo;
        $scope.uploadCertificate.IssueBy = msg.Certificate.IssueBy;
        $scope.uploadCertificate.IssueTo = msg.Certificate.IssueTo;
        $scope.uploadCertificate.showValid = true;
        $scope.partner.localCertificate = angular.copy($scope.uploadCertificate);
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        $scope.isSubmit = false;
        if (msg.Errors && msg.Errors.length > 0 && msg.Certificate) {
          return messager.error(msg.Errors[0].Message + '<br/>ThumbPrint:' + msg.Certificate.ThumbPrint);
        } else {
          return messager.error("The certificate file is not correct.");
        }
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.mapperFile = {};
      messager.error("Upload file failed.");
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      if (msg.data) {
        return common.ShowAPIError('Upload file Failed', msg.data);
      } else {
        return common.ShowAPIError('Upload file Failed', msg);
      }
    });
    uploader.bind('afteraddingfile', function(event, item) {
      return $scope.partner.localCertificate = {
        showValid: false
      };
    });
    uploader.bind('clearAll', function(event, item) {
      if (uploader.queue && uploader.queue.length === 0) {
        $scope.uploadCertificate = {};
        $scope.uploadCertificate.showValid = false;
        return $scope.partner.localCertificate = angular.copy($scope.uploadCertificate);
      }
    });
    return $scope.submit = function() {
      debugger;      if ($scope.partnerForm.$valid) {
        $scope.isSubmit = true;
        if ($scope.uploadFile && uploader.queue && uploader.queue.length > 0) {
          if ($scope.password) {
            uploader.queue[0].url = common.apiURL.upload + "?password=" + $scope.password + "&fullname=" + $scope.mapperFile.OriginalName + "&filetype=certificate&format=json";
          } else {
            uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.mapperFile.OriginalName + "&filetype=certificate&format=json";
          }
          return uploader.uploadAll();
        } else {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.save();
        }
      }
    };
  }
]);
