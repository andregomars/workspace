﻿(function() {

  angular.module('eaas-view-partner', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/partner/view", {
        templateUrl: "/modules/eaas/app/partner/view-partner.tpl.html",
        controller: 'EaaSViewPartnerCtrl'
      });
    }
  ]).controller('EaaSViewPartnerCtrl', [
    "$scope", "$http", "$window", "$filter", "messager", "common", "partner", "mapperAPI", '$fileUploader', 'partnerAPI', 'stationAPI', 'certificateAPI', function($scope, $http, $window, $filter, messager, common, partner, mapperAPI, $fileUploader, partnerAPI, stationAPI, certificateAPI) {
      var pageName;
      $scope.common = common;
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.errorTitle = 'partner';
      $scope.viewError = false;
      $scope.initViewCertificateObject = function() {
        $scope.certificateView = common.buildViewObject('Public Certificate');
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Certificate File', $scope.partner.localCertificate.FileList[0].OriginalName, true, ['downloadView', 'url'], [true, $scope.partner.localCertificate.FileList[0].Url]));
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Subject', $scope.partner.localCertificate.Subject));
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Thumbprint', $scope.partner.localCertificate.Thumbprint));
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Issued to', $scope.partner.localCertificate.IssueTo));
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Issued by', $scope.partner.localCertificate.IssueBy));
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Valid from', $scope.partner.localCertificate.ValidFrom, true, ['momentView'], [true]));
        $scope.certificateView.viewAttList.push(common.buildViewAttr('Valid to', $scope.partner.localCertificate.ValidTo, true, ['momentView'], [true]));
        return $scope.certificateView.viewAttList = common.clearAttrListNullValue($scope.certificateView.viewAttList);
      };
      $scope.initViewObject = function() {
        $scope.generalView = common.buildViewObject('General Information');
        $scope.generalView.InUser = $scope.partner.InUser;
        $scope.generalView.InDate = $scope.partner.InDate;
        $scope.generalView.EditUser = $scope.partner.EditUser;
        $scope.generalView.EditDate = $scope.partner.EditDate;
        $scope.generalView.viewAttList.push(common.buildViewAttr('Status', $scope.partner.Status, true, ['statusView'], [true]));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Name', $scope.partner.Name));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Description', $scope.partner.Description));
        $scope.generalView.viewAttList.push(common.buildViewAttr('Type', $scope.partner.Type));
        $scope.generalView.viewAttList = common.clearAttrListNullValue($scope.generalView.viewAttList);
        if ($scope.partner.Contact) {
          $scope.contactView = common.buildViewObject('Contact Information');
          $scope.contactView.viewAttList.push(common.buildViewAttr('Name', $scope.partner.Contact.Name));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Company', $scope.partner.Contact.Company));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Job Title', $scope.partner.Contact.JobTitle));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Email', $scope.partner.Contact.Email, true, ['mailView'], [true]));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Business Phone', $scope.partner.Contact.BusinessPhone));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Mobile Phone', $scope.partner.Contact.MobilePhone));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Fax', $scope.partner.Contact.Fax));
          $scope.contactView.viewAttList.push(common.buildViewAttr('Address', $scope.partner.Contact.Address));
          $scope.contactView.viewAttList = common.clearAttrListNullValue($scope.contactView.viewAttList);
        }
        $scope.belongView = common.buildViewObject('Belongs To');
        $scope.belongView.viewAttList.push(common.buildViewAttr('Organization', common.currentOrganization.Name));
        return $scope.belongView.viewAttList = common.clearAttrListNullValue($scope.belongView.viewAttList);
      };
      $scope.getCetrificateFile = function(certificateId) {
        return certificateAPI.search({
          file: true,
          id: certificateId
        }, function(response) {
          if (response && response.Succeeded) {
            if (response.CertificateList && response.CertificateList.length > 0) {
              $scope.partner.localCertificate = response.CertificateList[0];
            }
            return $scope.initViewCertificateObject();
          } else {
            return common.ShowAPIError("Get certificate data failed.", response);
          }
        }, function(error) {
          return common.ShowAPIError("Get certificate data failed.", error.data);
        });
      };
      $scope.getItemInfo = function() {
        return partnerAPI.search({
          id: $scope.partnerId,
          contact: true,
          certificate: true
        }, function(result) {
          if (result && result.Succeeded) {
            if (result.PartnerList && result.PartnerList.length > 0) {
              $scope.partner = result.PartnerList[0];
              $scope.currentItem = result.PartnerList[0];
              partner.viewItem = angular.copy(result.PartnerList[0]);
              if ($scope.partner.ContactList && $scope.partner.ContactList.length > 0) {
                $scope.partner.Contact = $scope.partner.ContactList[0];
              }
              $scope.initViewObject();
              if ($scope.partner.Certificate) {
                $scope.partner.localCertificate = angular.copy($scope.partner.Certificate);
                return $scope.promise = $scope.getCetrificateFile($scope.partner.localCertificate.Id);
              }
            } else {
              $scope.viewError = true;
              return partner.viewItem = void 0;
            }
          } else {
            return common.ShowAPIError('Get partner data failed', result);
          }
        }, function(error) {
          return common.ShowAPIError('Get partner data failed', error.data);
        });
      };
      pageName = common.currentRoutePath();
      if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.Id) {
        $scope.partnerId = common.current.link[pageName].pageParameter.Id;
        $scope.promise = $scope.getItemInfo();
        $scope.authItem = {
          Id: $scope.partnerId,
          InUser: common.current.link[pageName].pageParameter.InUser,
          Type: common.current.link[pageName].pageParameter.Type
        };
      } else if (common.current.isBackPage === true) {
        common.current.isBackPage = false;
        $scope.partner = angular.copy(partner.viewItem);
        if ($scope.partner) {
          $scope.authItem = angular.copy(partner.viewItem);
          $scope.currentItem = angular.copy(partner.viewItem);
          if ($scope.partner.ContactList && $scope.partner.ContactList.length > 0) {
            $scope.partner.Contact = $scope.partner.ContactList[0];
          }
          $scope.initViewObject();
          if ($scope.partner.Certificate) {
            $scope.partner.localCertificate = angular.copy($scope.partner.Certificate);
            $scope.promise = $scope.getCetrificateFile($scope.partner.localCertificate.Id);
          }
        } else {
          $scope.viewError = true;
        }
      } else {
        common.navigate('partner');
      }
      return $scope.edit = function() {
        partner.editItem = $scope.partner;
        return common.navigate('partner/edit');
      };
    }
  ]);

}).call(this);
