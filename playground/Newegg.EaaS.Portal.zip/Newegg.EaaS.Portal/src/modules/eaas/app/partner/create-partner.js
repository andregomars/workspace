﻿
angular.module('eaas-create-partner', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/partner/create", {
      templateUrl: "/modules/eaas/app/partner/create-partner.tpl.html",
      controller: 'EaaSCreatePartnerCtrl'
    });
  }
]).controller('EaaSCreatePartnerCtrl', [
  "$scope", "$location", "messager", 'common', "partner", 'partnerAPI', 'certificateAPI', '$fileUploader', function($scope, location, messager, common, partner, partnerAPI, certificateAPI, $fileUploader) {
    var uploader;
    $scope.transferObj = {
      isSucceed: true,
      action: 'create',
      objName: 'partner',
      title: 'Partner has been created successfully'
    };
    common.initUnSavedConfirm($scope);
    $scope.common = common;
    $scope.partner = {};
    $scope.partner.Type = 'Local';
    $scope.partner.Certificate = {
      showValid: false
    };
    $scope.selectCertificate = null;
    $scope.uploadCertificate = null;
    $scope.isSubmit = false;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    if (common.currentUser.UserRole === common.userRole.partnerUser || common.currentUser.UserRole === common.userRole.stationUser) {
      $scope.partner.Type = 'Trading';
    }
    $scope.certificateFile = {};
    $scope.uploadFile = false;
    $scope.changeUpload = function(change) {
      $scope.uploadFile = change;
      if (change) {
        if ($scope.uploadCertificate && $scope.uploadCertificate.showValid && uploader.queue && uploader.queue.length > 0) {
          $scope.partner.Certificate = angular.copy($scope.uploadCertificate);
        } else {
          $scope.partner.Certificate = {
            showValid: false
          };
        }
      }
      if (change === false) {
        if ($scope.selectCertificate !== null) {
          return $scope.partner.Certificate = angular.copy($scope.selectCertificate);
        } else {
          return $scope.partner.Certificate = {
            showValid: false
          };
        }
      }
    };
    $scope.save = function() {
      var requestDataModel, temp_purpose;
      if ($scope.partnerForm.$valid) {
        $scope.partner.Status = 'Active';
        $scope.partner.OrganizationID = common.currentOrganization.Id;
        $scope.partner.ContactList = [];
        if ($scope.partner.Contact) {
          $scope.partner.ContactList.push($scope.partner.Contact);
        }
        if ($scope.partner.Certificate && $scope.partner.Certificate.showValid) {
          if ($scope.uploadFile) {
            if ($scope.password) {
              $scope.certificateFile.Password = $scope.password;
            }
            $scope.partner.Certificate.FileList = [];
            $scope.partner.Certificate.FileList.push($scope.certificateFile);
          }
          if ($scope.partner.Certificate.Id) {
            $scope.partner.CertificateID = $scope.partner.Certificate.Id;
          }
        } else {
          $scope.partner.Certificate = null;
        }
        $scope.partner.StationList = [];
        requestDataModel = {};
        requestDataModel.Partner = angular.copy($scope.partner);
        if (requestDataModel.Partner.Contact) {
          delete requestDataModel.Partner.Contact;
        }
        if (requestDataModel.Partner.Certificate && !requestDataModel.Partner.CertificateID) {
          temp_purpose = 'Signature';
          if ($scope.partner.Type === 'Trading') {
            temp_purpose = 'Encryption';
          }
          requestDataModel.Partner.Certificate.Purpose = temp_purpose;
        }
        if (requestDataModel.Partner.CertificateID && requestDataModel.Partner.Certificate) {
          delete requestDataModel.Partner.Certificate;
        }
        return partnerAPI.create(requestDataModel, function(result) {
          debugger;          if (result.Succeeded) {
            $scope.transferObj.obj = result.PartnerList[0];
            common.navigate('transfer', $scope.transferObj);
          } else {
            if (uploader.queue && uploader.queue.length > 0) {
              uploader.queue[0].isUploaded = false;
            }
            common.ShowAPIError('Create Partner Failed', result);
          }
          return $scope.isSubmit = false;
        }, function(error) {
          debugger;          if (uploader.queue && uploader.queue.length > 0) {
            uploader.queue[0].isUploaded = false;
          }
          $scope.isSubmit = false;
          return common.ShowAPIError('Create Partner Failed', error.data);
        });
      }
    };
    if (common.currentUser.Type === common.userRole.stationUser) {
      $scope.filterType = common.userRole.stationUser;
      $scope.filterId = common.currentUser.StationID;
    } else if (common.currentUser.Type === common.userRole.partnerUser) {
      $scope.filterType = common.userRole.partnerUser;
      $scope.filterId = common.currentUser.PartnerID;
    } else {
      $scope.filterType = null;
      $scope.filterId = null;
    }
    $scope.getCertificateData = function() {
      var response;
      $scope.CertificateList = null;
      $scope.purpose = 'Signature';
      if ($scope.partner.Type === 'Trading') {
        $scope.purpose = 'Encryption';
      }
      return response = certificateAPI.search({
        purpose: $scope.purpose,
        isUsed: false
      }, function() {
        if (response && response.Succeeded) {
          $scope.CertificateList = response.CertificateList;
          if ($scope.filterType === common.userRole.stationUser) {
            return $scope.promiseCertificate = common.GetStationInfo($scope.filterId, null, $scope.onLoadStationComplete);
          } else if ($scope.filterType === common.userRole.partnerUser) {
            return $scope.promiseCertificate = common.GetPartnerInfo($scope.filterId, $scope.onLoadPartnerComplete);
          } else {
            $scope.CertificateList = common.sortResourceList($scope.CertificateList, common.userRole.organizationUser);
            $scope.initCertificateData();
            return $scope.syncCertificateData();
          }
        } else {
          return common.ShowAPIError('Get certificate data failed', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get certificate data failed', error.data);
      });
    };
    $scope.onLoadPartnerComplete = function(partnerList) {
      if (partnerList.length > 0) {
        $scope.filterPartnerId = partnerList[0].Id;
        return $scope.promiseCertificate = common.GetStationInfo(null, $scope.filterPartnerId, $scope.onLoadStationComplete);
      } else {
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      }
    };
    $scope.onLoadStationComplete = function(stationList) {
      if (stationList.length > 0) {
        $scope.filterStationList = stationList;
        $scope.filterPartnerId = stationList[0].PartnerID;
        $scope.filterCertificateListByRole();
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      } else {
        $scope.initCertificateData();
        return $scope.syncCertificateData();
      }
    };
    $scope.filterCertificateListByRole = function() {
      var certificate, filterList, index, index2;
      filterList = [];
      for (index in $scope.CertificateList) {
        certificate = $scope.CertificateList[index];
        if (certificate.OwnerType === 'Organization') {
          filterList.push(certificate);
        } else if (certificate.OwnerType === 'Partner') {
          if ($scope.filterType && certificate.OwnerID === $scope.filterPartnerId) {
            filterList.push(certificate);
          }
        } else if (certificate.OwnerType === 'Station') {
          if ($scope.filterType) {
            for (index2 in $scope.filterStationList) {
              if ($scope.filterStationList[index2].Id === certificate.OwnerID) {
                filterList.push(certificate);
              }
            }
          }
        }
      }
      return $scope.CertificateList = common.sortResourceList(filterList, $scope.filterType);
    };
    $scope.filterUsedCertificate = function(certificate) {
      var index, _results;
      _results = [];
      for (index in $scope.filterCertificateList) {
        if ($scope.filterCertificateList[index].OwnerType === 'Partner' && $scope.filterCertificateList[index].ThumbPrint === certificate.ThumbPrint) {
          _results.push(certificate.show = false);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.initCertificateData = function() {
      var index, _results;
      $scope.filterCertificateList = $scope.CertificateList;
      _results = [];
      for (index in $scope.CertificateList) {
        $scope.CertificateList[index].selected = false;
        $scope.CertificateList[index].show = true;
        if (common.validateCertificate($scope.CertificateList[index]) === false) {
          $scope.CertificateList[index].show = false;
          continue;
        }
        if ($scope.CertificateList[index].IsUsed === true) {
          _results.push($scope.CertificateList[index].show = false);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };
    $scope.singleSelect = function(certificate) {
      var index, _results;
      _results = [];
      for (index in $scope.CertificateList) {
        if ($scope.CertificateList[index].Id === certificate.Id) {
          continue;
        } else {
          _results.push($scope.CertificateList[index].selected = false);
        }
      }
      return _results;
    };
    $scope.syncCertificateData = function() {
      var certificate;
      if ($scope.partner.Certificate) {
        certificate = $scope.getSelectedCertificateById($scope.partner.Certificate.Id);
        if (certificate) {
          return certificate.selected = true;
        }
      }
    };
    $scope.getSelectedCertificateById = function(id) {
      var index;
      for (index in $scope.CertificateList) {
        if ($scope.CertificateList[index].Id === id) {
          return $scope.CertificateList[index];
        }
      }
    };
    $scope.closeCertificateDialog = function() {
      var certificate, response;
      certificate = $scope.getUserSelectedCertificate();
      if (certificate.Id) {
        return response = certificateAPI.search({
          file: true,
          id: certificate.Id
        }, function() {
          var fullCertificate;
          if (response && response.Succeeded) {
            if (response.CertificateList && response.CertificateList.length > 0) {
              fullCertificate = response.CertificateList[0];
              fullCertificate.showValid = certificate.showValid;
              $scope.partner.Certificate = fullCertificate;
              $scope.selectCertificate = angular.copy(fullCertificate);
              return $scope.addCertificateModal = false;
            }
          } else {
            return common.ShowAPIError('Get certificate data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get certificate data failed.', error.data);
        });
      } else {
        $scope.partner.Certificate = certificate;
        $scope.selectCertificate = angular.copy(certificate);
        return $scope.addCertificateModal = false;
      }
    };
    $scope.hiddenCertificateDialog = function() {
      return $scope.addCertificateModal = false;
    };
    $scope.openCertificateDialog = function() {
      $scope.addCertificateModal = true;
      return $scope.promiseCertificate = $scope.getCertificateData();
    };
    $scope.getUserSelectedCertificate = function() {
      var certificate, index;
      certificate = {
        showValid: false
      };
      for (index in $scope.CertificateList) {
        if ($scope.CertificateList[index].selected === true) {
          $scope.CertificateList[index].showValid = true;
          certificate = $scope.CertificateList[index];
        }
      }
      return certificate;
    };
    $scope.uploadurl = common.apiURL.upload + "?fullname=certificate.cer&filetype=certificate&format=json";
    $scope.isCheckPassword = false;
    $scope.uploadHeader = common.initHeader(common.currentUser);
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = true;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) !== 'cer' && item.name.slice(item.name.lastIndexOf('.') + 1) !== 'pfx' && item.name.slice(item.name.lastIndexOf('.') + 1) !== 'p12') {
            valid = false;
            messager.error("File extension name must be cer or pfx or p12.");
          }
          if (valid === true && (item.name.slice(item.name.lastIndexOf('.') + 1) === 'pfx' || item.name.slice(item.name.lastIndexOf('.') + 1) === 'p12')) {
            messager.info("For PFX or P12 certificate, usually this kind of certificate is containning private key which is protected by a password, to create a certificate based on these files, the password must be provided.");
          }
          $scope.certificateFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        if (common.validateCertificate(msg.Certificate) === false) {
          messager.error("The certificate file is expired.");
          uploader.queue[0].isUploaded = false;
          $scope.isSubmit = false;
          return;
        }
        if (msg.Certificate.Status !== 'Valid') {
          messager.info("The certificate file will be expired in 30 days.");
        }
        $scope.certificateFile.Url = msg.File.Url;
        $scope.certificateFile.OriginalName = msg.File.OriginalName;
        $scope.certificateFile.Size = msg.File.Size;
        $scope.certificateFile.SubType = 'Main';
        $scope.certificateFile.Hash = msg.File.Hash;
        $scope.uploadCertificate = {};
        $scope.uploadCertificate.Subject = msg.Certificate.Subject;
        $scope.uploadCertificate.ThumbPrint = msg.Certificate.ThumbPrint;
        $scope.uploadCertificate.ValidFrom = msg.Certificate.ValidFrom;
        $scope.uploadCertificate.ValidTo = msg.Certificate.ValidTo;
        $scope.uploadCertificate.IssueBy = msg.Certificate.IssueBy;
        $scope.uploadCertificate.IssueTo = msg.Certificate.IssueTo;
        $scope.uploadCertificate.showValid = true;
        $scope.partner.Certificate = angular.copy($scope.uploadCertificate);
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        if (msg.Errors && msg.Errors.length > 0 && msg.Certificate) {
          messager.error(msg.Errors[0].Message + '<br/>ThumbPrint:' + msg.Certificate.ThumbPrint);
        } else {
          messager.error("The certificate file is not correct.");
        }
        return $scope.isSubmit = false;
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.certificateFile = {};
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      return common.ShowAPIError('Upload file Failed', msg);
    });
    uploader.bind('cancel', function(event, xhr, item, msg) {
      $scope.certificateFile = {};
      messager.error("Upload file failed.");
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      if (msg.data) {
        return common.ShowAPIError('Upload file Failed', msg.data);
      } else {
        return common.ShowAPIError('Upload file Failed', msg);
      }
    });
    uploader.bind('afteraddingfile', function(event, item) {});
    uploader.bind('clearAll', function(event, item) {
      if (uploader.queue && uploader.queue.length === 0) {
        return $scope.partner.Certificate = {
          showValid: false
        };
      }
    });
    return $scope.submit = function() {
      debugger;      if ($scope.partnerForm.$valid) {
        $scope.isSubmit = true;
        if ($scope.uploadFile && uploader.queue && uploader.queue.length > 0) {
          if ($scope.password) {
            uploader.queue[0].url = common.apiURL.upload + "?password=" + $scope.password + "&fullname=" + $scope.certificateFile.OriginalName + "&filetype=certificate&format=json";
          } else {
            uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.certificateFile.OriginalName + "&filetype=certificate&format=json";
          }
          return uploader.uploadAll();
        } else {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.save();
        }
      }
    };
  }
]);
