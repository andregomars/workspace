﻿(function() {

  angular.module('eaas-organization', ['ngRoute']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/organization", {
        templateUrl: "/modules/eaas/app/organization/organization.tpl.html",
        controller: 'organController'
      });
    }
  ]).controller('organController', [
    "$scope", "progress", "common", "organization", "organizationAPI", 'authAPI', '$http', 'messager', '$rootScope', '$window', function($scope, progress, common, organization, organizationAPI, authAPI, $http, messager, $rootScope, $window) {
      $scope.common = common;
      $scope.showLoading = true;
      $scope.query = angular.copy(organization.query);
      $scope.isBackPage = common.current.isBackPage;
      if (common.current.isBackPage === false) {
        $scope.query.queryFieldList = [
          {
            text: 'Name',
            value: 'name'
          }, {
            text: 'Description',
            value: 'description'
          }, {
            text: 'EDI Server',
            value: 'ediServer'
          }
        ];
        $scope.query.queryField = 'name';
        common.InitQueryFields($scope.query);
      }
      $scope.pageSize = common.getPageSize(400, 95);
      $scope.opOrgan = false;
      if (common.currentUser.Type === common.userRole.superUser && !common.currentOrganization) {
        $scope.opOrgan = true;
      }
      if (common.currentUser && common.currentUser.Type && common.currentUser.Type === common.userRole.superUser && common.currentOrganization && common.currentOrganization.IsAgent && common.currentOrganization.IsAgent === true) {
        $scope.agentOrganization = angular.copy(common.currentOrganization);
      }
      $scope.isNeedAgent = function() {
        if (common.currentUser.Type === common.userRole.superUser && common.currentOrganization && $scope.isNeedChooseAgent() === false) {
          return true;
        }
        return false;
      };
      $scope.isNeedChooseAgent = function() {
        if (common.currentUser.Type === common.userRole.superUser && common.currentOrganization !== null && common.currentOrganization.IsAgent && common.currentOrganization.IsAgent === true) {
          return true;
        }
        return false;
      };
      $scope.isAgent = function(organ) {
        if (common.currentUser.Type === common.userRole.superUser && common.currentOrganization === null) {
          return true;
        }
        return false;
      };
      $scope.pageBack = function() {
        if ($scope.isAgent()) {

        } else {
          return common.back();
        }
      };
      $scope.search = function() {
        var requestItem, response;
        $scope.data = null;
        $scope.message = 'Loading...';
        requestItem = angular.copy($scope.query);
        organization.query = angular.copy($scope.query);
        common.clearQueryParameter(requestItem);
        return response = organizationAPI.search(requestItem, function() {
          debugger;          if (response && response.Succeeded) {
            $scope.totalItems = response.TotalRecordCount;
            $scope.data = response.OrganizationList;
            return organization.data = response.OrganizationList;
          } else {
            return common.ShowAPIError('Get organization data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get organization data failed.', error.data);
        });
      };
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.pageChanged = function(page) {
        $scope.query.currentPage = page;
        $scope.query.startpageindex = page - 1;
        $scope.query.endpageindex = page - 1;
        return $scope.promise = $scope.search();
      };
      $scope.showPagination = function() {
        return $scope.query.totalItems > $scope.query.pageSize;
      };
      $scope.$on('ExitAgentSuccessed', function() {
        return $scope.promise = $scope.search();
      });
      $scope.$on('loginSuccessed', function() {
        if ($scope.isAgent() === false && common.currentUser.Type === common.userRole.superUser) {
          return common.navigate('organization/detail');
        }
      });
      $scope.advancedSearch = function() {
        $scope.query.currentPage = 1;
        return $scope.pageChanged(1);
      };
      $scope.view = function(item) {
        return common.navigate('organization/detail', {
          OrganId: item.Id
        });
      };
      $scope.initOrganList = function(organ) {
        var index, _results;
        _results = [];
        for (index in $scope.data) {
          if ($scope.data[index].Id === organ.Id) {
            continue;
          }
          _results.push($scope.data[index].agentDescription = null);
        }
        return _results;
      };
      $scope.agentOrgan = function(organ) {
        $scope.message = 'Processing...';
        return $scope.promise = $scope.agentRequest(organ);
      };
      $scope.agentRequest = function(organ) {
        organ.isAgentSubmit = true;
        return authAPI.request({
          action: 'agent',
          OrganizationID: organ.Id
        }, function(result) {
          organ.isAgentSubmit = false;
          if (result && result.Succeeded && result.Status === 'Successful') {
            common.setUserToken(result.AuthorizationToken);
            common.currentUser.ActualUserRole = common.userRole.superUser;
            common.currentUser.UserRole = common.userRole.organizationUser;
            common.currentOrganization = angular.copy(organ);
            common.currentOrganization.IsAgent = true;
            common.currentUser.OrganizationID = common.currentOrganization.Id;
            common.currentUser.AgentOrganizationID = common.currentOrganization.Id;
            common.saveUserInfo(common.currentUser);
            organization.viewItem = null;
            $scope.agentOrganization = common.currentOrganization;
            organ.agentDescription = '(Agent)';
            $scope.initOrganList(organ);
            $rootScope.UserAgent.chooseAgent = true;
            common.navigate('organization/detail');
            return messager.success("Now you are working as an agent administrator of " + common.currentOrganization.Name + ".<br />If you want to stop working as an agent, you can click on the user menu at the right-up corner of the page and select Exist " + common.currentOrganization.Name + " at any time.");
          } else {
            return common.ShowAPIError('Agent organization failed.', result);
          }
        }, function(error) {
          return common.ShowAPIError('Agent organization failed.', error.data);
        });
      };
      if ($scope.isAgent()) {
        if (common.current.isBackPage) {
          common.current.isBackPage = false;
        } else {
          organization.reset();
        }
        return $scope.promise = $scope.search();
      } else {
        if (common.current.isBackPage === true) {
          common.current.isBackPage = false;
          return $window.history.go(-1);
        } else {
          organization.viewItem = common.currentOrganization;
          return common.navigate('organization/detail');
        }
      }
    }
  ]);

}).call(this);
