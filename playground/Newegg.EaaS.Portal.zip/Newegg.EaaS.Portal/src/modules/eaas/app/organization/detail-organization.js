(function() {

  angular.module('eaas-view-organ', ['ngRoute', 'duScroll', 'angular-follow']).config([
    "$routeProvider", function($routeProvider) {
      return $routeProvider.when("/organization/detail", {
        templateUrl: "/modules/eaas/app/organization/detail-organization.tpl.html",
        controller: 'detailOrganCtrl'
      });
    }
  ]).controller('detailOrganCtrl', [
    "$scope", "common", "organization", 'certificateAPI', 'organizationAPI', 'loadbalanceAPI', 'messager', function($scope, common, organization, certificateAPI, organizationAPI, loadbalanceAPI, messager) {
      var pageName;
      $scope.common = common;
      pageName = common.currentRoutePath();
      $scope.delay = 0;
      $scope.minDuration = 0;
      $scope.message = 'Loading...';
      $scope.backdrop = true;
      $scope.promise = null;
      $scope.getCertificateInfo = function() {
        $scope.currentItem.SearchFile = true;
        return certificateAPI.search({
          file: true,
          id: $scope.currentItem.CertificateID
        }, function(result) {
          debugger;          $scope.currentItem.SearchFile = false;
          if (result && result.Succeeded) {
            return $scope.currentItem.DisplayCertificate = result.CertificateList[0];
          } else {
            common.ShowAPIError('Get certificate data failed.', result);
            return $scope.currentItem.CertificateID = null;
          }
        }, function(error) {
          $scope.currentItem.CertificateID = null;
          return common.ShowAPIError('Get certificate data failed.', error.data);
        });
      };
      $scope.edit = function() {
        return common.navigate('organization/edit', {
          Id: $scope.currentItem.Id
        });
      };
      $scope.enableEdit = function() {
        if (common.currentUser.Type === common.userRole.superUser) {
          return true;
        }
        if (common.currentUser.Type === common.userRole.organizationUser) {
          return true;
        }
        return false;
      };
      $scope.initData = function(id) {
        var response;
        if (id) {
          $scope.currentItem = {};
          $scope.currentItem.Id = id;
        } else {
          $scope.currentItem = angular.copy(organization.viewItem);
        }
        $scope.getLoadBalanceInfo();
        return response = organizationAPI.search({
          id: $scope.currentItem.Id,
          contact: true
        }, function() {
          debugger;          if (response && response.Succeeded) {
            if (response.OrganizationList && response.OrganizationList.length > 0) {
              $scope.currentItem = response.OrganizationList[0];
              organization.viewItem = null;
              if ($scope.currentItem.ContactList && $scope.currentItem.ContactList.length > 0) {
                $scope.currentItem.Contact = $scope.currentItem.ContactList[0];
              }
              if ($scope.currentItem.CertificateID) {
                return $scope.promise = $scope.getCertificateInfo();
              }
            }
          } else {
            return common.ShowAPIError('Get organization data failed.', response);
          }
        }, function(error) {
          return common.ShowAPIError('Get organization data failed.', error.data);
        });
      };
      $scope.getLoadBalanceInfo = function() {
        $scope.LoadBalanceServerList = null;
        return loadbalanceAPI.search({
          organizationID: $scope.currentItem.Id
        }, function(result) {
          if (result && result.Succeeded) {
            return $scope.LoadBalanceServerList = result.OrganizationServerList;
          } else {
            common.ShowAPIError('Get loadBalance data failed.', result);
            return $scope.LoadBalanceServerList = null;
          }
        }, function(error) {
          return common.ShowAPIError('Get loadBalance data failed.', error.data);
        });
      };
      $scope.operateOnlineOffline = function(serverInfo) {
        var operationStatus, requestEntry;
        operationStatus = serverInfo.Status === 'Online' ? 'Offline' : 'Online';
        requestEntry = {};
        if (operationStatus === 'Offline') {
          requestEntry = {
            organizationID: $scope.currentItem.Id,
            serverName: serverInfo.ServerName,
            status: operationStatus,
            isForced: true
          };
        } else {
          requestEntry = {
            organizationID: $scope.currentItem.Id,
            serverName: serverInfo.ServerName,
            status: operationStatus
          };
        }
        $scope.message = 'Processing...';
        return loadbalanceAPI.edit(requestEntry, function(result) {
          if (result && result.Succeeded) {
            messager.success("The server " + serverInfo.ServerName + " has been put to " + (operationStatus.toLowerCase()) + " successfully.");
            return $scope.getLoadBalanceInfo();
          } else {
            return common.ShowAPIError("Put " + serverInfo.ServerName + " to " + (operationStatus.toLowerCase()) + " failed.", result);
          }
        }, function(error) {
          return common.ShowAPIError("Put " + serverInfo.ServerName + " to " + (operationStatus.toLowerCase()) + " failed.", error.data);
        });
      };
      if (common.currentUser.Type === 'Supervisor' && !common.currentOrganization) {
        if (!organization.viewItem || !organization.viewItem.Id) {
          if (common.currentOrganization && common.currentOrganization.Id) {
            organization.viewItem = common.currentOrganization;
            $scope.promise = $scope.initData();
          } else if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.OrganId) {
            $scope.initData(common.current.link[pageName].pageParameter.OrganId);
          } else if (common.current.isBackPage === true && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.OrganId) {
            common.current.isBackPage === false;
            $scope.initData(common.current.link[pageName].pageParameter.OrganId);
          } else {
            common.navigate('organization');
          }
        } else {
          if (common.current.isBackPage === true) {
            common.current.isBackPage === false;
            $scope.promise = $scope.initData();
          } else if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter && common.current.link[pageName].pageParameter.OrganId) {
            $scope.initData(common.current.link[pageName].pageParameter.OrganId);
          } else {
            $scope.promise = $scope.initData();
          }
        }
      } else {
        if (!organization.viewItem || !organization.viewItem.Id) {
          if (common.currentOrganization && common.currentOrganization.Id) {
            organization.viewItem = common.currentOrganization;
            $scope.promise = $scope.initData();
          } else {
            common.navigate('organization');
          }
        } else {
          $scope.promise = $scope.initData();
        }
      }
      return $scope.OnlineOfflineClick = function(serverInfo) {
        var Msg, operationStatus;
        operationStatus = serverInfo.Status === 'Online' ? 'Offline' : 'Online';
        Msg = serverInfo.Status === 'Online' ? "Once the server is offline, it will stop receiving incoming and outgoing messages." : "Once the server is online, it will start to process incoming and outgoing messages.";
        return common.ConfirmBox("Are you sure you want to put this server " + (operationStatus.toLowerCase()) + "?", Msg, function() {
          return loadbalanceAPI.search({
            organizationID: $scope.currentItem.Id,
            serverName: serverInfo.ServerName
          }, function(result) {
            var currentServerInfo;
            if (result && result.Succeeded) {
              currentServerInfo = result.OrganizationServerList[0];
              if (serverInfo.Status === currentServerInfo.Status) {
                return $scope.operateOnlineOffline(serverInfo);
              } else {
                common.ShowAPIError("Current server status has changed, can not do " + (operationStatus.toLowerCase()) + ".", null);
                return $scope.getLoadBalanceInfo();
              }
            } else {
              common.ShowAPIError('Get loadBalance data failed.', result);
              return $scope.LoadBalanceServerList = null;
            }
          }, function(error) {
            return common.ShowAPIError('Get loadBalance data failed.', error.data);
          });
        });
      };
    }
  ]);

}).call(this);
