﻿
angular.module('eaas-edit-organization', ['ngRoute', 'pascalprecht.translate']).config([
  "$routeProvider", function($routeProvider) {
    return $routeProvider.when("/organization/edit", {
      templateUrl: "/modules/eaas/app/organization/edit-organization.tpl.html",
      controller: 'EaaSEditOrganizationCtrl'
    });
  }
]).controller('EaaSEditOrganizationCtrl', [
  "$scope", "$location", "messager", 'common', "organization", 'organizationAPI', 'certificateAPI', '$fileUploader', '$q', function($scope, location, messager, common, organization, organizationAPI, certificateAPI, $fileUploader, $q) {
    var pageName, uploader;
    $scope.common = common;
    $scope.delay = 0;
    $scope.minDuration = 0;
    $scope.message = 'Loading...';
    $scope.backdrop = true;
    $scope.promise = null;
    $scope.uploadurl = common.apiURL.upload + "?fullname=certificate.cer&filetype=certificate&format=json";
    $scope.uploadHeader = common.initHeader(common.currentUser);
    $scope.organ = {};
    $scope.organ.localCertificate = {
      Id: -1,
      showValid: false
    };
    common.initUnSavedConfirm($scope);
    $scope.transferObj = {
      isSucceed: true,
      action: 'edit',
      objName: 'organization',
      title: 'Organization has been updated successfully'
    };
    $scope.certificateFile = {};
    $scope.changeUpload = function(change) {
      $scope.uploadFile = change;
      if (change) {
        if ($scope.uploadCertificate && $scope.uploadCertificate.showValid && uploader.queue && uploader.queue.length > 0) {
          $scope.organ.localCertificate = angular.copy($scope.uploadCertificate);
        } else {
          $scope.organ.localCertificate = {
            showValid: false,
            Id: -1
          };
        }
      }
      if (change === false) {
        $scope.organ.localCertificate = angular.copy($scope.orignalCertificate);
        $scope.organ.localCertificate.showValid = true;
        if ($scope.organ.localCertificate.Id === -1) {
          return $scope.organ.localCertificate.showValid = false;
        }
      }
    };
    $scope.getCertificateInfo = function() {
      return certificateAPI.search({
        file: true,
        id: $scope.organ.CertificateID
      }, function(result) {
        if (result && result.Succeeded) {
          if (result.CertificateList && result.CertificateList.length > 0) {
            $scope.orignalCertificate = result.CertificateList[0];
            $scope.organ.localCertificate = angular.copy($scope.orignalCertificate);
            return $scope.organ.localCertificate.showValid = true;
          } else {
            $scope.orignalCertificate = {
              Id: -1,
              showValid: false
            };
            return $scope.organ.localCertificate = angular.copy($scope.orignalCertificate);
          }
        } else {
          return common.ShowAPIError('Get certificate data failed.', result);
        }
      }, function(error) {
        return common.ShowAPIError('Get certificate data failed.', error.data);
      });
    };
    $scope.initData = function(organId) {
      var response;
      return response = organizationAPI.search({
        id: organId,
        contact: true
      }, function() {
        if (response && response.Succeeded) {
          if (response.OrganizationList && response.OrganizationList.length > 0) {
            $scope.organ = response.OrganizationList[0];
            if ($scope.organ.ContactList && $scope.organ.ContactList.length > 0) {
              $scope.organ.Contact = $scope.organ.ContactList[0];
            }
            if ($scope.organ.CertificateID) {
              return $scope.promise = $scope.getCertificateInfo();
            }
          }
        } else {
          return common.ShowAPIError('Get organization data failed.', response);
        }
      }, function(error) {
        return common.ShowAPIError('Get organization data failed.', error.data);
      });
    };
    pageName = common.currentRoutePath();
    if (common.current.isBackPage === false && common.current.link.status === 'page' && common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
      if (common.current.link[pageName].pageParameter.Id) {
        $scope.promise = $scope.initData(common.current.link[pageName].pageParameter.Id);
      } else {
        common.navigate('organization');
      }
    } else if (common.current.isBackPage === true) {
      common.current.isBackPage = false;
      if (common.current.link && common.current.link[pageName] && common.current.link[pageName].pageParameter) {
        if (common.current.link[pageName].pageParameter.Id) {
          $scope.promise = $scope.initData(common.current.link[pageName].pageParameter.Id);
        } else {
          common.navigate('organization');
        }
      }
    } else {
      common.navigate('organization');
    }
    $scope.enableCertificate = function() {
      if (common.currentUser.Type === common.userRole.superUser && !common.currentOrganization) {
        return false;
      }
      if (common.currentUser.Type === common.userRole.superUser && common.currentOrganization) {
        return true;
      }
      if (common.currentUser.Type === common.userRole.organizationUser && common.currentOrganization) {
        return true;
      }
      return false;
    };
    $scope.removeCertificate = function() {
      return $scope.organ.localCertificate = {
        Id: -1,
        showValid: false
      };
    };
    $scope.save = function() {
      var requestDataModel;
      $scope.organ.ContactList = [];
      if ($scope.organ.Contact) {
        $scope.organ.ContactList.push($scope.organ.Contact);
      }
      if ($scope.organ.localCertificate && $scope.organ.localCertificate.showValid && $scope.organ.localCertificate.Id !== -1) {
        if ($scope.uploadFile && uploader.queue && uploader.queue.length > 0) {
          $scope.organ.localCertificate.FileList = [];
          $scope.organ.localCertificate.FileList.push($scope.certificateFile);
        }
      } else {
        if ($scope.uploadFile && uploader.queue && uploader.queue.length < 1 && $scope.orignalCertificate && $scope.orignalCertificate.Id !== -1) {
          $scope.organ.localCertificate = null;
          $scope.organ.CertificateID = $scope.orignalCertificate.Id;
        } else {
          $scope.organ.localCertificate = null;
          $scope.organ.CertificateID = null;
        }
      }
      if ($scope.organ.localCertificate && $scope.organ.localCertificate.Id === -1) {
        $scope.organ.localCertificate = null;
        $scope.organ.CertificateID = null;
      }
      if ($scope.organ.localCertificate) {
        $scope.organ.Certificate = angular.copy($scope.organ.localCertificate);
      }
      if ($scope.organ.localCertificate && $scope.organ.localCertificate.Id && $scope.organ.CertificateID === $scope.organ.localCertificate.Id) {
        $scope.organ.Certificate = null;
      }
      requestDataModel = {};
      requestDataModel.Organization = angular.copy($scope.organ);
      delete requestDataModel.Organization.localCertificate;
      return organizationAPI.edit(requestDataModel, function(result) {
        if (result.Succeeded) {
          $scope.transferObj.obj = result.OrganizationList[0];
          common.navigate('transfer', $scope.transferObj);
        } else {
          if (uploader.queue && uploader.queue.length > 0) {
            uploader.queue[0].isUploaded = false;
          }
          common.ShowAPIError('Edit organ failed', result);
        }
        return $scope.isSubmit = false;
      }, function(error) {
        if (uploader.queue && uploader.queue.length > 0) {
          uploader.queue[0].isUploaded = false;
        }
        $scope.isSubmit = false;
        return common.ShowAPIError('Edit organ failed', error.data);
      });
    };
    uploader = $scope.uploader = $fileUploader.create({
      scope: $scope,
      url: $scope.uploadurl,
      headers: $scope.uploadHeader,
      filters: [
        function(item) {
          var valid;
          valid = true;
          if (item.name.slice(item.name.lastIndexOf('.') + 1) !== 'cer') {
            valid = false;
            messager.error("File extension name must be cer .");
          }
          $scope.certificateFile.OriginalName = item.name;
          $scope.uploadValid = valid;
          return valid;
        }
      ]
    });
    uploader.bind('success', function(event, xhr, item, msg) {
      if (msg.Succeeded) {
        if (common.validateCertificate(msg.Certificate) === false) {
          messager.error("The certificate file is expired.");
          uploader.queue[0].isUploaded = false;
          $scope.isSubmit = false;
          return;
        }
        if (msg.Certificate.Status !== 'Valid') {
          messager.info("The certificate file will be expired in 30 days.");
        }
        $scope.certificateFile.Url = msg.File.Url;
        $scope.certificateFile.OriginalName = msg.File.OriginalName;
        $scope.certificateFile.Size = msg.File.Size;
        $scope.certificateFile.SubType = 'Main';
        $scope.certificateFile.Hash = msg.File.Hash;
        $scope.uploadCertificate = {};
        $scope.uploadCertificate.Subject = msg.Certificate.Subject;
        $scope.uploadCertificate.ThumbPrint = msg.Certificate.ThumbPrint;
        $scope.uploadCertificate.ValidFrom = msg.Certificate.ValidFrom;
        $scope.uploadCertificate.ValidTo = msg.Certificate.ValidTo;
        $scope.uploadCertificate.IssueBy = msg.Certificate.IssueBy;
        $scope.uploadCertificate.IssueTo = msg.Certificate.IssueTo;
        $scope.uploadCertificate.Purpose = 'Encryption';
        $scope.uploadCertificate.showValid = true;
        $scope.organ.localCertificate = angular.copy($scope.uploadCertificate);
        $scope.message = 'Processing...';
        return $scope.promise = $scope.save();
      } else {
        uploader.queue[0].isUploaded = false;
        if (msg.Errors && msg.Errors.length > 0 && msg.Certificate) {
          messager.error(msg.Errors[0].Message + '<br/>ThumbPrint:' + msg.Certificate.ThumbPrint);
        } else {
          messager.error("The certificate file is not correct.");
        }
        return $scope.isSubmit = false;
      }
    });
    uploader.bind('error', function(event, xhr, item, msg) {
      $scope.certificateFile = {};
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      return common.ShowAPIError('Upload file Failed', msg);
    });
    uploader.bind('cancel', function(event, xhr, item, msg) {
      $scope.certificateFile = {};
      messager.error("Upload file failed.");
      $scope.isSubmit = false;
      uploader.queue[0].isUploaded = false;
      if (msg.data) {
        return common.ShowAPIError('Upload file Failed', msg.data);
      } else {
        return common.ShowAPIError('Upload file Failed', msg);
      }
    });
    uploader.bind('afteraddingfile', function(event, item) {
      debugger;
    });
    uploader.bind('clearAll', function(event, item) {
      if (uploader.queue && uploader.queue.length === 0) {
        return $scope.organ.localCertificate = {
          Id: -1,
          showValid: false
        };
      }
    });
    return $scope.submit = function() {
      debugger;      if ($scope.organForm.$valid) {
        $scope.isSubmit = true;
        if ($scope.uploadFile && uploader.queue && uploader.queue.length > 0) {
          if ($scope.uploadValid && $scope.uploadValid === true) {
            uploader.queue[0].url = common.apiURL.upload + "?fullname=" + $scope.certificateFile.OriginalName + "&filetype=certificate&format=json";
            return uploader.uploadAll();
          } else {
            return messager.error("Please choose correctly file to upload.");
          }
        } else {
          $scope.message = 'Processing...';
          return $scope.promise = $scope.save();
        }
      }
    };
  }
]);
