﻿(function() {

  angular.module('system', ['system-release', 'system-404', 'system-401', 'ngRoute', 'pascalprecht.translate']);

}).call(this);
